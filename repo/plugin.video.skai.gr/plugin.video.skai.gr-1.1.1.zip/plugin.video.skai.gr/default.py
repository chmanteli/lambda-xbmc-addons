# -*- coding: utf-8 -*-

'''
    skai player XBMC Addon
    Copyright (C) 2012 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib,urllib2,re,os,xbmcplugin,xbmcgui,xbmcaddon


settings = xbmcaddon.Addon(id='plugin.video.skai.gr')
data = 'special://profile/addon_data/plugin.video.skai.gr'

home = settings.getAddonInfo('path')
language = settings.getLocalizedString
addonname = settings.getAddonInfo("name")
description = language(30503).encode("utf-8")
icon = xbmc.translatePath(os.path.join(home,'icon.png'))
fanart = xbmc.translatePath(os.path.join(home,'fanart.jpg'))
artPath = xbmc.translatePath(os.path.join(home,'resources/art/'))
favPath = xbmc.translatePath(os.path.join(data,'favourites.cfg'))
dataPath = xbmc.translatePath(data)
skin = xbmc.getSkinDir()

xbmcplugin.setContent(int(sys.argv[1]), 'Episodes')
xbmcplugin.setPluginFanart(int(sys.argv[1]), fanart)

try:
    import StorageServer
    cache = StorageServer.StorageServer(addonname,720)
except:
    import storageserverdummy as StorageServer
    cache = StorageServer.StorageServer(addonname,720)

try:
    import CommonFunctions
    common = CommonFunctions
except:
    import commonfunctionsdummy as CommonFunctions
    common = CommonFunctions



base_url = 'http://www.skai.gr/player/tv/'
base_type = 'TV'


def xbmc_notify(type):
    if type == 'favadd':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30201).encode("utf-8")))
    elif type == 'favrem':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30202).encode("utf-8")))
    elif type == 'favup':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30203).encode("utf-8")))
    elif type == 'favdown':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30204).encode("utf-8")))

def xbmc_refresh():
    xbmc.executebuiltin("Container.Refresh")

def xbmc_view():
    viewenable = settings.getSetting("viewenable")

    if (skin == 'skin.confluence' or skin == 'skin.confluence.svn') and viewenable == 'true':
        confluence_views = [50,51,500,504,503,515]
        view = int(settings.getSetting("confluence"))
        xbmc.executebuiltin("Container.SetViewMode("+str(confluence_views[view])+")")

    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn') and viewenable == 'true':
        rapier_views = [50,52,74,73,68,94]
        view = int(settings.getSetting("rapier"))
        xbmc.executebuiltin("Container.SetViewMode("+str(rapier_views[view])+")")

def xbmc_data():
    if not os.path.exists(dataPath):
        os.makedirs(dataPath)
    if not os.path.isfile(favPath):
        read = open(favPath, 'w')
        read.write('')
        read.close()

def add_favourite_item(name,url):
    xbmc_refresh()
    read = open(favPath, 'a+')
    read.write('"'+name+'"|"'+url+'"\n')
    read.close()
    xbmc_notify('favadd')

def delete_favourite_item(name,url):
    xbmc_refresh()
    read = open(favPath, 'r')
    text = read.read().replace('"'+name+'"|"'+url+'"','')
    read.close()
    read = open(favPath, 'w')
    for line in re.compile('"(.+?)\n').findall(text):
        read.write('"'+line+'\n')
    read.close()
    xbmc_notify('favrem')

def move_favourite_item(name,url,type):
    xbmc_refresh()
    replaced = []
    j = []
    i = 0
    f = open(favPath,'r')
    for line in f:
        if re.search('"'+url.replace('?','[?]')+'"',line) is not None:
            j = i
        i = i+1
    f.close()
    if type == 'favup':
        i = 1
    if type == 'favdown':
        i = -1
    f = open(favPath,'r')
    for line in f:
        if i == j:
            replaced = line
        i = i+1
    f.close()

    if not replaced == []:
        read = open(favPath, 'r')
        text = read.read()
        if type == 'favup':
            text = text.replace(replaced+'"'+name+'"|"'+url+'"','"'+name+'"|"'+url+'"'+replaced)
            text = text.replace('\n','')
        if type == 'favdown':
            text = text.replace('"'+name+'"|"'+url+'"\n'+replaced,replaced+'"'+name+'"|"'+url+'"')
            text = text.replace('\n','')
        read.close()
        read = open(favPath, 'w')
        for name,cid in re.compile('"(.+?)"[|]"(.+?)"').findall(text):
            read.write('"'+name+'"|"'+cid+'"\n')
        if type == 'favup':
            xbmc_notify('favup')
        if type == 'favdown':
            xbmc_notify('favdown')
	    read.close()

def get_favourites():
    xbmc_data()
    read = open(favPath, 'r')
    text = read.read()
    read.close()
    list = re.compile('"(.+?)"[|]"(.+?)"').findall(text)
    total = len(list)
    for name,url in list:
        iconimage = cache.cacheFunction(get_iconimage, url)
        #iconimage = get_iconimage(url)
        add_favourites(total,name,url,500,iconimage)
    xbmc_view()

def add_favourites(total,name,url,mode,iconimage):
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    sysiconimage = urllib.quote_plus(iconimage)
    contextMenuItems = []
    contextMenuItems.append((xbmc.getLocalizedString(13332), 'XBMC.RunPlugin(%s?mode=102&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    contextMenuItems.append((xbmc.getLocalizedString(13333), 'XBMC.RunPlugin(%s?mode=103&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    contextMenuItems.append((xbmc.getLocalizedString(1210), 'XBMC.RunPlugin(%s?mode=101&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    u = '%s?mode=%s&url=%s&iconimage=%s' % (sys.argv[0], str(mode), sysurl, sysiconimage)
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        item.setProperty( "Fanart_Image", iconimage )
    else: item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)

def get_categories():
    xbmc_data()
    try:
        result = common.fetchPage({"link": base_url})
        categories = common.parseDOM(result["content"], "div", attrs = { "id": "player-nav-main" })[0]
        categories = common.parseDOM(categories, "li")
        total = len(categories) + 2
    except:
        total = 2
        xbmc_view()
        return
    add_categories(total,language(30501).encode("utf-8"),base_url,200,artPath+'favorites.png')
    add_categories(total,language(30502).encode("utf-8"),base_url,300,artPath+'shows.png')
    for category in categories:
        try:
            name = common.parseDOM(category, "a")[0]
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            id = common.parseDOM(category, "a", ret="class")[0]
            id = id.split("CID_")[1]
            url = 'http://www.skai.gr/ajax.aspx?m=Skai.Player.ItemView&type=%s&cid=%s' % (base_type, id)
            url = url.encode('utf-8')
            iconimage = cache.cacheFunction(get_iconimage, url)
            #iconimage = get_iconimage(url)
            add_categories(total,name,url,500,iconimage)
        except:
            total = total - 1
            pass
    xbmc_view()
    return

def add_categories(total,name,url,mode,iconimage):
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    sysiconimage = urllib.quote_plus(iconimage)
    contextMenuItems = []
    u = '%s?mode=%s&url=%s&iconimage=%s' % (sys.argv[0], str(mode), sysurl, sysiconimage)
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        item.setProperty( "Fanart_Image", iconimage )
    else: item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)

def get_genres():
    xbmc_data()
    try:
        result = common.fetchPage({"link": base_url})
        categories = common.parseDOM(result["content"], "div", attrs = { "id": "player-nav-main" })[0]
        categories = common.parseDOM(categories, "li")
        total = len(categories)
    except:
        xbmc_view()
        return
    for category in categories:
        try:
            name = common.parseDOM(category, "a")[0]
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            id = common.parseDOM(category, "a", ret="class")[0]
            id = id.split("CID_")[1]
            url = 'http://www.skai.gr/ajax.aspx?m=Skai.Player.ItemView&type=%s&cid=%s' % (base_type, id)
            url = url.encode('utf-8')
            iconimage = cache.cacheFunction(get_iconimage, url)
            #iconimage = get_iconimage(url)
            if not (id == '0'):
                url = 'http://www.skai.gr/ajax.aspx?m=Skai.Player.AlbumsView&type=%s&cid=%s&Page=1&ct=365' % (base_type, id)
                add_genres(total,name,url,400,iconimage)
        except:
            total = total - 1
            pass
    xbmc_view()
    return

def add_genres(total,name,url,mode,iconimage):
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    contextMenuItems = []
    u = '%s?mode=%s&url=%s' % (sys.argv[0], str(mode), sysurl)
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        item.setProperty( "Fanart_Image", iconimage )
    else: item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)

def get_shows(url):
    xbmc_data()
    try:
        result = common.fetchPage({"link": url})
        shows = common.parseDOM(result["content"], "li")
        total = len(shows)
    except:
        xbmc_view()
        return
    for show in shows:
        try:
            name = common.parseDOM(show, "a")[0]
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            id = common.parseDOM(show, "a", ret="class")[0]
            id = re.compile('CategoryLink ALID_(.+?) CID_(.+?)').findall(id)[0]
            url = 'http://www.skai.gr/ajax.aspx?m=Skai.Player.ItemView&type=%s&alid=%s&cid=%s' % (base_type, id[0], id[1])
            url = url.encode('utf-8')
            iconimage = cache.cacheFunction(get_iconimage, url)
            #iconimage = get_iconimage(url)
            add_shows(total,name,url,500,iconimage)
        except:
            total = total - 1
            pass
    xbmc_view()
    return

def add_shows(total,name,url,mode,iconimage):
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    sysiconimage = urllib.quote_plus(iconimage)
    read = open(favPath, 'r')
    text = read.read()
    read.close()
    contextMenuItems = []
    if not url in text: contextMenuItems.append((xbmc.getLocalizedString(14076), 'XBMC.RunPlugin(%s?mode=100&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    else: contextMenuItems.append((xbmc.getLocalizedString(14077), 'XBMC.RunPlugin(%s?mode=101&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    u = '%s?mode=%s&url=%s&iconimage=%s' % (sys.argv[0], str(mode), sysurl, sysiconimage)
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        item.setProperty( "Fanart_Image", iconimage )
    else: item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)

def get_episodes(url,iconimage):
    xbmc_data()
    try:
        result = common.fetchPage({"link": url+'&Page=1'})
        episodes = result["content"]
    except:
        xbmc_view()
        return
    try:
        for i in range(2, 11):
            result = common.fetchPage({"link": url+'&Page='+str(i)})
            episodes += result["content"]
    except:
        pass
    try:
        episodes = common.parseDOM(episodes, "Item")
        total = len(episodes)
    except:
        xbmc_view()
        return
    for episode in episodes:
        try:
            name1 = common.parseDOM(episode, "Title")[0]
            name1 = re.compile(".+?CDATA[[](.+?)[]].+?").findall(name1)[0]
            name2 = common.parseDOM(episode, "Date")[0]
            name2 = re.compile(".+?CDATA[[](.+?)[]].+?").findall(name2)[0]
            name2 = name2.replace('T', ' ')
            name = '%s - %s' % (name1, name2)
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            show = common.replaceHTMLCodes(name1)
            show = show.encode('utf-8')
            url = common.parseDOM(episode, "File")[0]
            url = common.replaceHTMLCodes(url)
            url = re.compile(".+?CDATA[[](.+?)[]].+?").findall(url)[0]
            url = url.encode('utf-8')
            if settings.getSetting("episode_thumbs") == 'true':
                id = common.parseDOM(episode, "ID")[0]
                iconimage = cache.cacheFunction(get_episodes_image, id)
                #iconimage = get_episodes_image(id)
            add_episodes(total,name,show,url,iconimage)
        except:
            total = total - 1
            pass
    xbmc_view()
    return

def add_episodes(total,name,show,url,iconimage):
    mode = 900
    sysurl = urllib.quote_plus(url)
    u = '%s?mode=%s&url=%s' % (sys.argv[0], str(mode), sysurl)
    contextMenuItems = []
    item = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": show, "Plot": description } )
    item.setProperty("IsPlayable", "true")
    item.setProperty( "Video", "true" )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        item.setProperty( "Fanart_Image", iconimage )
    else: item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)	
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total)

def resolve_episodes(url):
    try:
        swfUrl = 'http://www.skai.gr/files/1/Flash/Shows/SkaiMediaPlayer.swf'
        url = '%s pageUrl=%s swfUrl=%s swfVfy=true timeout=10' % (url, base_url, swfUrl)
        item = xbmcgui.ListItem(path=url)
        return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
    except:
        return

def get_episodes_image(id):
    try:
        url = re.compile(".+?CDATA[[](.+?)[]].+?").findall(id)[0]
        url = 'http://www.skai.gr/ajax.aspx?m=Skai.Player.LookupMultimedia&record=false&mmid=%s' % url
        result = common.fetchPage({"link": url})
        iconimage = common.parseDOM(result["content"], "Image")[0]
        iconimage = re.compile(".+?CDATA[[](.+?)[]].+?").findall(iconimage)[0]
        iconimage = iconimage.encode('utf-8')
        return iconimage
    except:
        return

def get_iconimage(url):
    try:
        result = common.fetchPage({"link": url})
        content = result["content"]
        url = common.parseDOM(content, "ID")[0]
        url = re.compile(".+?CDATA[[](.+?)[]].+?").findall(url)[0]
        url = 'http://www.skai.gr/ajax.aspx?m=Skai.Player.LookupMultimedia&record=false&mmid=%s' % url
        result = common.fetchPage({"link": url})
        iconimage = common.parseDOM(result["content"], "Image")[0]
        iconimage = re.compile(".+?CDATA[[](.+?)[]].+?").findall(iconimage)[0]
        iconimage = iconimage.encode('utf-8')
        return iconimage
    except:
        return


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?','')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


params = get_params()
url = None
name = None
mode = None
iconimage = None
try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass


if mode == None or url == None or len(url) < 1:
    get_categories()

elif mode == 100:
    add_favourite_item(name,url)

elif mode == 101:
    delete_favourite_item(name,url)

elif mode == 102:
    move_favourite_item(name,url,'favup')

elif mode == 103:
    move_favourite_item(name,url,'favdown')

elif mode == 200:
    get_favourites()

elif mode == 300:
    get_genres()

elif mode == 400:
    get_shows(url)

elif mode == 500:
    get_episodes(url,iconimage)

elif mode == 900:
    resolve_episodes(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))