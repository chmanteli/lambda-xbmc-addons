# -*- coding: cp1253 -*-

'''
    skai player XBMC Addon
    Copyright (C) 2012 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib,urllib2,re,os,xbmcplugin,xbmcgui,xbmcaddon


settings = xbmcaddon.Addon(id='plugin.video.skai.gr')
data = 'special://profile/addon_data/plugin.video.skai.gr'

home = settings.getAddonInfo('path')
language = settings.getLocalizedString
addonname = settings.getAddonInfo("name")
description = language(30003).encode("utf-8")
icon = xbmc.translatePath(os.path.join(home,'icon.png'))
fanart = xbmc.translatePath(os.path.join(home,'fanart.jpg'))
artPath = xbmc.translatePath(os.path.join(home,'resources/art/'))
favPath = xbmc.translatePath(os.path.join(data,'favourites.cfg'))
datapath = xbmc.translatePath(data)
skin = xbmc.getSkinDir()

xbmcplugin.setContent(int(sys.argv[1]), 'Episodes')
xbmcplugin.setPluginFanart(int(sys.argv[1]), fanart)

try:
    import StorageServer
    cache = StorageServer.StorageServer(addonname,720)
except:
    import storageserverdummy as StorageServer
    cache = StorageServer.StorageServer(addonname,720)
	

base_url = 'http://www.skai.gr/player/tv/'

categories_url = 'http://www.skai.gr/ajax.aspx?m=Skai.Player.ItemView&type=TV&cid=%s&Page='
shows_categories_url = 'http://www.skai.gr/ajax.aspx?m=Skai.Player.AlbumsView&type=TV&cid=%s&Page=1&ct=365'
categories_pattern = '<a class="CategoryLink CID_(.+?)".+?title=".+?">(.+?)</a></li>'

shows_url = 'http://www.skai.gr/ajax.aspx?m=Skai.Player.ItemView&type=TV&alid=%s&cid=%s&Page='
shows_pattern = '<a class="CategoryLink ALID_(.+?) CID_(.+?) ".+?title=".+?">(.+?)</a></li>'

thumbs_url = 'http://www.skai.gr/ajax.aspx?m=Skai.Player.LookupMultimedia&record=true&mmid='
thumbs_pattern = '<Image>.+?CDATA[[](.+?)[]].+?</Image>'

episodes_pattern = '<Item>.+?<ID>.+?CDATA[[](.+?)[]].+?</ID>.+?<Title><.+?CDATA[[](.+?)[]].+?></Title>.+?<Date><.+?CDATA[[](.+?)T(.+?)[]].+?></Date>.+?<File><.+?CDATA[[](.+?)[]].+?></File>.+?<Photo1>(.+?)</Photo1>.+?</Item>'


def xbmc_notify(type):
    if type == 'favadd':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30101).encode("utf-8")))
    elif type == 'favrem':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30102).encode("utf-8")))
    elif type == 'favup':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30103).encode("utf-8")))
    elif type == 'favdown':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30104).encode("utf-8")))

def xbmc_refresh():
    xbmc.executebuiltin("Container.Refresh")

def xbmc_view():
    viewenable = settings.getSetting("viewenable")

    if (skin == 'skin.confluence' or skin == 'skin.confluence-vertical' \
    or skin == 'skin.confluence.moviesets'):
        if viewenable == 'true':
            confluence_views = [50,51,500,503,504]
            view = int(settings.getSetting("confluence"))
            xbmc.executebuiltin("Container.SetViewMode("+str(confluence_views[view])+")")

    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        if viewenable == 'true':
            rapier_views = [50,52,74,73,68,94]
            view = int(settings.getSetting("rapier"))
            xbmc.executebuiltin("Container.SetViewMode("+str(rapier_views[view])+")")

def xbmc_data():
    if not os.path.exists(datapath):
        os.makedirs(datapath)
    if not os.path.isfile(favPath):
        read = open(favPath, 'w')
        read.write('')
        read.close()

def GetURL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    link = link.replace('\n','')
    return link

def get_favourites():
    xbmc_data()
    read = open(favPath, 'r')
    text = read.read()
    read.close()
    for name,url in re.compile('"(.+?)"[|]"(.+?)"').findall(text):
        thumbnail = cache.cacheFunction(get_episodes, url,'thumbnail')
        #thumbnail = get_episodes(url,'thumbnail')
        add_favourites(name,url,900,thumbnail)
    xbmc_view()

def add_favourites(name,url,mode,iconimage):
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    contextMenuItems = []
    contextMenuItems.append((xbmc.getLocalizedString(13332), 'XBMC.RunPlugin(%s?mode=102&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    contextMenuItems.append((xbmc.getLocalizedString(13333), 'XBMC.RunPlugin(%s?mode=103&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    contextMenuItems.append((xbmc.getLocalizedString(1210), 'XBMC.RunPlugin(%s?mode=101&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        liz.setProperty( "Fanart_Image", iconimage )
    else: liz.setProperty( "Fanart_Image", fanart )
    liz.addContextMenuItems(contextMenuItems, replaceItems=True)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def add_favourite_item(name,url):
    xbmc_refresh()
    read = open(favPath, 'a+')
    read.write('"'+name+'"|"'+url+'"\n')
    read.close()
    xbmc_notify('favadd')

def delete_favourite_item(name,url):
    xbmc_refresh()
    read = open(favPath, 'r')
    text = read.read().replace('"'+name+'"|"'+url+'"','')
    read.close()
    read = open(favPath, 'w')
    for line in re.compile('"(.+?)\n').findall(text):
        read.write('"'+line+'\n')
    read.close()
    xbmc_notify('favrem')

def move_favourite_item(name,url,type):
    xbmc_refresh()
    replaced = []
    j = []
    i = 0
    f = open(favPath,'r')
    for line in f:
        if re.search('"'+url.replace('?','[?]')+'"',line) is not None:
            j = i
        i = i+1
    f.close()
    if type == 'favup':
        i = 1
    if type == 'favdown':
        i = -1
    f = open(favPath,'r')
    for line in f:
        if i == j:
            replaced = line
        i = i+1
    f.close()

    if not replaced == []:
        read = open(favPath, 'r')
        text = read.read()
        if type == 'favup':
            text = text.replace(replaced+'"'+name+'"|"'+url+'"','"'+name+'"|"'+url+'"'+replaced)
            text = text.replace('\n','')
        if type == 'favdown':
            text = text.replace('"'+name+'"|"'+url+'"\n'+replaced,replaced+'"'+name+'"|"'+url+'"')
            text = text.replace('\n','')
        read.close()
        read = open(favPath, 'w')
        for name,cid in re.compile('"(.+?)"[|]"(.+?)"').findall(text):
            read.write('"'+name+'"|"'+cid+'"\n')
        if type == 'favup':
            xbmc_notify('favup')
        if type == 'favdown':
            xbmc_notify('favdown')
	    read.close()


def get_categories():
	xbmc_data()
	add_categories(language(30001).encode("utf-8"),base_url,200,artPath+'favorites.png')
	add_categories(language(30002).encode("utf-8"),base_url,300,artPath+'shows.png')
	try:
		link = GetURL(base_url)
		for cid,name in re.compile(categories_pattern).findall(link):
			name = name.replace('	','')
			url = categories_url %(cid)
			try:
				thumbnail = cache.cacheFunction(get_episodes, url,'thumbnail')
				#thumbnail = get_episodes(url,'thumbnail')
			except:
			    pass
			if thumbnail is not None:
				add_categories(name,url,900,thumbnail)
			xbmc_view()
	except:
		xbmc_view()
		return

def get_shows_categories():
	xbmc_data()
	try:
		link = GetURL(base_url)
		for cid,name in re.compile(categories_pattern).findall(link):
			name = name.replace('	','')
			url = categories_url %(cid)
			try:
				thumbnail = cache.cacheFunction(get_episodes, url,'thumbnail')
				#thumbnail = get_episodes(url,'thumbnail')
			except:
			    pass
			if not (thumbnail is None) and not (cid == '0'):
				url = shows_categories_url %(cid)
				add_categories(name,url,400,thumbnail)
			xbmc_view()
	except:
		xbmc_view()
		return

def add_categories(name,url,mode,iconimage):
    contextMenuItems = []
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        liz.setProperty( "Fanart_Image", iconimage )
    else: liz.setProperty( "Fanart_Image", fanart )
    liz.addContextMenuItems(contextMenuItems, replaceItems=True)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def get_shows(url):
	xbmc_data()
	try:
		link = GetURL(url)
		for alid,cid,name in re.compile(shows_pattern).findall(link):
			name = name.replace('	','')
			url = shows_url %(alid,cid)
			try:
				thumbnail = cache.cacheFunction(get_episodes, url,'thumbnail')
				#thumbnail = get_episodes(url,'thumbnail')
			except:
			    pass
			if thumbnail is not None:
				add_shows(name,url,900,thumbnail)
			xbmc_view()
	except:
		xbmc_view()
		return

def add_shows(name,url,mode,iconimage):
    read = open(favPath, 'r')
    text = read.read()
    read.close()
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    contextMenuItems = []
    if not url in text:
        contextMenuItems.append((xbmc.getLocalizedString(14076), 'XBMC.RunPlugin(%s?mode=100&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    else:
        contextMenuItems.append((xbmc.getLocalizedString(14077), 'XBMC.RunPlugin(%s?mode=101&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        liz.setProperty( "Fanart_Image", iconimage )
    else: liz.setProperty( "Fanart_Image", fanart )
    liz.addContextMenuItems(contextMenuItems, replaceItems=True)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok
	
def thumbnail_fixer(id):
    for thumbnail in re.compile(thumbs_pattern).findall(GetURL(thumbs_url+id)):
        thumbnail = thumbnail
    return thumbnail

def get_episodes(url,type):
	try:
	    episodes_url = url
	    for i in range(1, 11):
	        link = GetURL(episodes_url+str(i))
	        if '<Item>' in link:
	            for id,n1,n2,n3,url,thumbnail in re.compile(episodes_pattern).findall(link):
	                if type == 'thumbnail':
	                    thumbnail = thumbnail_fixer(id)
	                    return thumbnail
	                elif type == 'episode':
	                    thumbnail = cache.cacheFunction(thumbnail_fixer, id)
	                    #thumbnail = thumbnail_fixer(id)
	                    name = n1+' - '+n2+' - '+n3
	                    add_episodes(name,url,thumbnail)
	            xbmc_view()
	        else:
	            xbmc_view()
	            return
	except:
		xbmc_view()
		return

def add_episodes(name,url,iconimage):
    mode = 901
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok = True
    contextMenuItems = []
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    liz.setProperty("IsPlayable", "true")
    liz.setProperty( "Video", "true" )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        liz.setProperty( "Fanart_Image", iconimage )
    else: liz.setProperty( "Fanart_Image", fanart )
    liz.addContextMenuItems(contextMenuItems, replaceItems=True)	
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
    return ok

def resolve_episodes(url):
    swfUrl = 'http://www.skai.gr/files/1/Flash/Shows/SkaiMediaPlayer.swf'
    url = url+' swfUrl='+swfUrl+' swfVfy=true timeout=10'

    item = xbmcgui.ListItem(path=url)
    return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?','')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


params = get_params()
url = None
name = None
mode = None
try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass


if mode == None or url == None or len(url) < 1:
    get_categories()

elif mode == 100:
    add_favourite_item(name,url)

elif mode == 101:
    delete_favourite_item(name,url)

elif mode == 102:
    move_favourite_item(name,url,'favup')

elif mode == 103:
    move_favourite_item(name,url,'favdown')

elif mode == 200:
    get_favourites()

elif mode == 300:
    get_shows_categories()

elif mode == 400:
    get_shows(url)

elif mode == 900:
    get_episodes(url,'episode')

elif mode == 901:
    resolve_episodes(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))