# -*- coding: utf-8 -*-

'''
    alpha podcast XBMC Addon
    Copyright (C) 2012 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib,urllib2,re,os,xbmcplugin,xbmcgui,xbmcaddon
import random
import sets


settings = xbmcaddon.Addon(id='plugin.audio.alpha989')
data = 'special://profile/addon_data/plugin.audio.alpha989'

home = settings.getAddonInfo('path')
language = settings.getLocalizedString
addonname = settings.getAddonInfo("name")
album = 'Alpha 989'
genre = language(30502).encode("utf-8")
description = language(30503).encode("utf-8")
icon = xbmc.translatePath(os.path.join(home,'icon.png'))
fanart1 = xbmc.translatePath(os.path.join(home,'resources/fanart/1.jpg'))
fanart2 = xbmc.translatePath(os.path.join(home,'resources/fanart/2.jpg'))
image1 = xbmc.translatePath(os.path.join(home,'resources/images/1.png'))
image2 = xbmc.translatePath(os.path.join(home,'resources/images/2.png'))
datapath = xbmc.translatePath(data)
skin = xbmc.getSkinDir()

rule = '<rule name="alpha989" audio="true" filename="*alpha989.com*" player="dvdplayer"/>'

xbmcplugin.setContent(int(sys.argv[1]), 'Songs')

try:
    import StorageServer
    cache = StorageServer.StorageServer(addonname,720)
except:
    import storageserverdummy as StorageServer
    cache = StorageServer.StorageServer(addonname,720)

try:
    import CommonFunctions
    common = CommonFunctions
except:
    import commonfunctionsdummy as CommonFunctions
    common = CommonFunctions



base_url = 'http://www.alpha989.com/'


def unique_list(list):
    unique_set = sets.Set()
    unique_list = []
    for n in list:
        if n not in unique_set:
            unique_set.add(n)
            unique_list.append(n)
    return unique_list

def xbmc_view():
    viewenable = settings.getSetting("viewenable")

    if (skin == 'skin.confluence' or skin == 'skin.confluence.svn') and viewenable == 'true':
        confluence_views = [50,51,500,506]
        view = int(settings.getSetting("confluence"))
        xbmc.executebuiltin("Container.SetViewMode("+str(confluence_views[view])+")")

    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn') and viewenable == 'true':
        rapier_views = [50,63,52,77,62,67]
        view = int(settings.getSetting("rapier"))
        xbmc.executebuiltin("Container.SetViewMode("+str(rapier_views[view])+")")

def playercorecheck(rule):
    playercorefile = xbmc.translatePath('special://masterprofile/playercorefactory.xml')
    playercorebackup = xbmc.translatePath('special://masterprofile/playercorefactory.xml.bak')

    try:
        read = open(playercorefile, 'r')
        text = read.read()
        read.close()
    except:
        text = ''
        pass

    if not text.find(rule) == -1:
        return
    else:
        retval = xbmcgui.Dialog().yesno(addonname, language(30201).encode("utf-8"), language(30202).encode("utf-8"))

    if not retval:
        return

    if not os.path.isfile(playercorefile):
        text = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<playercorefactory>\n<rules action="prepend">\n'+rule+'\n</rules>\n</playercorefactory>'
        write = open(playercorefile,'w+')
        write.write(text)
        write.close()
        retval = xbmcgui.Dialog().yesno(addonname, language(30203).encode("utf-8"), language(30204).encode("utf-8"))
        if retval: xbmc.executebuiltin("Quit()")
        return

    text = text.replace('<rules action="overwrite">','<rules action="overwrite">\n'+rule)
    text = text.replace('<rules action="prepend">','<rules action="prepend">\n'+rule)
    text = text.replace('<rules action="append">','<rules action="append">\n'+rule)
    if not text.find(rule) == -1:
        os.rename(playercorefile, playercorebackup)
        write = open(playercorefile,'w+')
        write.write(text)
        write.close()
        retval = xbmcgui.Dialog().yesno(addonname, language(30203).encode("utf-8"), language(30204).encode("utf-8"))
        if retval: xbmc.executebuiltin("Quit()")
        return

    text = text.replace('<playercorefactory>','<playercorefactory>\n<rules action="prepend">\n'+rule+'\n</rules>')
    if not text.find(rule) == -1:
        os.rename(playercorefile, playercorebackup)
        write = open(playercorefile,'w+')
        write.write(text)
        write.close()
        retval = xbmcgui.Dialog().yesno(addonname, language(30203).encode("utf-8"), language(30204).encode("utf-8"))
        if retval: xbmc.executebuiltin("Quit()")
        return

    text += '<playercorefactory>\n<rules action="prepend">\n'+rule+'\n</rules>\n</playercorefactory>'
    if not text.find(rule) == -1:
        os.rename(playercorefile, playercorebackup)
        write = open(playercorefile,'w+')
        write.write(text)
        write.close()
        retval = xbmcgui.Dialog().yesno(addonname, language(30203).encode("utf-8"), language(30204).encode("utf-8"))
        if retval: xbmc.executebuiltin("Quit()")
        return
    return

def get_producers():
    try:
        result = common.fetchPage({"link": base_url})
        producers = common.parseDOM(result["content"], "div", attrs = { "class": "producersHome" })[0]
        producers = common.parseDOM(producers, "div", attrs = { "class": "pItem" })
        total = len(producers) + 1
    except:
        total = 1
        xbmc_view()
        return
    add_producers(total,language(30501).encode("utf-8"),base_url,1,image1)
    for producer in producers:
        try:
            name = common.parseDOM(producer, "h2")[0]
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            iconimage = common.parseDOM(producer, "img", ret="src")[0]
            iconimage = base_url + iconimage
            iconimage = iconimage.encode('utf-8')
            url = common.parseDOM(producer, "a", ret="href")[0]
            url = base_url + url
            url = url.encode('utf-8')
            add_producers(total,name,url,2,iconimage)
        except:
            total = total - 1
            pass
    xbmc_view()
    return

def add_producers(total,name,url,mode,iconimage):
    sysartist = urllib.quote_plus(name)
    sysiconimage = urllib.quote_plus(iconimage)
    sysurl = urllib.quote_plus(url)
    contextMenuItems = []
    u = '%s?mode=%s&url=%s&artist=%s&iconimage=%s' % (sys.argv[0], str(mode), sysurl, sysartist, sysiconimage)
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    item.setInfo( type="music", infoLabels={ "Title": name, "Label": name, "Artist": name, "Album": album, "Genre": genre, "Comment": description } )
    item.setProperty( "Album_Description", description )
    item.setProperty( "Fanart_Image", random.choice([fanart1, fanart2]) )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)

def get_interviews():
    try:
        result = common.fetchPage({"link": base_url})
        interviews = common.parseDOM(result["content"], "div", attrs = { "class": "interBoxHome" })[0]
        interviews = common.parseDOM(interviews, "div", attrs = { "class": "iItems.+?" })
        total = len(interviews)
    except:
        xbmc_view()
        return
    for interview in interviews:
        try:
            name2 = common.parseDOM(interview, "div", attrs = { "class": "dateTime" })[0]
            name1 = common.parseDOM(interview, "div", attrs = { "class": "text" })[0]
            name1 = common.parseDOM(name1, "a")[0]
            name = '%s - %s' % (name1, name2)
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            url = common.parseDOM(interview, "div", attrs = { "class": "text" })[0]
            url = common.parseDOM(url, "a", ret="href")[0]
            url = base_url + url
            url = url.encode('utf-8')
            add_podcasts(total,name,url,artist,image1)
        except:
            total = total - 1
            pass
    xbmc_view()
    return

def get_podcasts(url,artist,iconimage):
    try:
        result = common.fetchPage({"link": url})
        podcasts = common.parseDOM(result["content"], "div", attrs = { "class": "playNow" })[0]
    except:
        xbmc_view()
        return
    try:
        navs = common.parseDOM(result["content"], "td", attrs = { "class": "pagerIn" })[0]
        navs = common.parseDOM(navs, "a", ret="href")
        navs = unique_list(navs)
        for nav in navs:
            url = base_url + nav
            result = common.fetchPage({"link": url})
            podcasts += common.parseDOM(result["content"], "div", attrs = { "class": "playNow" })[0]
    except:
        pass
    try:
        podcasts = common.parseDOM(podcasts, "div", attrs = { "id": "cphMainTop.+?" })
        total = len(podcasts)
    except:
        xbmc_view()
        return
    for podcast in podcasts:
        try:
            name1 = common.parseDOM(podcast, "b")[0]
            name2 = podcast.split("<br />")[1].replace('\n','').replace('  ','')
            name = '%s - %s' % (name1, name2)
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            url = common.parseDOM(podcast, "a", ret="href")[0]
            url = base_url + url
            url = common.replaceHTMLCodes(url)
            url = url.encode('utf-8')
            add_podcasts(total,name,url,artist,iconimage)
        except:
            total = total - 1
            pass
    xbmc_view()
    return

def add_podcasts(total,name,url,artist,iconimage):
    mode = 0
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    contextMenuItems = []
    u = '%s?mode=%s&name=%s&url=%s' % (sys.argv[0], str(mode), sysname, sysurl)
    item = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    item.setInfo( type="music", infoLabels={ "Title": name, "Label": name, "Artist": artist, "Album": album, "Genre": genre, "Comment": description } )
    item.setProperty("IsPlayable", "true")
    item.setProperty( "music", "true" )
    item.setProperty( "Album_Description", description )
    item.setProperty( "Fanart_Image", random.choice([fanart1, fanart2]) )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total)

def resolve_podcasts(name,url):
    playercorecheck(rule)
    try:
        result = common.fetchPage({"link": url})
        try:
            result = common.parseDOM(result["content"], "div", attrs = { "class": "playNow" })[0]
        except:
            pass
        try:
            result = common.parseDOM(result["content"], "div", attrs = { "class": "mainContent" })[0]
        except:
            pass
        rtmp = re.compile("streamer: '(.+?)'").findall(result)[0]
        playpath = re.compile("file: '(.+?)'").findall(result)[0]
        app = re.split('\/+', playpath)[0]
        playpath = re.split('\/+', playpath)[1]
        if (playpath.endswith('.mp3') and not playpath.startswith('mp3:')):
            playpath = 'mp3:%s' % (playpath)
        url = '%s playpath=%s/%s pageUrl=%s timeout=10' % (rtmp, app, playpath, base_url)
        item = xbmcgui.ListItem(path=url, iconImage=image2, thumbnailImage=image2)
        return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
    except:
        return


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?','')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


params = get_params()
url = None
name = None
mode = None
artist = None
iconimage = None
try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    artist = urllib.unquote_plus(params["artist"])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass


if mode==None or url==None or len(url)<1:
    get_producers()

elif mode==1:
    get_interviews()

elif mode==2:
    get_podcasts(url,artist,iconimage)

elif mode==0:
    resolve_podcasts(name,url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))