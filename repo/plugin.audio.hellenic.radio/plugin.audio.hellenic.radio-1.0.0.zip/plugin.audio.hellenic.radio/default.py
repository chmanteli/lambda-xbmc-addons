# -*- coding: cp1253 -*-

'''
    hellenic radio XBMC Addon
    Copyright (C) 2012 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib,urllib2,re,os,xbmcplugin,xbmcgui,xbmcaddon
import random


settings = xbmcaddon.Addon(id='plugin.audio.hellenic.radio')
data = 'special://profile/addon_data/plugin.audio.hellenic.radio'

home = settings.getAddonInfo('path')
language = settings.getLocalizedString
addonname = settings.getAddonInfo("name")
icon = xbmc.translatePath(os.path.join(home,'icon.png'))
fanart1 = xbmc.translatePath(os.path.join(home,'resources/fanart/1.jpg'))
fanart2 = xbmc.translatePath(os.path.join(home,'resources/fanart/2.jpg'))
artPath = xbmc.translatePath(os.path.join(home,'resources/art/'))
logoPath = xbmc.translatePath(os.path.join(home,'resources/logos/'))
favPath = xbmc.translatePath(os.path.join(data,'favourites.cfg'))
datapath = xbmc.translatePath(data)
skin = xbmc.getSkinDir()

xbmcplugin.setContent(int(sys.argv[1]), 'Albums')


def xbmc_notify(type):
    if type == 'favadd':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30401).encode("utf-8")))
    elif type == 'favrem':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30402).encode("utf-8")))
    elif type == 'favup':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30403).encode("utf-8")))
    elif type == 'favdown':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30404).encode("utf-8")))

def xbmc_refresh():
    xbmc.executebuiltin("Container.Refresh")

def xbmc_view():
    viewenable = settings.getSetting("viewenable")

    if (skin == 'skin.confluence' or skin == 'skin.confluence-vertical' \
    or skin == 'skin.confluence.moviesets'):
        if viewenable == 'true':
            confluence_views = [50,51,500,509,506,513]
            view = int(settings.getSetting("confluence"))
            xbmc.executebuiltin("Container.SetViewMode("+str(confluence_views[view])+")")

    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        if viewenable == 'true':
            rapier_views = [50,63,52,77,62,67,96,98,64,70]
            view = int(settings.getSetting("rapier"))
            xbmc.executebuiltin("Container.SetViewMode("+str(rapier_views[view])+")")

def xbmc_data():
    if not os.path.exists(datapath):
        os.makedirs(datapath)
    if not os.path.isfile(favPath):
        read = open(favPath, 'w')
        read.write('')
        read.close()
		
def add_favourite_item(name,url):
    xbmc_refresh()
    read = open(favPath, 'a+')
    read.write('"'+name+'"|"'+url+'"\n')
    read.close()
    xbmc_notify('favadd')

def delete_favourite_item(name,url):
    xbmc_refresh()
    read = open(favPath, 'r')
    text = read.read().replace('"'+name+'"|"'+url+'"','')
    read.close()
    read = open(favPath, 'w')
    for line in re.compile('"(.+?)\n').findall(text):
        read.write('"'+line+'\n')
    read.close()
    xbmc_notify('favrem')

def move_favourite_item(name,url,type):
    xbmc_refresh()
    replaced = []
    j = []
    i = 0
    f = open(favPath,'r')
    for line in f:
        if re.search('"'+name.replace('?','[?]')+'"',line) is not None:
            j = i
        i = i+1
    f.close()
    if type == 'favup':
        i = 1
    if type == 'favdown':
        i = -1
    f = open(favPath,'r')
    for line in f:
        if i == j:
            replaced = line
        i = i+1
    f.close()

    if not replaced == []:
        read = open(favPath, 'r')
        text = read.read()
        if type == 'favup':
            text = text.replace(replaced+'"'+name+'"|"'+url+'"','"'+name+'"|"'+url+'"'+replaced)
            text = text.replace('\n','')
        if type == 'favdown':
            text = text.replace('"'+name+'"|"'+url+'"\n'+replaced,replaced+'"'+name+'"|"'+url+'"')
            text = text.replace('\n','')
        read.close()
        read = open(favPath, 'w')
        for name,cid in re.compile('"(.+?)"[|]"(.+?)"').findall(text):
            read.write('"'+name+'"|"'+cid+'"\n')
        if type == 'favup':
            xbmc_notify('favup')
        if type == 'favdown':
            xbmc_notify('favdown')
	    read.close()

def get_categories():
    xbmc_data()
    add_categories(language(30001).encode("utf-8"),language(30101).encode("utf-8"),1,artPath+'01.png')
    add_categories(language(30002).encode("utf-8"),language(30102).encode("utf-8"),2,artPath+'02.png')
    add_categories(language(30011).encode("utf-8"),language(30111).encode("utf-8"),11,artPath+'03.png')
    add_categories(language(30012).encode("utf-8"),language(30112).encode("utf-8"),12,artPath+'04.png')
    add_categories(language(30013).encode("utf-8"),language(30113).encode("utf-8"),13,artPath+'05.png')
    add_categories(language(30014).encode("utf-8"),language(30114).encode("utf-8"),14,artPath+'06.png')
    add_categories(language(30015).encode("utf-8"),language(30115).encode("utf-8"),15,artPath+'07.png')
    add_categories(language(30016).encode("utf-8"),language(30116).encode("utf-8"),16,artPath+'08.png')
    add_categories(language(30017).encode("utf-8"),language(30117).encode("utf-8"),17,artPath+'09.png')
    add_categories(language(30021).encode("utf-8"),language(30121).encode("utf-8"),21,artPath+'10.png')
    xbmc_view()

def add_categories(name,description,mode,iconimage):
    url = 'http://www.radio.gr'
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="music", infoLabels={ "Title": name, "Label": name, "Album": name } )
    liz.setProperty( "Album_Description", description )
    liz.setProperty( "Fanart_Image", random.choice([fanart1, fanart2]) )
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def get_favourites():
    xbmc_data()
    read = open(favPath, 'r')
    text = read.read()
    read.close()
    for favname,favlocation in re.compile('"(.+?)"[|]"(.+?)"').findall(text):
        get_radios('1',favname,favlocation)
    xbmc_view()

def get_radios(type,favname,favlocation):

    #type == '2'	All
    #type == '11'	International
    #type == '12'	Eclectic
    #type == '13'	Rock
    #type == '14'	Greek
    #type == '15'	Laika
    #type == '16'	Sports
    #type == '17'	News
    #type == '21'	Athens

    name = 'Ant1 Radio'
    band = '97,2'
    genre = 'News'
    location = 'Athens'
    url = 'http://ant1.live24.gr/ant1'
    if (type == '2' or type == '17' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Athens DeeJay'
    band = '95,2'
    genre = 'International'
    location = 'Athens'
    url = 'mms://213.186.58.26/deejay'
    if (type == '2' or type == '11' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Athens Party'
    band = ''
    genre = 'International'
    location = 'Athens'
    url = 'mms://golive.onestreaming.com/athensparty'
    if (type == '2' or type == '11' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Atlantis'
    band = '105,2'
    genre = 'Rock'
    location = 'Athens'
    url = 'http://stream.passcast.net:7030'
    if (type == '2' or type == '13' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Best'
    band = '92,6'
    genre = 'Eclectic'
    location = 'Athens'
    url = 'mms://best.live24.gr/best1222'
    if (type == '2' or type == '12' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Deftero'
    band = '103,7'
    genre = 'Eclectic'
    location = 'Athens'
    url = 'mms://a1782.l3271951781.c32719.g.lm.akamaistream.net/D/1782/32719/v0001/reflector:51781'
    if (type == '2' or type == '12' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Derti'
    band = '98,6'
    genre = 'Laika'
    location = 'Athens'
    url = 'mms://derti.live24.gr/derty1000'
    if (type == '2' or type == '15' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Diesi'
    band = '101,3'
    genre = 'Eclectic'
    location = 'Athens'
    url = 'mms://diesi.live24.gr/diesi1013'
    if (type == '2' or type == '12' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Difono'
    band = '96,6'
    genre = 'Eclectic'
    location = 'Athens'
    url = 'mms://captainjack.live24.gr/captainjack9660'
    if (type == '2' or type == '12' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Dromos'
    band = '89,8'
    genre = 'Greek'
    location = 'Athens'
    url = 'mms://dromos898.live24.gr/dromos898'
    if (type == '2' or type == '14' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'En Lefko'
    band = '87,7'
    genre = 'Eclectic'
    location = 'Athens'
    url = 'mms://enleuko.live24.gr/enleuko877'
    if (type == '2' or type == '12' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'ERA Sport'
    band = '101,8'
    genre = 'Sports'
    location = 'Athens'
    url = 'mms://a1113.l3271935112.c32719.g.lm.akamaistream.net/D/1113/32719/v0001/reflector:35112'
    if (type == '2' or type == '16' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Flash'
    band = '96'
    genre = 'News'
    location = 'Athens'
    url = 'mms://flash.live24.gr/flash5252'
    if (type == '2' or type == '17' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Freedom'
    band = '88,9'
    genre = 'Rock'
    location = 'Athens'
    url = 'mms://a1251.l4434923250.c44349.g.lm.akamaistream.net/D/1251/44349/v0001/reflector:23250'
    if (type == '2' or type == '13' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Galaxy'
    band = '92'
    genre = 'International'
    location = 'Athens'
    url = 'mms://galaxy.live24.gr/galaxy9292'
    if (type == '2' or type == '11' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Happy Radio'
    band = '93,2'
    genre = 'Greek'
    location = 'Athens'
    url = 'mms://orange.live24.gr/orange9320'
    if (type == '2' or type == '14' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Hot Fm'
    band = '104,6'
    genre = 'International'
    location = 'Athens'
    url = 'http://hotfm.live24.gr/shock'
    if (type == '2' or type == '11' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Kiss Fm'
    band = '92,9'
    genre = 'International'
    location = 'Athens'
    url = 'mms://kissfm.live24.gr/kiss2111'
    if (type == '2' or type == '11' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Kosmos'
    band = '93,6'
    genre = 'Eclectic'
    location = 'Athens'
    url = 'mms://a1232.l3271935231.c32719.g.lm.akamaistream.net/D/1232/32719/v0001/reflector:35231'
    if (type == '2' or type == '12' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Love Radio'
    band = '97,5'
    genre = 'Eclectic'
    location = 'Athens'
    url = 'mms://loveradio.live24.gr/loveradio-1000'
    if (type == '2' or type == '12' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Mad Radio'
    band = '106,2'
    genre = 'International'
    location = 'Athens'
    url = 'mms://mediaserver.mad.tv/madradio'
    if (type == '2' or type == '11' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Melodia'
    band = '99,2'
    genre = 'Eclectic'
    location = 'Athens'
    url = 'http://s4.onweb.gr:8050'
    if (type == '2' or type == '12' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Music'
    band = '89,2'
    genre = 'International'
    location = 'Athens'
    url = 'mms://a714.l649552713.c6495.g.lm.akamaistream.net/D/714/6495/v0001/reflector:52713'
    if (type == '2' or type == '11' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'NET'
    band = '105,8'
    genre = 'News'
    location = 'Athens'
    url = 'mms://a1709.l3271943708.c32719.g.lm.akamaistream.net/D/1709/32719/v0001/reflector:43708'
    if (type == '2' or type == '17' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Nitro Radio'
    band = '102,5'
    genre = 'International'
    location = 'Athens'
    url = 'mms://nitro.live24.gr/nitro4555'
    if (type == '2' or type == '11' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Nova Sport Fm'
    band = '94,6'
    genre = 'Sports'
    location = 'Athens'
    url = 'mms://sportfm.live24.gr/sportfm7712'
    if (type == '2' or type == '16' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'NRJ Athens'
    band = '88,6'
    genre = 'International'
    location = 'Athens'
    url = 'mms://johngreek.live24.gr/polis2795'
    if (type == '2' or type == '11' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Oasis Fm'
    band = '88'
    genre = 'Laika'
    location = 'Athens'
    url = 'mms://oasis.live24.gr/oasis8888'
    if (type == '2' or type == '15' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Radio 9'
    band = '98,9'
    genre = 'News'
    location = 'Athens'
    url = 'mms://a1278.l7083151277.c70831.e.lm.akamaistream.net/D/1278/70831/v0001/reflector:51277'
    if (type == '2' or type == '17' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Real Fm'
    band = '97,8'
    genre = 'News'
    location = 'Athens'
    url = 'mms://realfm.live24.gr/realfm'
    if (type == '2' or type == '17' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Red'
    band = '96,3'
    genre = 'Rock'
    location = 'Athens'
    url = 'rtmp://cp138550.live.edgefcs.net/live/ playpath=red_flash@11536 live=true pageUrl=http://www.redfm.gr/main/player/'
    if (type == '2' or type == '13' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Rock Fm'
    band = '96,9'
    genre = 'Rock'
    location = 'Athens'
    url = 'mms://rockfm.mediabox.gr/Rockfm'
    if (type == '2' or type == '13' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Rythmos'
    band = '94,9'
    genre = 'Greek'
    location = 'Athens'
    url = 'mms://nordr.live24.gr/rythmos949ath'
    if (type == '2' or type == '14' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Sentra Fm'
    band = '103,3'
    genre = 'Sports'
    location = 'Athens'
    url = 'mms://sentrafm.live24.gr/sentrafm'
    if (type == '2' or type == '16' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Sfera'
    band = '102,2'
    genre = 'Greek'
    location = 'Athens'
    url = 'mms://sfera.live24.gr/sfera4132'
    if (type == '2' or type == '14' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Skai Radio'
    band = '100,3'
    genre = 'News'
    location = 'Athens'
    url = 'rtmp://cp76153.live.edgefcs.net/live/ playpath=RADIO_LIVE_1@10774 live=true pageUrl=http://www.skai.gr/player/radiolive/'
    if (type == '2' or type == '17' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Sto Kokkino'
    band = '105,5'
    genre = 'News'
    location = 'Athens'
    url = 'http://stokokkino.gr:8000/stream'
    if (type == '2' or type == '17' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'Vima Fm'
    band = '99,5'
    genre = 'News'
    location = 'Athens'
    url = 'mms://a455.l649556454.c6495.g.lm.akamaistream.net/D/455/6495/v0001/reflector:56454'
    if (type == '2' or type == '17' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    name = 'VFM'
    band = '88,3'
    genre = 'International'
    location = 'Athens'
    url = 'mms://village883.live24.gr/village883'
    if (type == '2' or type == '11' or type == '21') \
	or (type == '1' and name == favname and location == favlocation):
        add_radios(name,url,type,band,genre,location)

    if not type == '1': xbmc_view()

def add_radios(name,url,type,band,genre,location):
    mode = 0
    sysname = urllib.quote_plus(name)
    sysloc = urllib.quote_plus(location)
    contextMenuItems = []
    if not type == '1':
        read = open(favPath, 'r')
        text = read.read()
        read.close()
        favourite = '"'+name+'"|"'+location+'"'
        if not favourite in text: contextMenuItems.append((language(30405).encode("utf-8"), 'XBMC.RunPlugin(%s?mode=100&name=%s&url=%s)' % (sys.argv[0], sysname, sysloc)))
        else: contextMenuItems.append((language(30406).encode("utf-8"), 'XBMC.RunPlugin(%s?mode=101&name=%s&url=%s)' % (sys.argv[0], sysname, sysloc)))
    if type == '1':
        contextMenuItems.append((xbmc.getLocalizedString(13332), 'XBMC.RunPlugin(%s?mode=102&name=%s&url=%s)' % (sys.argv[0], sysname, sysloc)))
        contextMenuItems.append((xbmc.getLocalizedString(13333), 'XBMC.RunPlugin(%s?mode=103&name=%s&url=%s)' % (sys.argv[0], sysname, sysloc)))
        contextMenuItems.append((xbmc.getLocalizedString(1210), 'XBMC.RunPlugin(%s?mode=101&name=%s&url=%s)' % (sys.argv[0], sysname, sysloc)))
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok=True
    iconimage = logoPath+name+'.png'
    if genre == 'International': description = language(30311).encode("utf-8")
    elif genre == 'Eclectic': description = language(30312).encode("utf-8")
    elif genre == 'Rock': description = language(30313).encode("utf-8")
    elif genre == 'Greek': description = language(30314).encode("utf-8")
    elif genre == 'Laika': description = language(30315).encode("utf-8")
    elif genre == 'Sports': description = language(30316).encode("utf-8")
    elif genre == 'News': description = language(30317).encode("utf-8")
    elif genre == '': description = ''
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="music", infoLabels={ "Title": name, "Label": name, "Album": name+' '+band, "Genre": genre, "Duration": "24h" } )
    liz.setProperty("IsPlayable", "true")
    liz.setProperty( "music", "true" )
    liz.setProperty( "Album_Label", location )
    liz.setProperty( "Album_Description", description )
    liz.setProperty( "Fanart_Image", random.choice([fanart1, fanart2]) )
    liz.addContextMenuItems(contextMenuItems)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

def resolve_radios(url):
    ok=True
    xbmc.executebuiltin("xbmc.PlayerControl(RepeatAll)")
    item = xbmcgui.ListItem(path=url)
    url = xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
    return ok


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?','')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


params = get_params()
url = None
name = None
mode = None
try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass


if mode==None or url==None or len(url)<1:
    get_categories()

elif mode==0:
    resolve_radios(url)
	
elif mode==1:
    get_favourites()
	
elif mode==2:
    get_radios('2','','')
	
elif mode==11:
    get_radios('11','','')
	
elif mode==12:
    get_radios('12','','')
	
elif mode==13:
    get_radios('13','','')
	
elif mode==14:
    get_radios('14','','')
	
elif mode==15:
    get_radios('15','','')
	
elif mode==16:
    get_radios('16','','')
	
elif mode==17:
    get_radios('17','','')
	
elif mode==21:
    get_radios('21','','')
	
elif mode == 100:
    add_favourite_item(name,url)

elif mode == 101:
    delete_favourite_item(name,url)
	
elif mode == 102:
    move_favourite_item(name,url,'favup')

elif mode == 103:
    move_favourite_item(name,url,'favdown')

xbmcplugin.endOfDirectory(int(sys.argv[1]))
