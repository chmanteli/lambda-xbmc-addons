# -*- coding: utf-8 -*-

'''
    hellenic radio XBMC Addon
    Copyright (C) 2012 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib,urllib2,re,os,xbmcplugin,xbmcgui,xbmcaddon
import random


settings = xbmcaddon.Addon(id='plugin.audio.hellenic.radio')
data = 'special://profile/addon_data/plugin.audio.hellenic.radio'

home = settings.getAddonInfo('path')
language = settings.getLocalizedString
addonname = settings.getAddonInfo("name")
icon = xbmc.translatePath(os.path.join(home,'icon.png'))
fanart1 = xbmc.translatePath(os.path.join(home,'resources/fanart/1.jpg'))
fanart2 = xbmc.translatePath(os.path.join(home,'resources/fanart/2.jpg'))
artPath = xbmc.translatePath(os.path.join(home,'resources/art/'))
logoPath = xbmc.translatePath(os.path.join(home,'resources/logos/'))
favPath = xbmc.translatePath(os.path.join(data,'favourites.cfg'))
dataPath = xbmc.translatePath(data)
skin = xbmc.getSkinDir()

xbmcplugin.setContent(int(sys.argv[1]), 'Albums')


def check_addon(id):
    try:
        check_addon = xbmcaddon.Addon(id=id).getAddonInfo("name")
        if not check_addon == addonname:
            return check_addon
        else:
            return
    except:
        return

def playercorecheck():
    rule = '<rule audio="true" protocols="rtmp" player="dvdplayer"/>'
    playercorefile = xbmc.translatePath('special://masterprofile/playercorefactory.xml')
    playercorebackup = xbmc.translatePath('special://masterprofile/playercorefactory.xml.bak')

    try:
        read = open(playercorefile, 'r')
        text = read.read()
        read.close()
    except:
        text = ''
        pass

    if not text.find(rule) == -1:
        return
    else:
        retval = xbmcgui.Dialog().yesno(addonname, language(30221).encode("utf-8"), language(30222).encode("utf-8"))

    if not retval:
        return

    if not os.path.isfile(playercorefile):
        text = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<playercorefactory>\n<rules action="prepend">\n'+rule+'\n</rules>\n</playercorefactory>'
        write = open(playercorefile,'w+')
        write.write(text)
        write.close()
        retval = xbmcgui.Dialog().yesno(addonname, language(30223).encode("utf-8"), language(30224).encode("utf-8"))
        if retval: xbmc.executebuiltin("Quit()")
        return

    text = text.replace('<rules action="overwrite">','<rules action="overwrite">\n'+rule)
    text = text.replace('<rules action="prepend">','<rules action="prepend">\n'+rule)
    text = text.replace('<rules action="append">','<rules action="append">\n'+rule)
    if not text.find(rule) == -1:
        os.rename(playercorefile, playercorebackup)
        write = open(playercorefile,'w+')
        write.write(text)
        write.close()
        retval = xbmcgui.Dialog().yesno(addonname, language(30223).encode("utf-8"), language(30224).encode("utf-8"))
        if retval: xbmc.executebuiltin("Quit()")
        return

    text = text.replace('<playercorefactory>','<playercorefactory>\n<rules action="prepend">\n'+rule+'\n</rules>')
    if not text.find(rule) == -1:
        os.rename(playercorefile, playercorebackup)
        write = open(playercorefile,'w+')
        write.write(text)
        write.close()
        retval = xbmcgui.Dialog().yesno(addonname, language(30223).encode("utf-8"), language(30224).encode("utf-8"))
        if retval: xbmc.executebuiltin("Quit()")
        return

    text += '<playercorefactory>\n<rules action="prepend">\n'+rule+'\n</rules>\n</playercorefactory>'
    if not text.find(rule) == -1:
        os.rename(playercorefile, playercorebackup)
        write = open(playercorefile,'w+')
        write.write(text)
        write.close()
        retval = xbmcgui.Dialog().yesno(addonname, language(30223).encode("utf-8"), language(30224).encode("utf-8"))
        if retval: xbmc.executebuiltin("Quit()")
        return
    return

def xbmc_notify(type):
    if type == 'favadd':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30201).encode("utf-8")))
    elif type == 'favrem':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30202).encode("utf-8")))
    elif type == 'favup':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30203).encode("utf-8")))
    elif type == 'favdown':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30204).encode("utf-8")))

def xbmc_refresh():
    xbmc.executebuiltin("Container.Refresh")

def xbmc_view():
    viewenable = settings.getSetting("viewenable")

    if (skin == 'skin.confluence' or skin == 'skin.confluence.svn') and viewenable == 'true':
        confluence_views = [50,51,500,509,506,513]
        view = int(settings.getSetting("confluence"))
        xbmc.executebuiltin("Container.SetViewMode("+str(confluence_views[view])+")")

    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn') and viewenable == 'true':
        rapier_views = [50,63,52,77,62,67,96,98,64,70]
        view = int(settings.getSetting("rapier"))
        xbmc.executebuiltin("Container.SetViewMode("+str(rapier_views[view])+")")

def xbmc_data():
    if not os.path.exists(dataPath):
        os.makedirs(dataPath)
    if not os.path.isfile(favPath):
        read = open(favPath, 'w')
        read.write('')
        read.close()
		
def add_favourite_item(name,url):
    xbmc_refresh()
    read = open(favPath, 'a+')
    read.write('"'+name+'"|"'+url+'"\n')
    read.close()
    xbmc_notify('favadd')

def delete_favourite_item(name,url):
    xbmc_refresh()
    read = open(favPath, 'r')
    text = read.read().replace('"'+name+'"|"'+url+'"','')
    read.close()
    read = open(favPath, 'w')
    for line in re.compile('"(.+?)\n').findall(text):
        read.write('"'+line+'\n')
    read.close()
    xbmc_notify('favrem')

def move_favourite_item(name,url,type):
    xbmc_refresh()
    replaced = []
    j = []
    i = 0
    f = open(favPath,'r')
    for line in f:
        if re.search('"'+name.replace('?','[?]')+'"',line) is not None:
            j = i
        i = i+1
    f.close()
    if type == 'favup':
        i = 1
    if type == 'favdown':
        i = -1
    f = open(favPath,'r')
    for line in f:
        if i == j:
            replaced = line
        i = i+1
    f.close()

    if not replaced == []:
        read = open(favPath, 'r')
        text = read.read()
        if type == 'favup':
            text = text.replace(replaced+'"'+name+'"|"'+url+'"','"'+name+'"|"'+url+'"'+replaced)
            text = text.replace('\n','')
        if type == 'favdown':
            text = text.replace('"'+name+'"|"'+url+'"\n'+replaced,replaced+'"'+name+'"|"'+url+'"')
            text = text.replace('\n','')
        read.close()
        read = open(favPath, 'w')
        for name,cid in re.compile('"(.+?)"[|]"(.+?)"').findall(text):
            read.write('"'+name+'"|"'+cid+'"\n')
        if type == 'favup':
            xbmc_notify('favup')
        if type == 'favdown':
            xbmc_notify('favdown')
	    read.close()

def get_favourites():
    xbmc_data()
    read = open(favPath, 'r')
    text = read.read()
    read.close()
    for favname,favlocation in re.compile('"(.+?)"[|]"(.+?)"').findall(text):
        get_radios('1',favname,favlocation)
    xbmc_view()

def get_categories():
    xbmc_data()
    add_categories(language(30501).encode("utf-8"),language(30601).encode("utf-8"),1,artPath+'01.png')
    add_categories(language(30502).encode("utf-8"),language(30602).encode("utf-8"),2,artPath+'02.png')
    add_categories(language(30511).encode("utf-8"),language(30611).encode("utf-8"),11,artPath+'03.png')
    add_categories(language(30512).encode("utf-8"),language(30612).encode("utf-8"),12,artPath+'04.png')
    add_categories(language(30513).encode("utf-8"),language(30613).encode("utf-8"),13,artPath+'05.png')
    add_categories(language(30514).encode("utf-8"),language(30614).encode("utf-8"),14,artPath+'06.png')
    add_categories(language(30515).encode("utf-8"),language(30615).encode("utf-8"),15,artPath+'07.png')
    add_categories(language(30516).encode("utf-8"),language(30616).encode("utf-8"),16,artPath+'08.png')
    add_categories(language(30517).encode("utf-8"),language(30617).encode("utf-8"),17,artPath+'09.png')
    add_categories(language(30518).encode("utf-8"),language(30618).encode("utf-8"),18,artPath+'10.png')
    add_categories(language(30519).encode("utf-8"),language(30619).encode("utf-8"),19,artPath+'11.png')
    add_categories(language(30521).encode("utf-8"),language(30621).encode("utf-8"),21,artPath+'12.png')
    add_categories(language(30522).encode("utf-8"),language(30622).encode("utf-8"),22,artPath+'13.png')
    xbmc_view()

def add_categories(name,description,mode,iconimage):
    sysurl = urllib.quote_plus('http://www.google.gr')
    contextMenuItems = []
    u = '%s?url=%s&mode=%s' % (sys.argv[0], sysurl, str(mode))
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    item.setInfo( type="music", infoLabels={ "Title": name, "Label": name, "Album": name } )
    item.setProperty( "Album_Description", description )
    item.setProperty( "Fanart_Image", random.choice([fanart1, fanart2]) )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,isFolder=True)

def get_radios(type,favname=None,favlocation=None):
    if not type == '1':
        xbmc_data()



    name = '98Fm'
    band = '93,8'
    genre = 'Eclectic'
    location = 'Attica'
    base = 'http://radio98fm.org/'
    url = 'http://98fm.ath.cx:8000/live128'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = '902 Fm'
    band = '90,1'
    genre = 'News'
    location = 'Attica'
    base = 'http://www.902.gr/'
    url = 'http://icecast.902.gr:8000/902'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Alpha Radio'
    band = '98,9'
    genre = 'News'
    location = 'Attica'
    base = 'http://www.alpha989.com'
    url = 'rtmp://cp70860.live.edgefcs.net/live playpath=radio9@35654 live=true timeout=10'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'ART Fm'
    band = '90,6'
    genre = 'News'
    location = 'Attica'
    base = 'http://www.radioasty.gr/'
    url = 'http://shoutcast.24radio.gr:8080/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Athens DeeJay'
    band = '95,2'
    genre = 'International'
    location = 'Attica'
    base = 'http://www.athensdeejay.gr/'
    url = 'http://91.132.6.21:8001/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Athina 984'
    band = '98,3'
    genre = 'News'
    location = 'Attica'
    base = 'http://www.athina984.gr/'
    url = 'rtmp://cp91386.live.edgefcs.net:80/live playpath=ATHENS984FLASH@20490 live=true timeout=10'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Atlantis'
    band = '105,2'
    genre = 'Rock'
    location = 'Attica'
    base = 'http://www.atlantisfm.gr/'
    url = 'http://46.4.73.140:8046/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Best'
    band = '92,6'
    genre = 'Eclectic'
    location = 'Attica'
    base = 'http://www.bestradio.gr/'
    url = 'mms://best.live24.gr/best1222'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Derti'
    band = '98,6'
    genre = 'Laika'
    location = 'Attica'
    base = 'http://www.derti.gr/'
    url = 'mms://derti.live24.gr/derty1000'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Diesi'
    band = '101,3'
    genre = 'Eclectic'
    location = 'Attica'
    base = 'http://www.diesi.gr/'
    url = 'mms://diesi.live24.gr/diesi1013'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Dromos'
    band = '89,8'
    genre = 'Greek'
    location = 'Attica'
    base = 'http://www.dromosfm.gr/'
    url = 'mms://dromos898.live24.gr/dromos898'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Easy'
    band = '97,2'
    genre = 'International'
    location = 'Attica'
    base = 'http://easy972.gr/'
    url = 'mms://ant1.live24.gr/ant1'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'En Lefko'
    band = '87,7'
    genre = 'Eclectic'
    location = 'Attica'
    base = 'http://enlefko.fm/'
    url = 'mms://enleuko.live24.gr/enleuko877'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Epikoinonia'
    band = '94,0'
    genre = 'News'
    location = 'Attica'
    base = 'http://www.94fm.gr/'
    url = 'http://radio.94fm.gr:8280/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'ERA 2'
    band = '102,9'
    genre = 'Eclectic'
    location = 'Attica'
    base = 'http://www.ert.gr/deytero/'
    url = 'mms://a1782.l3271951781.c32719.g.lm.akamaistream.net/D/1782/32719/v0001/reflector:51781'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'ERA 3'
    band = '90,9'
    genre = 'Eclectic'
    location = 'Attica'
    base = 'http://www.ert.gr/trito/'
    url = 'mms://a1318.l3271931317.c32719.g.lm.akamaistream.net/D/1318/32719/v0001/reflector:31317'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'ERA Filia'
    band = '106,7'
    genre = 'News'
    location = 'Attica'
    base = 'http://tvradio.ert.gr/radio/index.asp?id=18'
    url = 'mms://a1367.l3271923366.c32719.g.lm.akamaistream.net/D/1367/32719/v0001/reflector:23366'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'ERA Kosmos'
    band = '93,6'
    genre = 'Eclectic'
    location = 'Attica'
    base = 'http://www.ert.gr/kosmos936/'
    url = 'mms://a1232.l3271935231.c32719.g.lm.akamaistream.net/D/1232/32719/v0001/reflector:35231'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'ERA NET'
    band = '105,8'
    genre = 'News'
    location = 'Attica'
    base = 'http://tvradio.ert.gr/radio/index.asp?id=6'
    url = 'mms://a1709.l3271943708.c32719.g.lm.akamaistream.net/D/1709/32719/v0001/reflector:43708'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'ERA Sport'
    band = '101,8'
    genre = 'Sports'
    location = 'Attica'
    base = 'http://tvradio.ert.gr/radio/index.asp?id=3'
    url = 'mms://a1113.l3271935112.c32719.g.lm.akamaistream.net/D/1113/32719/v0001/reflector:35112'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Flash'
    band = '96,0'
    genre = 'News'
    location = 'Attica'
    base = 'http://www.flash.gr/'
    url = 'mms://flash.live24.gr/flash5252'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Freedom Fm'
    band = '88,9'
    genre = 'Rock'
    location = 'Attica'
    base = 'http://www.freedomfm.gr/'
    url = 'rtmp://cp185989.live.edgefcs.net:1935/live/ playpath=FreedomFM@81531 live=true timeout=10'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Galaxy'
    band = '92,0'
    genre = 'International'
    location = 'Attica'
    base = 'http://www.galaxy92.gr/'
    url = 'mms://galaxy.live24.gr/galaxy9292'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Hot Fm'
    band = '104,6'
    genre = 'International'
    location = 'Attica'
    base = 'http://www.hotfm1046.gr/'
    url = 'http://hotfm.live24.gr/shock'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Kanali 1'
    band = '90,4'
    genre = 'News'
    location = 'Attica'
    base = 'http://kanaliena.gr/'
    url = 'rtmp://cp126709.live.edgefcs.net:443/live/ playpath=radio1@25681 live=true timeout=10'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Kiss Fm'
    band = '92,9'
    genre = 'International'
    location = 'Attica'
    base = 'http://www.kiss.gr/'
    url = 'mms://kissfm.live24.gr/kiss2111'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Lampsi Fm'
    band = '92,3'
    genre = 'Greek'
    location = 'Attica'
    base = 'http://www.lampsifm.com/'
    url = 'http://91.132.6.21:8005/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Love Radio'
    band = '97,5'
    genre = 'Eclectic'
    location = 'Attica'
    base = 'http://www.loveradio.gr/'
    url = 'mms://loveradio.live24.gr/loveradio-1000'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Mad Radio'
    band = '106,2'
    genre = 'International'
    location = 'Attica'
    base = 'http://www.mad.gr/madradio/'
    url = 'plugin://plugin.video.youtube/?action=play_video&videoid=7CMdx8xCloY'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Melodia'
    band = '99,2'
    genre = 'Eclectic'
    location = 'Attica'
    base = 'http://www.melodia.gr/'
    url = 'rtmp://cp121670.live.edgefcs.net/live/ playpath=melodia@52591 live=true timeout=10'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Music'
    band = '89,2'
    genre = 'International'
    location = 'Attica'
    base = 'http://www.music892.gr/'
    url = 'mms://a714.l649552713.c6495.g.lm.akamaistream.net/D/714/6495/v0001/reflector:52713'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Nitro Radio'
    band = '102,5'
    genre = 'International'
    location = 'Attica'
    base = 'http://www.nitroradio.gr/'
    url = 'mms://nitro.live24.gr/nitro4555'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Nova Sport Fm'
    band = '94,6'
    genre = 'Sports'
    location = 'Attica'
    base = 'http://www.sport-fm.gr/'
    url = 'mms://sportfm.live24.gr/sportfm7712'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'NRJ Athens'
    band = '88,6'
    genre = 'International'
    location = 'Attica'
    base = 'http://nrjradio.gr/'
    url = 'http://149.5.240.22/WR-GR-WR71?1351645828220.mp3'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Oasis Fm'
    band = '88,0'
    genre = 'Laika'
    location = 'Attica'
    base = 'http://www.oasisfm.gr/'
    url = 'mms://oasis.live24.gr/oasis8888'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Orange'
    band = '93,2'
    genre = 'International'
    location = 'Attica'
    url = 'mms://orange.live24.gr/orange9320'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Parea Fm'
    band = '104,0'
    genre = 'Greek'
    location = 'Attica'
    base = 'http://www.pareafm.gr/'
    url = 'mms://parea104.live24.gr/parea104'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Pepper'
    band = '96,6'
    genre = 'Eclectic'
    location = 'Attica'
    base = 'http://radiopepper.gr/'
    url = 'mms://captainjack.live24.gr/captainjack9660'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Piraeus Church'
    band = '91,2'
    genre = 'Religious'
    location = 'Attica'
    base = 'http://www.pe912fm.com/'
    url = 'http://eco.caststream.net:8044/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Real Fm'
    band = '97,8'
    genre = 'News'
    location = 'Attica'
    base = 'http://www.real.gr/'
    url = 'mms://realfm.live24.gr/realfm'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Red'
    band = '96,3'
    genre = 'Rock'
    location = 'Attica'
    base = 'http://www.redfm.gr/'
    url = 'rtmp://cp138550.live.edgefcs.net/live/ playpath=red_flash@11536 live=true timeout=10'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Rock Fm'
    band = '96,9'
    genre = 'Rock'
    location = 'Attica'
    base = 'http://www.rockfm.gr/'
    url = 'http://91.132.6.21:8003/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Rythmos'
    band = '94,9'
    genre = 'Greek'
    location = 'Attica'
    base = 'http://www.rythmosfm.gr/'
    url = 'mms://rythmos.live24.gr/rythmos'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Sentra Fm'
    band = '103,3'
    genre = 'Sports'
    location = 'Attica'
    base = 'http://www.sentragoal.gr/'
    url = 'mms://sentrafm.live24.gr/sentrafm'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Sfera'
    band = '102,2'
    genre = 'Greek'
    location = 'Attica'
    base = 'http://www.sfera.gr/'
    url = 'mms://sfera.live24.gr/sfera4132'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Skai Radio'
    band = '100,3'
    genre = 'News'
    location = 'Attica'
    base = 'http://www.skai.gr/1003/'
    url = 'rtmp://cp76153.live.edgefcs.net/live/ playpath=RADIO_LIVE_1@10774 swfUrl=http://www.skai.gr/Themes/1/Default/Media/Media_player/flowplayer-3.2.5.swf pageUrl=http://www.skai.gr/player/radiolive/ swfVfy=true live=true'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Sto Kokkino'
    band = '105,5'
    genre = 'News'
    location = 'Attica'
    base = 'http://stokokkino.gr/'
    url = 'http://stokokkino.gr:8000/stream'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'VFM'
    band = '88,3'
    genre = 'International'
    location = 'Attica'
    base = 'http://www.vfm883.gr/'
    url = 'mms://village883.live24.gr/village883'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Vima Fm'
    band = '99,5'
    genre = 'News'
    location = 'Attica'
    base = 'http://www.tovima.gr/vimafm/'
    url = 'mms://music.vimafm995.gr/vimafm'
    add_radios(name,url,type,band,genre,location,favname,favlocation)



    name = '1055 Rock'
    band = '105,5'
    genre = 'Rock'
    location = 'Salonica'
    base = 'http://www.1055rock.gr/'
    url = 'mms://m1.onweb.gr/1055Rock'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Acritans of Pontus'
    band = '102,3'
    genre = 'Traditional'
    location = 'Salonica'
    base = 'http://www.akritestoupontou.gr/'
    url = 'rtmp://46.137.92.58/live/ playpath=akritestoupontou.sdp live=true timeout=10'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'City International'
    band = '106,1'
    genre = 'News'
    location = 'Salonica'
    base = 'http://www.cityinternational.gr/'
    url = 'http://nyc04.egihosting.com/458378'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Cosmoradio'
    band = '95,1'
    genre = 'Greek'
    location = 'Salonica'
    base = 'http://www.cosmoradio.gr/'
    url = 'http://shout.cosmoradio.gr:8130/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Eroticos'
    band = '94,8'
    genre = 'Eclectic'
    location = 'Salonica'
    base = 'http://www.eroticos.gr/'
    url = 'http://178.32.72.192:8050/eroticos'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'ERT3 102'
    band = '102,0'
    genre = 'News'
    location = 'Salonica'
    base = 'http://www.ert3.gr/'
    url = 'mms://a1758.l3271933757.c32719.g.lm.akamaistream.net/D/1758/32719/v0001/reflector:33757'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'ERT3 958'
    band = '95,8'
    genre = 'Eclectic'
    location = 'Salonica'
    base = 'http://www.ert3.gr/'
    url = 'mms://a1964.l3271953963.c32719.g.lm.akamaistream.net/D/1964/32719/v0001/reflector:53963'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'FM 100'
    band = '100,0'
    genre = 'News'
    location = 'Salonica'
    base = 'http://www.fm100.gr/'
    url = 'http://eco.caststream.net:8038/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Imagine'
    band = '89,7'
    genre = 'Eclectic'
    location = 'Salonica'
    base = 'http://www.imagine897.gr/'
    url = 'http://imagine.1stepstream.com:8000/aac'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Kalamaria Fm'
    band = '101,7'
    genre = 'Laika'
    location = 'Salonica'
    base = 'http://www.kalamariafm.gr/'
    url = 'mms://wm3.greekstream.net/kalamariafm'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Laikos'
    band = '87,6'
    genre = 'Laika'
    location = 'Salonica'
    base = 'http://www.laikos.gr/'
    url = 'http://iphone.live24.gr/laikos876'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Libero'
    band = '107,4'
    genre = 'Sports'
    location = 'Salonica'
    base = 'http://www..libero.fm/'
    url = 'http://eco.onestreaming.com:8081/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Metropolis'
    band = '95,5'
    genre = 'Sports'
    location = 'Salonica'
    base = 'http://www.metropolisradiogr.com/'
    url = 'http://streamx1.greekradios.gr:8000/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Mousikos Galaxias'
    band = '105,8'
    genre = 'Laika'
    location = 'Salonica'
    base = 'http://www.g-radio.gr/radio/'
    url = 'http://188.165.229.150:10966/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Ola Fm'
    band = '91,4'
    genre = 'Greek'
    location = 'Salonica'
    base = 'http://www.olafm.gr/'
    url = 'http://ola.isolservers.com:8300/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Palmos'
    band = '96,5'
    genre = 'Greek'
    location = 'Salonica'
    base = 'http://www.palmos965.gr/'
    url = 'mms://a1202.l7083147201.c70831.g.lm.akamaistream.net/D/1202/70831/v0001/reflector:47201'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Plus Radio'
    band = '102,6'
    genre = 'International'
    location = 'Salonica'
    base = 'http://www.plusradio.gr/'
    url = 'http://94.177.122.248:8120/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Radio 1'
    band = '99,0'
    genre = 'Greek'
    location = 'Salonica'
    base = 'http://www.99fm.gr/'
    url = 'http://eco.onestreaming.com:8336/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Radio Ekfrasi'
    band = '92,4'
    genre = 'Eclectic'
    location = 'Salonica'
    base = 'http://www.fm-ekfrasi.gr/'
    url = 'http://sc2.greekstream.net:4012/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Radio Gnomi'
    band = '93,7'
    genre = 'News'
    location = 'Salonica'
    base = 'http://www.gnominet.gr/'
    url = 'http://sc2.greekstream.net:4040/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Radio Thessaloniki'
    band = '94,5'
    genre = 'News'
    location = 'Salonica'
    base = 'http://www.rthess.gr/'
    url = 'http://178.32.72.192:8060/rthes'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Radiokymata'
    band = '104,4'
    genre = 'Greek'
    location = 'Salonica'
    base = 'http://www.radiokymata.gr/'
    url = 'http://s1.onweb.gr:8812/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Rainbow'
    band = '89,0'
    genre = 'Rock'
    location = 'Salonica'
    base = 'http://www.89rainbow.gr/'
    url = 'http://stream.greekradios.gr:4000/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Republic'
    band = '100,3'
    genre = 'International'
    location = 'Salonica'
    base = 'http://www.republicradio.gr/'
    url = 'http://streamx2.greekradios.gr:8000/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Rock Radio'
    band = '104,7'
    genre = 'Rock'
    location = 'Salonica'
    base = 'http://www.rockradio.gr/'
    url = 'http://rockradio.gr:1111/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'RSO'
    band = '91,7'
    genre = 'International'
    location = 'Salonica'
    base = 'http://www.rso.gr/'
    url = 'http://rso.isolservers.com:8200/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Sport 103'
    band = '103,0'
    genre = 'Sports'
    location = 'Salonica'
    base = 'http://www.sport103.gr/'
    url = 'mms://golive.onestreaming.com/sport103'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Studio 3'
    band = '103,6'
    genre = 'Traditional'
    location = 'Salonica'
    base = 'http://www.studio3.gr/'
    url = 'http://s1.onweb.gr:8408/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Sunshine'
    band = '107,7'
    genre = 'Eclectic'
    location = 'Salonica'
    base = 'http://www.facebook.com/1077sunshine'
    url = 'http://eco.onestreaming.com:8083/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Thessaloniki DeeJay'
    band = '89,4'
    genre = 'International'
    location = 'Salonica'
    base = 'http://www.athensdeejay.gr/'
    url = 'http://91.132.6.21:8001/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Velvet'
    band = '96,8'
    genre = 'Eclectic'
    location = 'Salonica'
    base = 'http://www.velvet968.gr/'
    url = 'http://stream.greekradios.gr:2042/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Venus'
    band = '91,1'
    genre = 'International'
    location = 'Salonica'
    base = 'http://www.911.gr/'
    url = 'http://stream.myip.gr:8054/'
    add_radios(name,url,type,band,genre,location,favname,favlocation)

    name = 'Zoo Radio'
    band = '90,8'
    genre = 'International'
    location = 'Salonica'
    base = 'http://www.zooradio.gr/'
    url = 'http://188.138.121.94:8004'
    add_radios(name,url,type,band,genre,location,favname,favlocation)



    if not type == '1':
        xbmc_view()

def add_radios(name,url,type,band,genre,location,favname,favlocation):
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    sysloc = urllib.quote_plus(location)

    if (type == '2') \
    or (type == '11' and genre == 'International') \
    or (type == '12' and genre == 'Eclectic') \
    or (type == '13' and genre == 'Rock') \
    or (type == '14' and genre == 'Greek') \
    or (type == '15' and genre == 'Laika') \
    or (type == '16' and genre == 'Sports') \
    or (type == '17' and genre == 'News') \
    or (type == '18' and genre == 'Religious') \
    or (type == '19' and genre == 'Traditional') \
    or (type == '21' and location == 'Attica') \
    or (type == '22' and location == 'Salonica') \
	or (type == '1' and name == favname and location == favlocation):
        pass
    else:
        return

    if genre == 'International':
        description = language(30711).encode("utf-8")
    elif genre == 'Eclectic':
        description = language(30712).encode("utf-8")
    elif genre == 'Rock':
        description = language(30713).encode("utf-8")
    elif genre == 'Greek':
        description = language(30714).encode("utf-8")
    elif genre == 'Laika':
        description = language(30715).encode("utf-8")
    elif genre == 'Sports':
        description = language(30716).encode("utf-8")
    elif genre == 'News':
        description = language(30717).encode("utf-8")
    elif genre == 'Religious':
        description = language(30718).encode("utf-8")
    elif genre == 'Traditional':
        description = language(30719).encode("utf-8")
    elif genre == '':
        description = ''

    iconimage = '%s%s/%s.png' % (logoPath, location, name)

    contextMenuItems = []
    if not type == '1':
        read = open(favPath, 'r')
        text = read.read()
        read.close()
        favourite = '"'+name+'"|"'+location+'"'
        if not favourite in text: contextMenuItems.append((language(30205).encode("utf-8"), 'XBMC.RunPlugin(%s?mode=100&name=%s&url=%s)' % (sys.argv[0], sysname, sysloc)))
        else: contextMenuItems.append((language(30206).encode("utf-8"), 'XBMC.RunPlugin(%s?mode=101&name=%s&url=%s)' % (sys.argv[0], sysname, sysloc)))
    if type == '1':
        contextMenuItems.append((xbmc.getLocalizedString(13332), 'XBMC.RunPlugin(%s?mode=102&name=%s&url=%s)' % (sys.argv[0], sysname, sysloc)))
        contextMenuItems.append((xbmc.getLocalizedString(13333), 'XBMC.RunPlugin(%s?mode=103&name=%s&url=%s)' % (sys.argv[0], sysname, sysloc)))
        contextMenuItems.append((xbmc.getLocalizedString(1210), 'XBMC.RunPlugin(%s?mode=101&name=%s&url=%s)' % (sys.argv[0], sysname, sysloc)))

    u = '%s?url=%s&mode=0' % (sys.argv[0], sysurl)
    item=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    item.setInfo( type="music", infoLabels={ "Title": name, "Label": name, "Album": name, "Artist": band, "Genre": genre, "Comment": description, "Duration": "1440" } )
    item.setProperty("IsPlayable", "true")
    item.setProperty( "music", "true" )
    item.setProperty( "Album_Label", location )
    item.setProperty( "Album_Description", description )
    item.setProperty( "Fanart_Image", random.choice([fanart1, fanart2]) )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,isFolder=False)

def resolve_radios(url):
    if url.startswith('rtmp://'):
        playercorecheck()
    if url.startswith('plugin://plugin.video.youtube/') and check_addon('plugin.video.youtube') is None:
        xbmcgui.Dialog().ok(addonname, language(30211).encode("utf-8"), language(30212).encode("utf-8"))
        xbmc.PlayList(xbmc.PLAYLIST_MUSIC).clear()
        return
    xbmc.PlayList(xbmc.PLAYLIST_MUSIC).clear()
    item = xbmcgui.ListItem(path=url)
    return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?','')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


params = get_params()
url = None
name = None
mode = None
try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass


if mode==None or url==None or len(url)<1:
    get_categories()

elif mode==0:
    resolve_radios(url)
	
elif mode==1:
    get_favourites()
	
elif mode==2:
    get_radios('2')
	
elif mode==11:
    get_radios('11')
	
elif mode==12:
    get_radios('12')
	
elif mode==13:
    get_radios('13')
	
elif mode==14:
    get_radios('14')
	
elif mode==15:
    get_radios('15')
	
elif mode==16:
    get_radios('16')
	
elif mode==17:
    get_radios('17')

elif mode==18:
    get_radios('18')

elif mode==19:
    get_radios('19')
	
elif mode==21:
    get_radios('21')

elif mode==22:
    get_radios('22')
	
elif mode == 100:
    add_favourite_item(name,url)

elif mode == 101:
    delete_favourite_item(name,url)
	
elif mode == 102:
    move_favourite_item(name,url,'favup')

elif mode == 103:
    move_favourite_item(name,url,'favdown')

xbmcplugin.endOfDirectory(int(sys.argv[1]))
