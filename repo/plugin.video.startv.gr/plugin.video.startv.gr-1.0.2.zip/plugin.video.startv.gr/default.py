# -*- coding: utf-8 -*-

'''
    star webtv XBMC Addon
    Copyright (C) 2012 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib,urllib2,re,os,xbmcplugin,xbmcgui,xbmcaddon


settings = xbmcaddon.Addon(id='plugin.video.startv.gr')
data = 'special://profile/addon_data/plugin.video.startv.gr'

home = settings.getAddonInfo('path')
language = settings.getLocalizedString
addonname = settings.getAddonInfo("name")
description = language(30505).encode("utf-8")
icon = xbmc.translatePath(os.path.join(home,'icon.png'))
fanart = xbmc.translatePath(os.path.join(home,'fanart.jpg'))
artPath = xbmc.translatePath(os.path.join(home,'resources/art/'))
favPath = xbmc.translatePath(os.path.join(data,'favourites.cfg'))
dataPath = xbmc.translatePath(data)
skin = xbmc.getSkinDir()

xbmcplugin.setContent(int(sys.argv[1]), 'Episodes')
xbmcplugin.setPluginFanart(int(sys.argv[1]), fanart)

try:
    import StorageServer
    cache = StorageServer.StorageServer(addonname,720)
except:
    import storageserverdummy as StorageServer
    cache = StorageServer.StorageServer(addonname,720)

try:
    import CommonFunctions
    common = CommonFunctions
except:
    import commonfunctionsdummy as CommonFunctions
    common = CommonFunctions



base_url = 'http://www.youtube.com'
channel_url = 'http://www.youtube.com/user/startvgr'
shows_url = 'http://www.youtube.com/user/startvgr/videos?view=1'
latest_url = 'http://www.youtube.com/playlist?list=UUwUNbp_4Y2Ry-asyerw2jew'
news_url = 'http://www.youtube.com/playlist?list=PLCB68F7D162CF8D79'


def xbmc_notify(type):
    if type == 'favadd':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30201).encode("utf-8")))
    elif type == 'favrem':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30202).encode("utf-8")))
    elif type == 'favup':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30203).encode("utf-8")))
    elif type == 'favdown':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30204).encode("utf-8")))

def xbmc_refresh():
    xbmc.executebuiltin("Container.Refresh")

def xbmc_view():
    viewenable = settings.getSetting("viewenable")

    if (skin == 'skin.confluence' or skin == 'skin.confluence.svn') and viewenable == 'true':
        confluence_views = [50,51,500,504,503,515]
        view = int(settings.getSetting("confluence"))
        xbmc.executebuiltin("Container.SetViewMode("+str(confluence_views[view])+")")

    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn') and viewenable == 'true':
        rapier_views = [50,52,74,73,68,94]
        view = int(settings.getSetting("rapier"))
        xbmc.executebuiltin("Container.SetViewMode("+str(rapier_views[view])+")")

def xbmc_data():
    if not os.path.exists(dataPath):
        os.makedirs(dataPath)
    if not os.path.isfile(favPath):
        read = open(favPath, 'w')
        read.write('')
        read.close()

def add_favourite_item(name,url):
    xbmc_refresh()
    read = open(favPath, 'a+')
    read.write('"'+name+'"|"'+url+'"\n')
    read.close()
    xbmc_notify('favadd')

def delete_favourite_item(name,url):
    xbmc_refresh()
    read = open(favPath, 'r')
    text = read.read().replace('"'+name+'"|"'+url+'"','')
    read.close()
    read = open(favPath, 'w')
    for line in re.compile('"(.+?)\n').findall(text):
        read.write('"'+line+'\n')
    read.close()
    xbmc_notify('favrem')

def move_favourite_item(name,url,type):
    xbmc_refresh()
    replaced = []
    j = []
    i = 0
    f = open(favPath,'r')
    for line in f:
        if re.search('"'+url.replace('?','[?]')+'"',line) is not None:
            j = i
        i = i+1
    f.close()
    if type == 'favup':
        i = 1
    if type == 'favdown':
        i = -1
    f = open(favPath,'r')
    for line in f:
        if i == j:
            replaced = line
        i = i+1
    f.close()

    if not replaced == []:
        read = open(favPath, 'r')
        text = read.read()
        if type == 'favup':
            text = text.replace(replaced+'"'+name+'"|"'+url+'"','"'+name+'"|"'+url+'"'+replaced)
            text = text.replace('\n','')
        if type == 'favdown':
            text = text.replace('"'+name+'"|"'+url+'"\n'+replaced,replaced+'"'+name+'"|"'+url+'"')
            text = text.replace('\n','')
        read.close()
        read = open(favPath, 'w')
        for name,cid in re.compile('"(.+?)"[|]"(.+?)"').findall(text):
            read.write('"'+name+'"|"'+cid+'"\n')
        if type == 'favup':
            xbmc_notify('favup')
        if type == 'favdown':
            xbmc_notify('favdown')
	    read.close()

def get_favourites():
    xbmc_data()
    read = open(favPath, 'r')
    text = read.read()
    read.close()
    list = re.compile('"(.+?)"[|]"(.+?)"').findall(text)
    total = len(list)
    for name,url in list:
        iconimage = artPath+'favorites.png'
        try:
            iconimage = cache.cacheFunction(get_episodes, url,'iconimage')
            #iconimage = get_episodes(url,'iconimage')
        except:
            pass
        add_favourites(total,name,url,400,iconimage)
    xbmc_view()

def add_favourites(total,name,url,mode,iconimage):
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    contextMenuItems = []
    contextMenuItems.append((xbmc.getLocalizedString(13332), 'XBMC.RunPlugin(%s?mode=102&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    contextMenuItems.append((xbmc.getLocalizedString(13333), 'XBMC.RunPlugin(%s?mode=103&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    contextMenuItems.append((xbmc.getLocalizedString(1210), 'XBMC.RunPlugin(%s?mode=101&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    u = '%s?mode=%s&url=%s' % (sys.argv[0], str(mode), sysurl)
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        item.setProperty( "Fanart_Image", iconimage )
    else: item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)

def get_categories():
    xbmc_data()
    total = 4
    add_categories(total,language(30501).encode("utf-8"),base_url,200,artPath+'favorites.png')
    add_categories(total,language(30502).encode("utf-8"),base_url,300,artPath+'shows.png')
    try:
        iconimage = cache.cacheFunction(get_episodes, latest_url,'iconimage')
        add_categories(total,language(30503).encode("utf-8"),latest_url,400,iconimage)
    except:
        pass
    try:
        iconimage = cache.cacheFunction(get_episodes, news_url,'iconimage')
        add_categories(total,language(30504).encode("utf-8"),news_url,400,iconimage)
    except:
        pass
    xbmc_view()
    return

def add_categories(total,name,url,mode,iconimage):
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    contextMenuItems = []
    u = '%s?mode=%s&url=%s' % (sys.argv[0], str(mode), sysurl)
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        item.setProperty( "Fanart_Image", iconimage )
    else: item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)

def get_shows():
    xbmc_data()
    try:
        result = common.fetchPage({"link": shows_url})
        shows = common.parseDOM(result["content"], "li", attrs = { "class": "channels-content-item" })
        total = len(shows)
    except:
        return
    for show in shows:
        try:
            name = common.parseDOM(show, "a", attrs = { "class": "content-item-title" })[0]
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            iconimage = common.parseDOM(show, "img", ret="data-thumb")[0]
            iconimage = re.compile('.+?/vi/(.+?)/.+?').findall(iconimage)[0]
            iconimage = 'http://i.ytimg.com/vi/%s/0.jpg' % iconimage
            iconimage = iconimage.encode('utf-8')
            url = common.parseDOM(show, "a", attrs = { "class": "content-item-title" }, ret = "href")[0]
            url = base_url + url
            url = url.encode('utf-8')
            add_shows(total,name,url,400,iconimage)
        except:
            total = total - 1
            pass
    xbmc_view()
    return

def add_shows(total,name,url,mode,iconimage):
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    read = open(favPath, 'r')
    text = read.read()
    read.close()
    contextMenuItems = []
    if not url in text: contextMenuItems.append((xbmc.getLocalizedString(14076), 'XBMC.RunPlugin(%s?mode=100&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    else: contextMenuItems.append((xbmc.getLocalizedString(14077), 'XBMC.RunPlugin(%s?mode=101&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    u = '%s?mode=%s&url=%s' % (sys.argv[0], str(mode), sysurl)
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        item.setProperty( "Fanart_Image", iconimage )
    else: item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)

def get_episodes(url,type=None):
    xbmc_data()
    try:
        result = common.fetchPage({"link": url})
        episodes = common.parseDOM(result["content"], "li", attrs = { "class": "playlist-video-item.+?" })
        total = len(episodes)
    except:
        return
    for episode in episodes:
        try:
            name = common.parseDOM(episode, "span", attrs = { "class": "title video-title.+?" })[0]
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            videoid = common.parseDOM(episode, "button", ret="data-video-ids")[0]
            iconimage = 'http://i.ytimg.com/vi/%s/0.jpg' % videoid
            iconimage = iconimage.encode('utf-8')
            if type == 'iconimage': return iconimage
            url = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % videoid
            url = url.encode('utf-8')
            add_episodes(total,name,url,iconimage)
        except:
            total = total - 1
            pass
    xbmc_view()
    return

def add_episodes(total,name,url,iconimage):
    mode = 900
    sysurl = urllib.quote_plus(url)
    u = '%s?mode=%s&url=%s' % (sys.argv[0], str(mode), sysurl)
    contextMenuItems = []
    item = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    item.setProperty("IsPlayable", "true")
    item.setProperty( "Video", "true" )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        item.setProperty( "Fanart_Image", iconimage )
    else: item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)	
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total)

def resolve_episodes(url):
    item = xbmcgui.ListItem(path=url)
    return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?','')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


params = get_params()
url = None
name = None
mode = None
try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass


if mode == None or url == None or len(url) < 1:
    get_categories()

elif mode == 100:
    add_favourite_item(name,url)

elif mode == 101:
    delete_favourite_item(name,url)

elif mode == 102:
    move_favourite_item(name,url,'favup')

elif mode == 103:
    move_favourite_item(name,url,'favdown')

elif mode == 200:
    get_favourites()

elif mode == 300:
    get_shows()

elif mode == 400:
    get_episodes(url)

elif mode == 900:
    resolve_episodes(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
