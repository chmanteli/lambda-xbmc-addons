# -*- coding: utf-8 -*-

'''
    greek-movies XBMC Addon
    Copyright (C) 2012 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib,urllib2,re,os,xbmcplugin,xbmcgui,xbmcaddon
import urlresolver
import sets

settings = xbmcaddon.Addon(id='plugin.video.greek.movies.com')
data = 'special://profile/addon_data/plugin.video.greek.movies.com'

home = settings.getAddonInfo('path')
language = settings.getLocalizedString
addonname = settings.getAddonInfo("name")
description = language(30506).encode("utf-8")
icon = xbmc.translatePath(os.path.join(home,'icon.png'))
artPath = xbmc.translatePath(os.path.join(home,'resources/art/'))
poster = xbmc.translatePath(os.path.join(artPath,'poster.jpg'))
fanart = xbmc.translatePath(os.path.join(home,'fanart.jpg'))
favPath = xbmc.translatePath(os.path.join(data,'favourites.cfg'))
dataPath = xbmc.translatePath(data)
skin = xbmc.getSkinDir()

xbmcplugin.setContent(int(sys.argv[1]), 'Movies')
xbmcplugin.setPluginFanart(int(sys.argv[1]), fanart)

try:
    import StorageServer
    cache = StorageServer.StorageServer(addonname,720)
except:
    import storageserverdummy as StorageServer
    cache = StorageServer.StorageServer(addonname,720)

try:
    import CommonFunctions
    common = CommonFunctions
except:
    import commonfunctionsdummy as CommonFunctions
    common = CommonFunctions



base_url = 'http://greek-movies.com/'
movies_url = 'http://greek-movies.com/movies.php?'
short_movies_url = 'http://greek-movies.com/shortfilm.php?'


def unique_list(list):
    unique_set = sets.Set()
    unique_list = []
    for n in list:
        if n not in unique_set:
            unique_set.add(n)
            unique_list.append(n)
    return unique_list

def check_addon(id):
    try:
        check_addon = xbmcaddon.Addon(id=id).getAddonInfo("name")
        if not check_addon == addonname:
            return check_addon
        else:
            return
    except:
        return

def xbmc_notify(type):
    if type == 'favadd':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30201).encode("utf-8")))
    elif type == 'favrem':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30202).encode("utf-8")))
    elif type == 'favup':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30203).encode("utf-8")))
    elif type == 'favdown':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30204).encode("utf-8")))

def xbmc_refresh():
    xbmc.executebuiltin("Container.Refresh")

def xbmc_view(type):
    viewenable = settings.getSetting("viewenable")

    if (skin == 'skin.confluence' or skin == 'skin.confluence.svn') and viewenable == 'true':
        confluence_views = [50,51,500,501,508,504,503,515]
        if type == '1': view = int(settings.getSetting("confluence"))
        if type == '2': view = int(settings.getSetting("confluence2"))
        xbmc.executebuiltin("Container.SetViewMode("+str(confluence_views[view])+")")

    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn') and viewenable == 'true':
        rapier_views = [50,54,52,75,58,66,95,97,53,69]
        if type == '1': view = int(settings.getSetting("rapier"))
        if type == '2': view = int(settings.getSetting("rapier2"))
        xbmc.executebuiltin("Container.SetViewMode("+str(rapier_views[view])+")")

def xbmc_data():
    if not os.path.exists(dataPath):
        os.makedirs(dataPath)
    if not os.path.isfile(favPath):
        read = open(favPath, 'w')
        read.write('')
        read.close()

def add_favourite_item(name,url):
    xbmc_refresh()
    read = open(favPath, 'a+')
    read.write('"'+name+'"|"'+url+'"\n')
    read.close()
    xbmc_notify('favadd')

def delete_favourite_item(name,url):
    xbmc_refresh()
    read = open(favPath, 'r')
    text = read.read().replace('"'+name+'"|"'+url+'"','')
    read.close()
    read = open(favPath, 'w')
    for line in re.compile('"(.+?)\n').findall(text):
        read.write('"'+line+'\n')
    read.close()
    xbmc_notify('favrem')

def move_favourite_item(name,url,type):
    xbmc_refresh()
    replaced = []
    j = []
    i = 0
    f = open(favPath,'r')
    for line in f:
        if re.search('"'+url.replace('?','[?]')+'"',line) is not None:
            j = i
        i = i+1
    f.close()
    if type == 'favup':
        i = 1
    if type == 'favdown':
        i = -1
    f = open(favPath,'r')
    for line in f:
        if i == j:
            replaced = line
        i = i+1
    f.close()

    if not replaced == []:
        read = open(favPath, 'r')
        text = read.read()
        if type == 'favup':
            text = text.replace(replaced+'"'+name+'"|"'+url+'"','"'+name+'"|"'+url+'"'+replaced)
            text = text.replace('\n','')
        if type == 'favdown':
            text = text.replace('"'+name+'"|"'+url+'"\n'+replaced,replaced+'"'+name+'"|"'+url+'"')
            text = text.replace('\n','')
        read.close()
        read = open(favPath, 'w')
        for name,cid in re.compile('"(.+?)"[|]"(.+?)"').findall(text):
            read.write('"'+name+'"|"'+cid+'"\n')
        if type == 'favup':
            xbmc_notify('favup')
        if type == 'favdown':
            xbmc_notify('favdown')
	    read.close()

def get_favourites():
    xbmc_data()
    read = open(favPath, 'r')
    text = read.read()
    read.close()
    list = re.compile('"(.+?)"[|]"(.+?)"').findall(text)
    total = len(list)
    for name,url in list:
        iconimage = ''
        iconimage = cache.cacheFunction(get_iconimage, url)
        #iconimage = get_iconimage(url)
        add_favourites(total,name,url,600,iconimage)
    xbmc_view('2')

def add_favourites(total,name,url,mode,iconimage):
    sysiconimage = urllib.quote_plus(iconimage)
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    contextMenuItems = []
    contextMenuItems.append((xbmc.getLocalizedString(13332), 'XBMC.RunPlugin(%s?mode=102&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    contextMenuItems.append((xbmc.getLocalizedString(13333), 'XBMC.RunPlugin(%s?mode=103&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    contextMenuItems.append((xbmc.getLocalizedString(1210), 'XBMC.RunPlugin(%s?mode=101&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    u = '%s?mode=%s&name=%s&url=%s&iconimage=%s' % (sys.argv[0], str(mode), sysname, sysurl, sysiconimage)
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "Plot": description } )
    item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)

def get_categories():
    xbmc_data()
    total = 5
    add_categories(total,language(30501).encode("utf-8"),base_url,200,'0',poster)
    add_categories(total,language(30502).encode("utf-8"),base_url,300,'0',poster)
    add_categories(total,language(30503).encode("utf-8"),base_url,400,'0',poster)
    add_categories(total,language(30504).encode("utf-8"),base_url,500,'1',poster)
    add_categories(total,language(30505).encode("utf-8"),base_url,500,'2',poster)
    xbmc_view('1')
    return

def get_movie_categories():
    xbmc_data()
    total = 3
    add_categories(total,language(30511).encode("utf-8"),base_url,310,'0',poster)
    add_categories(total,language(30512).encode("utf-8"),base_url,320,'0',poster)
    add_categories(total,language(30513).encode("utf-8"),base_url,330,'0',poster)
    xbmc_view('1')
    return

def get_movies_sort():
    xbmc_data()
    total = 26
    add_categories(total,language(30521).encode("utf-8"),base_url,340,'1',poster)
    add_categories(total,language(30522).encode("utf-8"),base_url,340,'2',poster)
    add_categories(total,language(30523).encode("utf-8"),base_url,340,'3',poster)
    add_categories(total,language(30524).encode("utf-8"),base_url,340,'4',poster)
    add_categories(total,language(30525).encode("utf-8"),base_url,340,'5',poster)
    add_categories(total,language(30526).encode("utf-8"),base_url,340,'6',poster)
    add_categories(total,language(30527).encode("utf-8"),base_url,340,'7',poster)
    add_categories(total,language(30528).encode("utf-8"),base_url,340,'8',poster)
    add_categories(total,language(30529).encode("utf-8"),base_url,340,'9',poster)
    add_categories(total,language(30530).encode("utf-8"),base_url,340,'10',poster)
    add_categories(total,language(30531).encode("utf-8"),base_url,340,'11',poster)
    add_categories(total,language(30532).encode("utf-8"),base_url,340,'12',poster)
    add_categories(total,language(30533).encode("utf-8"),base_url,340,'13',poster)
    add_categories(total,language(30534).encode("utf-8"),base_url,340,'14',poster)
    add_categories(total,language(30535).encode("utf-8"),base_url,340,'15',poster)
    add_categories(total,language(30536).encode("utf-8"),base_url,340,'16',poster)
    add_categories(total,language(30537).encode("utf-8"),base_url,340,'17',poster)
    add_categories(total,language(30538).encode("utf-8"),base_url,340,'18',poster)
    add_categories(total,language(30539).encode("utf-8"),base_url,340,'19',poster)
    add_categories(total,language(30540).encode("utf-8"),base_url,340,'20',poster)
    add_categories(total,language(30541).encode("utf-8"),base_url,340,'21',poster)
    add_categories(total,language(30542).encode("utf-8"),base_url,340,'22',poster)
    add_categories(total,language(30543).encode("utf-8"),base_url,340,'23',poster)
    add_categories(total,language(30544).encode("utf-8"),base_url,340,'24',poster)
    add_categories(total,language(30545).encode("utf-8"),base_url,340,'25',poster)
    add_categories(total,language(30546).encode("utf-8"),base_url,340,'26',poster)
    xbmc_view('1')
    return

def get_movie_genres_sort():
    xbmc_data()
    total = 17
    add_categories(total,language(30551).encode("utf-8"),base_url,350,'1',poster)
    add_categories(total,language(30552).encode("utf-8"),base_url,350,'2',poster)
    add_categories(total,language(30553).encode("utf-8"),base_url,350,'3',poster)
    add_categories(total,language(30554).encode("utf-8"),base_url,350,'4',poster)
    add_categories(total,language(30555).encode("utf-8"),base_url,350,'5',poster)
    add_categories(total,language(30556).encode("utf-8"),base_url,350,'6',poster)
    add_categories(total,language(30557).encode("utf-8"),base_url,350,'7',poster)
    add_categories(total,language(30558).encode("utf-8"),base_url,350,'8',poster)
    add_categories(total,language(30559).encode("utf-8"),base_url,350,'9',poster)
    add_categories(total,language(30560).encode("utf-8"),base_url,350,'10',poster)
    add_categories(total,language(30561).encode("utf-8"),base_url,350,'11',poster)
    add_categories(total,language(30562).encode("utf-8"),base_url,350,'12',poster)
    add_categories(total,language(30563).encode("utf-8"),base_url,350,'13',poster)
    add_categories(total,language(30564).encode("utf-8"),base_url,350,'14',poster)
    add_categories(total,language(30565).encode("utf-8"),base_url,350,'15',poster)
    add_categories(total,language(30566).encode("utf-8"),base_url,350,'16',poster)
    add_categories(total,language(30567).encode("utf-8"),base_url,350,'17',poster)
    xbmc_view('1')
    return

def get_movie_years_sort():
    xbmc_data()
    total = 8
    add_categories(total,language(30571).encode("utf-8"),base_url,360,'1',poster)
    add_categories(total,language(30572).encode("utf-8"),base_url,360,'2',poster)
    add_categories(total,language(30573).encode("utf-8"),base_url,360,'3',poster)
    add_categories(total,language(30574).encode("utf-8"),base_url,360,'4',poster)
    add_categories(total,language(30575).encode("utf-8"),base_url,360,'5',poster)
    add_categories(total,language(30576).encode("utf-8"),base_url,360,'6',poster)
    add_categories(total,language(30577).encode("utf-8"),base_url,360,'7',poster)
    add_categories(total,language(30578).encode("utf-8"),base_url,360,'8',poster)
    xbmc_view('1')
    return

def get_short_movie_categories():
    xbmc_data()
    total = 3
    add_categories(total,language(30511).encode("utf-8"),base_url,410,'0',poster)
    add_categories(total,language(30512).encode("utf-8"),base_url,420,'0',poster)
    add_categories(total,language(30513).encode("utf-8"),base_url,430,'0',poster)
    xbmc_view('1')
    return

def get_short_movies_sort():
    xbmc_data()
    total = 26
    add_categories(total,language(30521).encode("utf-8"),base_url,440,'1',poster)
    add_categories(total,language(30522).encode("utf-8"),base_url,440,'2',poster)
    add_categories(total,language(30523).encode("utf-8"),base_url,440,'3',poster)
    add_categories(total,language(30524).encode("utf-8"),base_url,440,'4',poster)
    add_categories(total,language(30525).encode("utf-8"),base_url,440,'5',poster)
    add_categories(total,language(30526).encode("utf-8"),base_url,440,'6',poster)
    add_categories(total,language(30527).encode("utf-8"),base_url,440,'7',poster)
    add_categories(total,language(30528).encode("utf-8"),base_url,440,'8',poster)
    add_categories(total,language(30529).encode("utf-8"),base_url,440,'9',poster)
    add_categories(total,language(30530).encode("utf-8"),base_url,440,'10',poster)
    add_categories(total,language(30531).encode("utf-8"),base_url,440,'11',poster)
    add_categories(total,language(30532).encode("utf-8"),base_url,440,'12',poster)
    add_categories(total,language(30533).encode("utf-8"),base_url,440,'13',poster)
    add_categories(total,language(30534).encode("utf-8"),base_url,440,'14',poster)
    add_categories(total,language(30535).encode("utf-8"),base_url,440,'15',poster)
    add_categories(total,language(30536).encode("utf-8"),base_url,440,'16',poster)
    add_categories(total,language(30537).encode("utf-8"),base_url,440,'17',poster)
    add_categories(total,language(30538).encode("utf-8"),base_url,440,'18',poster)
    add_categories(total,language(30539).encode("utf-8"),base_url,440,'19',poster)
    add_categories(total,language(30540).encode("utf-8"),base_url,440,'20',poster)
    add_categories(total,language(30541).encode("utf-8"),base_url,440,'21',poster)
    add_categories(total,language(30542).encode("utf-8"),base_url,440,'22',poster)
    add_categories(total,language(30543).encode("utf-8"),base_url,440,'23',poster)
    add_categories(total,language(30544).encode("utf-8"),base_url,440,'24',poster)
    add_categories(total,language(30545).encode("utf-8"),base_url,440,'25',poster)
    add_categories(total,language(30546).encode("utf-8"),base_url,440,'26',poster)
    xbmc_view('1')
    return

def get_short_movie_genres_sort():
    xbmc_data()
    total = 17
    add_categories(total,language(30551).encode("utf-8"),base_url,450,'1',poster)
    add_categories(total,language(30552).encode("utf-8"),base_url,450,'2',poster)
    add_categories(total,language(30553).encode("utf-8"),base_url,450,'3',poster)
    add_categories(total,language(30554).encode("utf-8"),base_url,450,'4',poster)
    add_categories(total,language(30555).encode("utf-8"),base_url,450,'5',poster)
    add_categories(total,language(30556).encode("utf-8"),base_url,450,'6',poster)
    add_categories(total,language(30557).encode("utf-8"),base_url,450,'7',poster)
    add_categories(total,language(30558).encode("utf-8"),base_url,450,'8',poster)
    add_categories(total,language(30559).encode("utf-8"),base_url,450,'9',poster)
    add_categories(total,language(30560).encode("utf-8"),base_url,450,'10',poster)
    add_categories(total,language(30561).encode("utf-8"),base_url,450,'11',poster)
    add_categories(total,language(30562).encode("utf-8"),base_url,450,'12',poster)
    add_categories(total,language(30563).encode("utf-8"),base_url,450,'13',poster)
    add_categories(total,language(30564).encode("utf-8"),base_url,450,'14',poster)
    add_categories(total,language(30565).encode("utf-8"),base_url,450,'15',poster)
    add_categories(total,language(30566).encode("utf-8"),base_url,450,'16',poster)
    add_categories(total,language(30567).encode("utf-8"),base_url,450,'17',poster)
    xbmc_view('1')
    return

def get_short_movie_years_sort():
    xbmc_data()
    total = 5
    add_categories(total,language(30581).encode("utf-8"),base_url,460,'1',poster)
    add_categories(total,language(30582).encode("utf-8"),base_url,460,'2',poster)
    add_categories(total,language(30583).encode("utf-8"),base_url,460,'3',poster)
    add_categories(total,language(30584).encode("utf-8"),base_url,460,'4',poster)
    add_categories(total,language(30585).encode("utf-8"),base_url,460,'5',poster)
    xbmc_view('1')
    return

def add_categories(total,name,url,mode,type,iconimage):
    sysname = urllib.quote_plus(name)
    systype = urllib.quote_plus(type)
    sysurl = urllib.quote_plus(url)
    contextMenuItems = []
    u = '%s?mode=%s&type=%s&url=%s' % (sys.argv[0], str(mode), systype, sysurl)
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        item.setProperty( "Fanart_Image", iconimage )
    else: item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)

def get_movies(type):
    xbmc_data()
    movies = ''
    try:
        for i in range(1, 9):
            url = '%sl=%s&y=%s' % (movies_url, type, str(i))
            result = common.fetchPage({"link": url})
            movies += common.parseDOM(result["content"], "DIV", attrs = { "class": "maincontent" })[0]
    except:
        xbmc_view('2')
        return
    try:
        movies = common.parseDOM(movies, "td", attrs = { "width": ".+?" })
        movies = unique_list(movies)
        total = len(movies)
    except:
        xbmc_view('2')
        return
    for movie in movies:
        try:
            name = movie_name(movie)
            url = movie_url(movie)
            iconimage = movie_iconimage(movie)
            add_movies(total,name,url,600,iconimage)
        except:
            total = total - 1
            pass
    xbmc_view('2')
    return

def get_movie_genres(type):
    xbmc_data()
    movies = ''
    try:
        for i in range(1, 9):
            url = '%sg=%s&y=%s' % (movies_url, type, str(i))
            result = common.fetchPage({"link": url})
            movies += common.parseDOM(result["content"], "DIV", attrs = { "class": "maincontent" })[0]
    except:
        xbmc_view('2')
        return
    try:
        movies = common.parseDOM(movies, "td", attrs = { "width": ".+?" })
        movies = unique_list(movies)
        total = len(movies)
    except:
        xbmc_view('2')
        return
    for movie in movies:
        try:
            name = movie_name(movie)
            url = movie_url(movie)
            iconimage = movie_iconimage(movie)
            add_movies(total,name,url,600,iconimage)
        except:
            total = total - 1
            pass
    xbmc_view('2')
    return

def get_movie_years(type):
    xbmc_data()
    movies = ''
    try:
        url = '%sy=%s' % (movies_url, type)
        result = common.fetchPage({"link": url})
        movies += common.parseDOM(result["content"], "DIV", attrs = { "class": "maincontent" })[0]
    except:
        xbmc_view('2')
        return
    try:
        movies = common.parseDOM(movies, "td", attrs = { "width": ".+?" })
        movies = unique_list(movies)
        total = len(movies)
    except:
        xbmc_view('2')
        return
    for movie in movies:
        try:
            name = movie_name(movie)
            url = movie_url(movie)
            iconimage = movie_iconimage(movie)
            add_movies(total,name,url,600,iconimage)
        except:
            total = total - 1
            pass
    xbmc_view('2')
    return

def get_short_movies(type):
    xbmc_data()
    movies = ''
    try:
        for i in range(1, 6):
            url = '%sl=%s&y=%s' % (short_movies_url, type, str(i))
            result = common.fetchPage({"link": url})
            movies += common.parseDOM(result["content"], "DIV", attrs = { "class": "maincontent" })[0]
    except:
        xbmc_view('2')
        return
    try:
        movies = common.parseDOM(movies, "td", attrs = { "width": ".+?" })
        movies = unique_list(movies)
        total = len(movies)
    except:
        xbmc_view('2')
        return
    for movie in movies:
        try:
            name = movie_name(movie)
            url = movie_url(movie)
            iconimage = movie_iconimage(movie)
            add_movies(total,name,url,600,iconimage)
        except:
            total = total - 1
            pass
    xbmc_view('2')
    return

def get_short_movie_genres(type):
    xbmc_data()
    movies = ''
    try:
        for i in range(1, 6):
            url = '%sg=%s&y=%s' % (short_movies_url, type, str(i))
            result = common.fetchPage({"link": url})
            movies += common.parseDOM(result["content"], "DIV", attrs = { "class": "maincontent" })[0]
    except:
        xbmc_view('2')
        return
    try:
        movies = common.parseDOM(movies, "td", attrs = { "width": ".+?" })
        movies = unique_list(movies)
        total = len(movies)
    except:
        xbmc_view('2')
        return
    for movie in movies:
        try:
            name = movie_name(movie)
            url = movie_url(movie)
            iconimage = movie_iconimage(movie)
            add_movies(total,name,url,600,iconimage)
        except:
            total = total - 1
            pass
    xbmc_view('2')
    return

def get_short_movie_years(type):
    xbmc_data()
    movies = ''
    try:
        url = '%sy=%s' % (short_movies_url, type)
        result = common.fetchPage({"link": url})
        movies += common.parseDOM(result["content"], "DIV", attrs = { "class": "maincontent" })[0]
    except:
        xbmc_view('2')
        return
    try:
        movies = common.parseDOM(movies, "td", attrs = { "width": ".+?" })
        movies = unique_list(movies)
        total = len(movies)
    except:
        xbmc_view('2')
        return
    for movie in movies:
        try:
            name = movie_name(movie)
            url = movie_url(movie)
            iconimage = movie_iconimage(movie)
            add_movies(total,name,url,600,iconimage)
        except:
            total = total - 1
            pass
    xbmc_view('2')
    return

def get_recent(type):
    xbmc_data()
    movies = ''
    try:
        if type == '1': url = movies_url
        if type == '2': url = short_movies_url
        result = common.fetchPage({"link": url})
        movies += common.parseDOM(result["content"], "DIV", attrs = { "class": "maincontent" })[0]
    except:
        xbmc_view('2')
        return
    try:
        movies = common.parseDOM(movies, "td", attrs = { "width": ".+?" })
        movies = unique_list(movies)
        total = len(movies)
    except:
        xbmc_view('2')
        return
    for movie in movies:
        try:
            name = movie_name(movie)
            url = movie_url(movie)
            iconimage = movie_iconimage(movie)
            add_movies(total,name,url,600,iconimage)
        except:
            total = total - 1
            pass
    xbmc_view('2')
    return

def add_movies(total,name,url,mode,iconimage):
    sysiconimage = urllib.quote_plus(iconimage)
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    read = open(favPath, 'r')
    text = read.read()
    read.close()
    contextMenuItems = []
    if not url in text: contextMenuItems.append((xbmc.getLocalizedString(14076), 'XBMC.RunPlugin(%s?mode=100&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    else: contextMenuItems.append((xbmc.getLocalizedString(14077), 'XBMC.RunPlugin(%s?mode=101&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    u = '%s?mode=%s&name=%s&url=%s&iconimage=%s' % (sys.argv[0], str(mode), sysname, sysurl, sysiconimage)
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "Plot": description } )
    item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)

def get_movie_sources(name,url,iconimage):
    xbmc_data()
    title = name
    try:
        result = common.fetchPage({"link": url})
        sources = common.parseDOM(result["content"], "DIV", attrs = { "class": "maincontent" })[0]
        sources = common.parseDOM(sources, "tr",)[-1]
        sources = common.parseDOM(sources, "p",)
        sources = unique_list(sources)
        total = len(sources)
    except:
        xbmc_view('1')
        return
    hosts = ['youtube','google','putlocker','veoh','vimeo','dailymotion','videoweed']
    for host in hosts:
        for source in sources:
            try:
                name = common.parseDOM(source, "a")[0]
                name = name.replace('<b>','').replace('</b>','')
                if re.search('.+?youtube.+?',name) is not None: name = 'youtube'
                if re.search('.+?google.+?',name) is not None: name = 'google'
                if re.search('.+?putlocker.+?',name) is not None: name = 'putlocker'
                if re.search('.+?veoh.+?',name) is not None: name = 'veoh'
                if re.search('.+?vimeo.+?',name) is not None: name = 'vimeo'
                if re.search('.+?dailymotion.+?',name) is not None: name = 'dailymotion'
                if re.search('.+?videoweed.+?',name) is not None: name = 'videoweed'
                name = common.replaceHTMLCodes(name)
                name = name.encode('utf-8')
                url = common.parseDOM(source, "a", ret="href")[0]
                url = base_url + url
                url = common.replaceHTMLCodes(url)
                url = url.encode('utf-8')
                if name == host:
                    add_movie_sources(total,name,title,url,iconimage)
            except:
                pass
    xbmc_view('1')
    return

def add_movie_sources(total,name,title,url,iconimage):
    mode = 900
    sysname = urllib.quote_plus(title)
    sysurl = urllib.quote_plus(url)
    contextMenuItems = []
    u = '%s?mode=%s&name=%s&url=%s' % (sys.argv[0], str(mode), sysname, sysurl)
    item = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "Plot": description } )
    item.setProperty("IsPlayable", "true")
    item.setProperty( "Video", "true" )
    item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)	
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total)

def resolve_movies(name,url):
    try:
        if re.search(".+? (.+?)",name) is not None:
            temp = re.search("(.+?) [(](.+?)[)]", name)
            name,year = temp.groups()
    except:
        pass
    try:
        result = common.fetchPage({"link": url})
        url = common.parseDOM(result["content"], "button", ret="OnClick")[0]
        if re.search("'.+?'",url) is not None:
            url = re.compile("'(.+?)'").findall(url)[-1]
    except:
        return
    try:
        if (re.search("video.google",url) or re.search("veoh",url) or re.search("vimeo",url)):
            flashvideodownloader = 'http://www.flashvideodownloader.org/download.php?u=%s' % url
            result = common.fetchPage({"link": flashvideodownloader})
            flashvideodownloader = common.parseDOM(result["content"], "div", attrs = { "class": "mod_download" })[0]
            flashvideodownloader = common.parseDOM(flashvideodownloader, "a", ret="href")[0]
            item = xbmcgui.ListItem(path=flashvideodownloader)
            item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "Year": year, "Plot": description } )
            return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
    except:
        pass
    try:
        if re.search("video.google",url) is not None:
            result = common.fetchPage({"link": url})
            url = common.parseDOM(result["content"], "link", attrs = { "rel": "canonical" }, ret="href")[0]
            url = 'http://www.youtube.com%s' % url

        if re.search("youtube",url) is not None:
            url = url.split("v=")[-1]
            host = 'youtube'

        if re.search("putlocker",url) is not None:
            url = url.split("/")[-1]
            host = 'putlocker'

        if re.search("veoh",url) is not None:
            url = url.split("/")[-1]
            host = 'veoh'

        if re.search("vimeo",url) is not None:
            url = url.split("/")[-1]
            host = 'vimeo'

        if re.search("dailymotion",url) is not None:
            url = url.split("/")[-1]
            host = 'dailymotion'

        if re.search("videoweed",url) is not None:
            url = url.split("/")[-1]
            host = 'videoweed'

        if host == 'youtube' and check_addon('plugin.video.youtube') is None:
            xbmcgui.Dialog().ok(addonname, language(30211).encode("utf-8"), language(30213).encode("utf-8"))
            return
        if host == 'vimeo' and check_addon('plugin.video.vimeo') is None:
            xbmcgui.Dialog().ok(addonname, language(30212).encode("utf-8"), language(30213).encode("utf-8"))
            return
        if check_addon('script.module.urlresolver') is None:
            xbmcgui.Dialog().ok(addonname, language(30214).encode("utf-8"), language(30215).encode("utf-8"))
            return

        url = urlresolver.HostedMediaFile(host=host, media_id=url).resolve()
        item = xbmcgui.ListItem(path=url)
        item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "Year": year, "Plot": description } )
        return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
    except:
        return

def movie_name(data):
    try:
        name = common.parseDOM(data, "p")[0]
        name = common.replaceHTMLCodes(name)
        name = name.encode('utf-8')
        return name
    except:
        return

def movie_url(data):
    try:
        url = common.parseDOM(data, "a", ret="href")[0]
        url = common.replaceHTMLCodes(url)
        url = base_url + url
        url = url.encode('utf-8')
        return url
    except:
        return

def movie_iconimage(data):
    try:
        iconimage = common.parseDOM(data, "IMG", ret="SRC")[0]
        iconimage = common.replaceHTMLCodes(iconimage)
        iconimage = base_url + iconimage
        if iconimage.endswith('icon/film.jpg'): iconimage = poster
        iconimage = iconimage.encode('utf-8')
        return iconimage
    except:
        return

def get_iconimage(url):
    try:
        result = common.fetchPage({"link": url})
        iconimage = common.parseDOM(result["content"], "DIV", attrs = { "class": "maincontent" })[0]
        iconimage = common.parseDOM(iconimage, "img", ret="src")[0]
        iconimage = common.replaceHTMLCodes(iconimage)
        iconimage = base_url + iconimage
        if iconimage.endswith('icon/film.jpg'): iconimage = poster
        iconimage = iconimage.encode('utf-8')
        return iconimage
    except:
        return


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?','')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


params = get_params()
url = None
name = None
iconimage = None
type = None
mode = None
try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:
    type = urllib.unquote_plus(params["type"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass


if mode == None or url == None or len(url) < 1:
    get_categories()

elif mode == 100:
    add_favourite_item(name,url)

elif mode == 101:
    delete_favourite_item(name,url)

elif mode == 102:
    move_favourite_item(name,url,'favup')

elif mode == 103:
    move_favourite_item(name,url,'favdown')

elif mode == 200:
    get_favourites()

elif mode == 300:
    get_movie_categories()

elif mode == 310:
    get_movies_sort()

elif mode == 320:
    get_movie_genres_sort()

elif mode == 330:
    get_movie_years_sort()

elif mode == 340:
    get_movies(type)

elif mode == 350:
    get_movie_genres(type)

elif mode == 360:
    get_movie_years(type)

elif mode == 400:
    get_short_movie_categories()

elif mode == 410:
    get_short_movies_sort()

elif mode == 420:
    get_short_movie_genres_sort()

elif mode == 430:
    get_short_movie_years_sort()

elif mode == 440:
    get_short_movies(type)

elif mode == 450:
    get_short_movie_genres(type)

elif mode == 460:
    get_short_movie_years(type)

elif mode == 500:
    get_recent(type)

elif mode == 600:
    get_movie_sources(name,url,iconimage)

elif mode == 900:
    resolve_movies(name,url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))