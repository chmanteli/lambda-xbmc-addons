# -*- coding: utf-8 -*-

'''
    hellenic tv XBMC Addon
    Copyright (C) 2012 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib,urllib2,re,os,xbmcplugin,xbmcgui,xbmcaddon
try: import json
except: import simplejson as json

settings = xbmcaddon.Addon(id='plugin.video.hellenic.tv')
data = 'special://profile/addon_data/plugin.video.hellenic.tv'

home = settings.getAddonInfo('path')
language = settings.getLocalizedString
addonname = settings.getAddonInfo("name")
justinaddon = xbmcaddon.Addon(id='plugin.video.jtv.archives').getAddonInfo('name')
icon = xbmc.translatePath(os.path.join(home,'icon.png'))
fanart = xbmc.translatePath(os.path.join(home,'fanart.jpg'))
logopath = xbmc.translatePath(os.path.join(home,'resources/logos/'))
datapath = xbmc.translatePath(data)
skin = xbmc.getSkinDir()

xbmcplugin.setContent(int(sys.argv[1]), 'Episodes')
xbmcplugin.setPluginFanart(int(sys.argv[1]), fanart)


def xbmc_view():
    viewenable = settings.getSetting("viewenable")

    if (skin == 'skin.confluence' or skin == 'skin.confluence.svn') and viewenable == 'true':
        confluence_views = [50,51,500,503,504]
        view = int(settings.getSetting("confluence"))
        xbmc.executebuiltin("Container.SetViewMode("+str(confluence_views[view])+")")

    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn') and viewenable == 'true':
        rapier_views = [50,52,74,73,68,94]
        view = int(settings.getSetting("rapier"))
        xbmc.executebuiltin("Container.SetViewMode("+str(rapier_views[view])+")")

def xbmc_webserver():
    if xbmc.executehttpapi("GetGuiSetting(1, services.webserver)")[4:] == "False":
        try:
            forcedserver = settings.getSetting("ForcedWebServer") == "True"
        except:
            forcedserver = False

        if forcedserver == False:
            dlg = xbmcgui.Dialog()
            retval = dlg.yesno(addonname, language(30201).encode("utf-8"), language(30202).encode("utf-8"))
            settings.setSetting("ForcedWebServer", "True")

            if retval:
                dlg.ok(addonname, language(30203).encode("utf-8"), language(30204).encode("utf-8"))
                xbmc.executehttpapi("SetGUISetting(1, services.webserver, true)")

			
def GetURL(url,referer=None):
    if referer is None:
        headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0'}
    else:
        headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0', 'Referer' : referer}
    req = urllib2.Request(url,None,headers)
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    link = link.replace('\n','')
    return link

def GetURL2(url,referer=None):
    if referer is None:
        headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0'}
    else:
        headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0', 'Referer' : referer}
    req = urllib2.Request(url, None, headers)
    response = urllib2.urlopen(req)
    link = response.geturl()
    return link

def get_epg(name,description):
    epg = "[B][%s] - %s[/B]\n%s" %(language(30200).encode("utf-8"), name, description.encode("utf-8"))
    return epg

def get_pathfinder_data():
    try:
        pathfinder = GetURL('http://tv.pathfinder.gr/now/')
        return pathfinder
    except:
        return

def get_pathfinder(pathfinder,name,channel,description):
    try:
        if settings.getSetting("epgenable") == 'true':
            temp = re.search('<a href="%s/(.+?)">(.+?)</a>.+?<td>(.+?)</td>' %(channel), pathfinder)
            a,b,c = temp.groups()
            temp = GetURL('http://tv.pathfinder.gr/now/%s' % a)
            c = re.compile('</div><div class="movie_header">.+?<p>(.+?)</p>').findall(temp)[0]
            epg = "[B][%s] - %s[/B]\n%s" %(language(30200).encode("cp1253"), b, c)
            return epg.decode("cp1253")
        else:
            epg = "[B][%s] - %s[/B]\n%s" %(language(30200).encode("cp1253"), name, description.encode("cp1253"))
            return epg.decode("cp1253")
    except:
        epg = "[B][%s] - %s[/B]\n%s" %(language(30200).encode("cp1253"), name, description.encode("cp1253"))
        return epg.decode("cp1253")


def get_channels():
    xbmc_webserver()
    pathfinder = get_pathfinder_data()


    name = 'MEGA'
    premiered = '1989'
    url = 'megaweb'
    epg = get_pathfinder(pathfinder,name,'mega',language(30501))
    add_wowza_channels(name,url,premiered,epg)

    name = 'ANT1'
    premiered = '1989'
    url = 'rtmp://live.forth.cloud.ant1.gr:80/live/ playpath=ant1tvnilova swfUrl=http://static.ant1.gr/live.ashx pageUrl=http://webtv.antenna.gr/webtv/live conn=B:0 swfVfy=true live=true timeout=10'
    epg = get_pathfinder(pathfinder,name,'ant1',language(30502))
    add_channels(name,url,premiered,epg)

    name = 'STAR'
    premiered = '1993'
    url = 'alterweb'
    #url = 'mms://206.222.31.146/star1?sid=18d43610-3556-47bd-bdab-a7ab48d78a5d-15-120756 live=true timeout=10'
    epg = get_pathfinder(pathfinder,name,'star',language(30503))
    add_wowza_channels(name,url,premiered,epg)

    name = 'ALPHA'
    premiered = '1993'
    url = 'kanali10'
    epg = get_pathfinder(pathfinder,name,'alpha',language(30504))
    add_wowza_channels(name,url,premiered,epg)

    name = 'SKAI'
    premiered = '2006'
    #url = 'rtmp://cp76154.live.edgefcs.net/live/ playpath=TV_LIVE_1@10773 swfUrl=http://www.skai.gr/files/1/Flash/Shows/SkaiMediaPlayer.swf pageUrl=http://www.skai.gr/player/tvlive/ swfVfy=true live=true timeout=10'
    url = 'plugin://plugin.video.youtube/?action=play_video&videoid=znMibmfnBcg'
    epg = get_pathfinder(pathfinder,name,'skai',language(30505))
    add_channels(name,url,premiered,epg)

    name = 'NET'
    premiered = '1966'
    url = 'rtmp://cp76856.live.edgefcs.net/live/ playpath=GRERT_vid_nogeo_NET@25927 live=true timeout=10'
    epg = get_pathfinder(pathfinder,name,'net',language(30506))
    add_channels(name,url,premiered,epg)

    name = 'ET1'
    premiered = '1966'
    url = 'rtmp://cp76856.live.edgefcs.net/live/ playpath=GRERT_vid_nogeo_ET1@25926 live=true timeout=10'
    epg = get_pathfinder(pathfinder,name,'et1',language(30507))
    add_channels(name,url,premiered,epg)

    name = 'ET3'
    premiered = '1988'
    url = 'rtmp://cp76856.live.edgefcs.net/live/ playpath=GRERT_vid_nogeo_ET3@25928 live=true timeout=10'
    epg = get_pathfinder(pathfinder,name,'et3',language(30508))
    add_channels(name,url,premiered,epg)

    name = 'ERT WORLD'
    premiered = '1996'
    url = 'tvnetwork-hellenictv-ertworld-hsslive-25f-4x3-SDh'
    epg = get_epg(name,language(30509))
    add_visionip_channels(name,url,premiered,epg)

    name = 'BOYLH TV'
    premiered = '1999'
    url = 'mms://media19.internet.gr/ParliamentTV-HQ'
    epg = get_pathfinder(pathfinder,name,'vouli',language(30510))
    add_channels(name,url,premiered,epg)

    name = 'MEGA CYPRUS'
    premiered = '1999'
    url = 'tvnetwork-hellenictv-mega-hsslive-25f-4x3-SDh'
    epg = get_epg(name,language(30521))
    add_visionip_channels(name,url,premiered,epg)
	
    name = 'ANT1 CYPRUS'
    premiered = '1993'
    url = 'rtmp://videos.ant1.com.cy:80/livepkgr playpath=livestream?adbe-live-event=liveevent swfUrl=http://www.ant1iwo.com/flowplayer.rtmp-3.1.3.swf pageUrl=http://www.ant1iwo.com/livestreaming/ swfVfy=true live=true timeout=10'
    epg = get_epg(name,language(30522))
    add_channels(name,url,premiered,epg)

    name = 'SIGMA'
    premiered = '1995'
    url = 'tvnetwork-hellenictv-sigma-hsslive-25f-4x3-SDh'
    epg = get_epg(name,language(30523))
    add_visionip_channels(name,url,premiered,epg)

    name = 'TV PLUS'
    premiered = '2006'
    url = 'tvnetwork-hellenictv-plus_tv-hsslive-25f-4x3-SDh'
    epg = get_epg(name,language(30524))
    add_visionip_channels(name,url,premiered,epg)

    name = 'RIK SAT'
    premiered = '1957'
    url = 'tvnetwork-hellenictv-riksat-hsslive-25f-4x3-SDh'
    #url = 'rtmp://m4.webvideocore.net/live/ playpath=7zlyq17szhc0o0wwsg4o swfUrl=http://play.streamingvideoprovider.com/player2.swf pageUrl=http://www.cybc.com.cy/video-on-demand/index.php?option=com_content&view=article&id=681&Itemid=83 swfVfy=true live=true timeout=10'
    epg = get_epg(name,language(30525))
    add_visionip_channels(name,url,premiered,epg)

    name = 'MTV NRG'
    premiered = '2011'
    url = 'tvnetwork-hellenictv-nrg-hsslive-25f-4x3-SDh'
    epg = get_epg(name,language(30526))
    add_visionip_channels(name,url,premiered,epg)

    name = 'MAD'
    premiered = '1996'
    url = 'tvnetwork-hellenictv-htv_music-hsslive-25f-4x3-SDh'
    epg = get_epg(name,language(30541))
    add_visionip_channels(name,url,premiered,epg)

    name = 'ACTION 24'
    premiered = ''
    url = 'rtmp://action24.str.viiideo.gr app=livepkgr/action24 playpath=livestream live=true timeout=10'
    #url = 'rtmp://srv2.viiideo.gr/live/ playpath=action24 live=true timeout=10'
    epg = get_epg(name,language(30542))
    add_channels(name,url,premiered,epg)

    name = 'KONTRA'
    premiered = '2010'
    url = 'rtmp://flashcloud.mediacdn.com/live/ playpath=kontratv live=true timeout=10'
    epg = get_epg(name,language(30543))
    add_channels(name,url,premiered,epg)

    name = 'EXTRA 3'
    premiered = '2001'
    url = 'rtmp://cp115021.live.edgefcs.net/live/ playpath=extragtnet@49573 live=true timeout=10'
    epg = get_epg(name,language(30544))
    add_channels(name,url,premiered,epg)

    name = 'ZOUGLA TV'
    premiered = ''
    url = 'rtmp://cp67108.live.edgefcs.net/live/ playpath=zouglaradio@15863 live=true timeout=10'
    epg = get_epg(name,language(30545))
    add_channels(name,url,premiered,epg)
	
    name = 'CHANNEL 9'
    premiered = '2005'
    url = 'http://www.livestream.com/channel9gr'
    epg = get_epg(name,language(30546))
    #add_livestream_channels(name,url,premiered,epg)

    name = 'SUNNY CHANNEL'
    premiered = '2012'
    url = 'http://www.livestream.com/sunnychannelgr'
    epg = get_epg(name,language(30547))
    add_livestream_channels(name,url,premiered,epg)

    name = 'BLUE SKY'
    premiered = '1990'
    url = 'mms://live.blueskytv.gr:8083/publishingpoint1'
    epg = get_epg(name,language(30548))
    add_channels(name,url,premiered,epg)

    name = 'BODY IN BALANCE'
    premiered = '2011'
    url = 'rtmp://flashcloud.mediacdn.com/live/ playpath=shoptv live=true timeout=10'
    epg = get_epg(name,language(30549))
    add_channels(name,url,premiered,epg)

    name = 'TELEASTY'
    premiered = '1990'
    url = 'tvnetwork-hellenictv-teleasty-hsslive-25f-4x3-SDh'
    epg = get_epg(name,language(30550))
    add_visionip_channels(name,url,premiered,epg)

    name = 'TELEASTY SPORT'
    premiered = '2011'
    url = 'rtmp://tv1.streampulse.eu/tilesport/ playpath=movie1 pageUrl=http://www.tilesport.tv/ live=true timeout=10'
    epg = get_epg(name,language(30551))
    add_channels(name,url,premiered,epg)

    name = '0-6 TV'
    premiered = ''
    url = 'http://www.livestream.com/06television'
    epg = get_epg(name,language(30552))
    add_livestream_channels(name,url,premiered,epg)

    name = 'STAR KENTRIKIS ELLADOS'
    premiered = ''
    url = 'http://www.dailymotion.com/video/xqjey2_star-lamia-live-streaming_news'
    epg = get_epg(name,language(30561))
    add_dailymotion_channels(name,url,premiered,epg)

    name = 'ENA TV'
    premiered = ''
    url = 'rtmp://srv2.viiideo.gr/live app=live playpath=enatv swfUrl=http://enatv.viiideo.gr/flowplayer/flowplayer.commercial-3.2.8.swf pageUrl=http://enatv.viiideo.gr/?cid=7  swfVfy=true live=true'
    epg = get_epg(name,language(30562))
    add_channels(name,url,premiered,epg)

    name = 'ASTRA TV'
    premiered = ''
    url = 'http://www.livestream.com/astratelevision'
    epg = get_epg(name,language(30581))
    add_livestream_channels(name,url,premiered,epg)

    name = 'EPIRUS TV1'
    premiered = ''
    url = 'http://www.livestream.com/epirustv1live'
    epg = get_epg(name,language(30601))
    add_livestream_channels(name,url,premiered,epg)

    name = 'ITV'
    premiered = ''
    url = 'http://www.ustream.tv/channel/ioannina-tv1'
    epg = get_epg(name,language(30602))
    add_ustream_channels(name,url,premiered,epg)

    name = 'ACHELOOS TV'
    premiered = ''
    url = 'rtmp://axeloostv.str.viiideo.gr/live/ playpath=mp4:axeloos.mp4 live=true timeout=10'
    epg = get_epg(name,language(30603))
    add_channels(name,url,premiered,epg)

    name = 'START TV'
    premiered = ''
    url = 'mms://208.75.230.34/corfutech'
    epg = get_epg(name,language(30604))
    add_channels(name,url,premiered,epg)

    name = 'CORFU CHANNEL'
    premiered = ''
    url = 'http://www.ustream.tv/channel/corfu-tv'
    epg = get_epg(name,language(30605))
    add_ustream_channels(name,url,premiered,epg)

    name = 'SUPER B'
    premiered = '1990'
    url = 'rtmp://176.9.145.67:80/superb/carnaval live=true timeout=10'
    epg = get_epg(name,language(30621))
    add_channels(name,url,premiered,epg)

    name = 'ACHAIA CHANNEL'
    premiered = ''
    url = 'mms://www999.connectit.gr/stream-web'
    epg = get_epg(name,language(30622))
    add_channels(name,url,premiered,epg)

    name = 'LEPANTO'
    premiered = '1989'
    url = 'mms://159.253.149.12:8000/lepanto'
    url = 'rtmp://159.253.149.12:1935/ app=39bby339vft99 playpath=39bby339vft99 live=true timeout=10'
    epg = get_epg(name,language(30623))
    add_channels(name,url,premiered,epg)

    name = 'ELLADA TV'
    premiered = ''
    url = 'rtmp://fml.68FC.edgecastcdn.net/2068FC/elladatv swfUrl=http://www.elladatv.gr/scripts/player.swf swfVfy=true live=true timeout=10'
    epg = get_epg(name,language(30641))
    add_channels(name,url,premiered,epg)

    name = 'KRITI TV'
    premiered = ''
    url = 'mms://85.25.236.14/cretetv1'
    epg = get_epg(name,language(30661))
    add_channels(name,url,premiered,epg)

    name = 'NEA TV'
    premiered = ''
    url = 'rtmp://koul.str.viiideo.gr/live/ playpath=mp4:koul5.mp4 live=true timeout=10'
    epg = get_epg(name,language(30662))
    add_channels(name,url,premiered,epg)

    name = 'KYDON TV'
    premiered = ''
    url = 'http://www.justin.tv/kydontv'
    epg = get_epg(name,language(30663))
    add_justin_channels(name,url,premiered,epg)

    name = 'KISSAMOS TV'
    premiered = ''
    url = 'rtmp://tvellas.net/live/kissamos live=true timeout=10'
    epg = get_epg(name,language(30664))
    add_channels(name,url,premiered,epg)

    name = 'IRIDA TV'
    premiered = ''
    url = 'mms://212.251.44.111:27030'
    epg = get_epg(name,language(30681))
    add_channels(name,url,premiered,epg)

    name = 'KOSMOS'
    premiered = ''
    url = 'rtmp://events.yourmedia.gr:1935/ app=tvkosmos playpath=mp4:tvkosmos.mp4 live=true timeout=10'
    epg = get_epg(name,language(30682))
    add_channels(name,url,premiered,epg)

    name = 'DIRAS TV'
    premiered = ''
    url = 'rtmp://www.cityofkos.gr/diras/livetv live=true timeout=10'
    epg = get_epg(name,language(30683))
    add_channels(name,url,premiered,epg)

    name = 'ARCHIPELAGOS TV'
    premiered = ''
    url = 'mms://stream.isol.gr/ARCHIPELAGOS'
    epg = get_epg(name,language(30701))
    add_channels(name,url,premiered,epg)

    name = 'TVM'
    premiered = ''
    url = 'rtmp://cp77174.live.edgefcs.net/live/ playpath=123456@19937 live=true timeout=10'
    epg = get_epg(name,language(30702))
    add_channels(name,url,premiered,epg)

    name = 'TV 100'
    premiered = '1988'
    url = 'rtmp://eco.caststream.net:1935/tv100/ playpath=tv100 live=true timeout=10'
    epg = get_epg(name,language(30741))
    add_channels(name,url,premiered,epg)

    name = 'EGNATIA TV'
    premiered = ''
    url = 'http://www.ustream.tv/channel/egnatiatv'
    epg = get_epg(name,language(30742))
    add_ustream_channels(name,url,premiered,epg)

    name = 'VERGINA TV'
    premiered = ''
    url = 'http://www.livestream.com/verginatv'
    epg = get_epg(name,language(30743))
    add_livestream_channels(name,url,premiered,epg)

    name = 'EUROPE 1'
    premiered = ''
    url = 'http://www.ustream.tv/channel/evina-kout'
    epg = get_epg(name,language(30744))
    add_ustream_channels(name,url,premiered,epg)

    name = 'DION TV'
    premiered = ''
    url = 'http://www.ustream.tv/channel/dion-tv-live'
    epg = get_epg(name,language(30745))
    add_ustream_channels(name,url,premiered,epg)

    name = '4E TV'
    premiered = ''
    url = 'rtmp://82.192.84.30:1935/live playpath=myStream.sdp live=true timeout=10'
    epg = get_epg(name,language(30746))
    add_channels(name,url,premiered,epg)

    name = 'WEST CHANNEL'
    premiered = ''
    url = 'http://www.ustream.tv/channel/west-tv-live'
    epg = get_epg(name,language(30761))
    add_ustream_channels(name,url,premiered,epg)

    name = 'FLASH TV'
    premiered = ''
    url = 'http://www.justin.tv/flash_television'
    epg = get_epg(name,language(30762))
    add_justin_channels(name,url,premiered,epg)

    name = 'TOP CHANNEL'
    premiered = ''
    url = 'http://www.justin.tv/top_channel'
    epg = get_epg(name,language(30763))
    add_justin_channels(name,url,premiered,epg)

    name = 'ENA CHANNEL'
    premiered = ''
    url = 'http://www.freedocast.com/charalampi'
    epg = get_epg(name,language(30781))
    add_freedocast_channels(name,url,premiered,epg)

    name = 'STAR TV DRAMA'
    premiered = ''
    url = 'mms://radiofeeds1.mediabox.gr/startv'
    epg = get_epg(name,language(30782))
    add_channels(name,url,premiered,epg)

    name = 'DIKTYO TV'
    premiered = ''
    url = 'http://www.justin.tv/diktyotv'
    epg = get_epg(name,language(30783))
    add_justin_channels(name,url,premiered,epg)

    name = 'TVS'
    premiered = ''
    url = 'mms://174.36.20.50/tvs'
    epg = get_epg(name,language(30784))
    #add_channels(name,url,premiered,epg)

    name = 'DELTA TV'
    premiered = '1991'
    url = 'mms://ams01.egihosting.com/989630'
    epg = get_epg(name,language(30801))
    add_channels(name,url,premiered,epg)

    name = 'R CHANNEL'
    premiered = '1991'
    url = 'http://www.livestream.com/rodopi_tv'
    epg = get_epg(name,language(30802))
    add_livestream_channels(name,url,premiered,epg)

    name = 'THRAKI NET'
    premiered = ''
    url = 'mms://live.onestreaming.com/thrakinet'
    epg = get_epg(name,language(30803))
    #add_channels(name,url,premiered,epg)

    xbmc_view()

'''
functions
Credit to MaxMustermann for the SportsDevil plugin.
Credit to divingmule for the Jtv plugin (0.3.4).
Credit to t0mm0 for the freedocast plugin.
'''
def wowza_play(url):
    wowza_server = '178.162.134.45:80'
    wowza_server = '46.21.146.45:80'
    url = 'rtmp://%s/%s playpath=%s.sdp pageUrl=http://www.kanalia.eu/ live=true timeout=10' % (wowza_server, url, url)
    return url

def visionip_play(url):
    url = 'rtmp://freeview.fms.visionip.tv/live/ playpath=mp4:%s live=true timeout=10' % url
    return url

def livestream_play(url):
    url = url.split("http://www.livestream.com/")[1]
    try:
        link = GetURL('http://x%sx.api.channel.livestream.com/3.0/getstream.json' % url)
        isLive = str(link.find('isLive":true'))
    except:
        return
    if isLive == '-1' and url == 'sunnychannelgr':
        return 'rtmp://extondemand.livestream.com:80/ondemand/trans/dv15/mogulus-user-files/chsunnychannelgr/2012/05/16/602ef5f5-9abc-4d44-bdbe-76f5c23099c5'
    if isLive == '-1':
        return
    try:
        url = re.compile('"rtspUrl"[:]"rtsp://(.+?)"').findall(link)[0]
        url = 'rtmp://%s live=true timeout=10' % url
        return url
    except:
        return

def ustream_play(url):
    pageUrl = ' pageUrl=' + url
    try:
        link = GetURL(url)
        channelId = re.compile('www.ustream.tv/embed/(.+?)"').findall(link)[0]
    except:
        return
    try:
        link = GetURL('http://cgw.ustream.tv/Viewer/getStream/1/%s.amf' % channelId)
        rtmp = re.compile('.*(rtmp://.+?)\x00.*').findall(link)[0]
        playpath = re.compile('.*streamName\W\W\W(.+?)[/]*\x00.*').findall(link)[0]
        swfUrl = GetURL2('http://www.ustream.tv/flash/viewer.swf')
        url = '%s/%s swfUrl=%s swfVfy=true live=true timeout=10' % (rtmp, playpath, swfUrl)
        return url
    except:
        return

def dailymotion_play(url):
    try:
        link = GetURL(url)
        watch_url = re.compile('"sequence":"(.+?)"').findall(link)
        watch_url = urllib.unquote(watch_url[0]).decode('utf8').replace('\\/', '/')
        watch_url = re.compile('"customURL":"(.+?)"').findall(watch_url)[0] + '&redirect=0'
    except:
        return
    try:
        stream_url = GetURL(watch_url)
        url = '%s live=true' % (stream_url)
        return url
    except:
        return

def freedocast_play(url):
    try:
        referer = url
        link = GetURL(url)
        watch_url = re.compile('id="player" src="(.+?)"').findall(link)[0]
        watch_url = 'http://www.freedocast.com/%s' % watch_url
        link = GetURL(watch_url,referer)
    except:
        return
    try:
        stream_url = re.search('file=(.+?)&streamer=(.+?)&', link)
        play, streamer = stream_url.groups()
        app = '/'.join(streamer.split('/')[3:])
        url = '%s app=%s playpath=%s pageurl=%s live=true timeout=10' % (streamer, app, play, watch_url)
        return url
    except:
        pass
    try:
        stream_url = re.compile('stream: \'(rtmp.+?)\'').findall(link)[0]
        url = '%s swfUrl=http://cdn.freedocast.com/player-octo/yume/v4/infinite-hd-player-FREEDOCAST.SWF pageUrl=%s swfVfy=true live=true timeout=10' % (stream_url, watch_url)
        return url
    except:
        pass
    try:
        stream_url = re.search('streamsUrl:  \'(.+?)\'', link)
        xml_url = s.group(1)
        xml = GetURL(xml_url)
        stream_url = re.search('<stream uri="(.+?)" stream="(.+?)"', xml)
        tcurl, play = stream_url.groups()
        url = '%s/%s swfUrl=http://cdn.freedocast.com/player-octo/playerv2/swfs/broadkastplayer-yupp.swf pageUrl=%s swfVfy=true live=true timeout=10' % (tcurl, play, watch_url)
        return url
    except:
        pass
    return

def justin_play(url, password=None):
    base_url = 'http://www.justin.tv/'
    name = url.split("http://www.justin.tv/")[1]
    q_type = "live"
    streams = []

    try:
        if not justinaddon == addonname:
            return 'plugin://plugin.video.jtv.archives/?mode=2&name=%s' % name
    except:
        pass

    try:
        temp_url = 'http://www.justin.tv/widgets/live_embed_player.swf?channel=%s' % name
        swf_url = GetURL2(temp_url,url)
    except:
        return

    try:
        temp_url = 'http://usher.justin.tv/find/%s.json?type=any&group=&channel_subscription=' % name
        if not password is None: temp_url += '&private_code='+password
        data = GetURL(temp_url,base_url)
        data = json.loads(data)
    except:
        return
    try:
        for i in data:
            token = None
            try:
                token = ' jtv='+i['token'].replace('\\','\\5c').replace(' ','\\20').replace('"','\\22')
                if i['needed_info'] == 'private': token = 'private'
            except:
                return
            try:
                rtmp = i['connect']+'/'+i['play']
            except:
                return
            try:
                if q_type == i['type']: stream_url = rtmp+token
                else: streams.append((i['type'], rtmp, token))
            except:
                continue
    except:
        return

    try:
        if len(streams) < 1:
            pass
        elif len(streams) == 1:
            stream_url = streams[0][1]+streams[0][2]
        else:
            for i in range(len(s_type)):
                quality = s_type[str(i)]
                for q in streams:
                    if q[0] == quality:
                        stream_url = (q[1]+q[2])
                    else:
                        continue
        url = '%s swfUrl=%s pageUrl=%s swfVfy=true live=true' % (stream_url, swf_url, url)
        return url
    except:
        return



def add_channels(name,url,premiered,epg):
    if settings.getSetting(name) == "false": return
    ok=True
    contextMenuItems = []
    iconimage = logopath+name+'.png'
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Label": name, "Duration": "1440", "Plot": epg, "Premiered": premiered } )
    liz.setProperty("IsPlayable", "true")
    liz.setProperty( "Video", "true" )
    liz.setProperty( "Fanart_Image", fanart )
    liz.addContextMenuItems(contextMenuItems, replaceItems=True)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
    return ok

def add_wowza_channels(name,url,premiered,epg):
    if settings.getSetting(name) == "false": return
    mode = 901
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok = True
    contextMenuItems = []
    iconimage = logopath+name+'.png'
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Label": name, "Duration": "1440", "Plot": epg, "Premiered": premiered } )
    liz.setProperty("IsPlayable", "true")
    liz.setProperty( "Video", "true" )
    liz.setProperty( "Fanart_Image", fanart )
    liz.addContextMenuItems(contextMenuItems, replaceItems=True)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
    return ok

def resolve_wowza_channels(url):
    url = wowza_play(url)
    item = xbmcgui.ListItem(path=url)
    return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

def add_visionip_channels(name,url,premiered,epg):
    if settings.getSetting(name) == "false": return
    mode = 902
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok = True
    contextMenuItems = []
    iconimage = logopath+name+'.png'
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Label": name, "Duration": "1440", "Plot": epg, "Premiered": premiered } )
    liz.setProperty("IsPlayable", "true")
    liz.setProperty( "Video", "true" )
    liz.setProperty( "Fanart_Image", fanart )
    liz.addContextMenuItems(contextMenuItems, replaceItems=True)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
    return ok

def resolve_visionip_channels(url):
    url = visionip_play(url)
    item = xbmcgui.ListItem(path=url)
    return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

def add_livestream_channels(name,url,premiered,epg):
    if settings.getSetting(name) == "false": return
    mode = 903
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok = True
    contextMenuItems = []
    iconimage = logopath+name+'.png'
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Label": name, "Duration": "1440", "Plot": epg, "Premiered": premiered } )
    liz.setProperty("IsPlayable", "true")
    liz.setProperty( "Video", "true" )
    liz.setProperty( "Fanart_Image", fanart )
    liz.addContextMenuItems(contextMenuItems, replaceItems=True)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
    return ok

def resolve_livestream_channels(url):
    url = livestream_play(url)
    item = xbmcgui.ListItem(path=url)
    return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

def add_ustream_channels(name,url,premiered,epg):
    if settings.getSetting(name) == "false": return
    mode = 904
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok = True
    contextMenuItems = []
    iconimage = logopath+name+'.png'
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Label": name, "Duration": "1440", "Plot": epg, "Premiered": premiered } )
    liz.setProperty("IsPlayable", "true")
    liz.setProperty( "Video", "true" )
    liz.setProperty( "Fanart_Image", fanart )
    liz.addContextMenuItems(contextMenuItems, replaceItems=True)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
    return ok

def resolve_ustream_channels(url):
    url = ustream_play(url)
    item = xbmcgui.ListItem(path=url)
    return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

def add_dailymotion_channels(name,url,premiered,epg):
    if settings.getSetting(name) == "false": return
    mode = 905
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok = True
    contextMenuItems = []
    iconimage = logopath+name+'.png'
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Label": name, "Duration": "1440", "Plot": epg, "Premiered": premiered } )
    liz.setProperty("IsPlayable", "true")
    liz.setProperty( "Video", "true" )
    liz.setProperty( "Fanart_Image", fanart )
    liz.addContextMenuItems(contextMenuItems, replaceItems=True)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
    return ok

def resolve_dailymotion_channels(url):
    url = dailymotion_play(url)
    item = xbmcgui.ListItem(path=url)
    return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

def add_freedocast_channels(name,url,premiered,epg):
    if settings.getSetting(name) == "false": return
    mode = 906
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok = True
    contextMenuItems = []
    iconimage = logopath+name+'.png'
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Label": name, "Duration": "1440", "Plot": epg, "Premiered": premiered } )
    liz.setProperty("IsPlayable", "true")
    liz.setProperty( "Video", "true" )
    liz.setProperty( "Fanart_Image", fanart )
    liz.addContextMenuItems(contextMenuItems, replaceItems=True)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
    return ok

def resolve_freedocast_channels(url):
    url = freedocast_play(url)
    item = xbmcgui.ListItem(path=url)
    return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

def add_justin_channels(name,url,premiered,epg):
    if settings.getSetting(name) == "false": return
    mode = 907
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok = True
    contextMenuItems = []
    iconimage = logopath+name+'.png'
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Label": name, "Duration": "1440", "Plot": epg, "Premiered": premiered } )
    liz.setProperty("IsPlayable", "true")
    liz.setProperty( "Video", "true" )
    liz.setProperty( "Fanart_Image", fanart )
    liz.addContextMenuItems(contextMenuItems, replaceItems=True)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
    return ok

def resolve_justin_channels(url):
    url = justin_play(url)
    item = xbmcgui.ListItem(path=url)
    return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?','')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


params = get_params()
url = None
name = None
mode = None
try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass


if mode == None or url == None or len(url) < 1:
    get_channels()

elif mode == 901:
    resolve_wowza_channels(url)

elif mode == 902:
    resolve_visionip_channels(url)

elif mode == 903:
    resolve_livestream_channels(url)

elif mode == 904:
    resolve_ustream_channels(url)

elif mode == 905:
    resolve_dailymotion_channels(url)

elif mode == 906:
    resolve_freedocast_channels(url)

elif mode == 907:
    resolve_justin_channels(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
