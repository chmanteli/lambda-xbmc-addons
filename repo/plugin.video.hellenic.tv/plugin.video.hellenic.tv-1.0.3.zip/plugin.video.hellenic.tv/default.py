# -*- coding: cp1253 -*-

'''
    hellenic tv XBMC Addon
    Copyright (C) 2012 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib,urllib2,re,os,xbmcplugin,xbmcgui,xbmcaddon


settings = xbmcaddon.Addon(id='plugin.video.hellenic.tv')
data = 'special://profile/addon_data/plugin.video.hellenic.tv'

home = settings.getAddonInfo('path')
language = settings.getLocalizedString
addonname = settings.getAddonInfo("name")
description = language(30020).encode("utf-8")
icon = xbmc.translatePath(os.path.join(home,'icon.png'))
fanart = xbmc.translatePath(os.path.join(home,'fanart.jpg'))
logoPath = xbmc.translatePath(os.path.join(home,'resources/logos/'))
datapath = xbmc.translatePath(data)
skin = xbmc.getSkinDir()

xbmcplugin.setContent(int(sys.argv[1]), 'Episodes')
xbmcplugin.setPluginFanart(int(sys.argv[1]), fanart)


epg = 'http://tv.pathfinder.gr/now/'
epg_pattern_1 = '<a href="%s/(.+?)">(.+?)</a>.+?<td>(.+?)</td>'
#example: '<a href="net/(.+?)">(.+?)</a>.+?<td>(.+?)</td>'
epg_pattern_2 = '</div><div class="movie_header">.+?<p>(.+?)</p>'


def xbmc_view():
    viewenable = settings.getSetting("viewenable")

    if (skin == 'skin.confluence' or skin == 'skin.confluence-vertical' \
    or skin == 'skin.confluence.moviesets'):
        if viewenable == 'true':
            confluence_views = [50,51,500,503,504]
            view = int(settings.getSetting("confluence"))
            xbmc.executebuiltin("Container.SetViewMode("+str(confluence_views[view])+")")

    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        if viewenable == 'true':
            rapier_views = [50,52,74,73,68,94]
            view = int(settings.getSetting("rapier"))
            xbmc.executebuiltin("Container.SetViewMode("+str(rapier_views[view])+")")

def xbmc_webserver():
    if xbmc.executehttpapi("GetGuiSetting(1, services.webserver)")[4:] == "False":
        try:
            forcedserver = settings.getSetting("ForcedWebServer") == "True"
        except:
            forcedserver = False

        if forcedserver == False:
            dlg = xbmcgui.Dialog()
            retval = dlg.yesno(addonname, language(30296).encode("utf-8"), language(30295).encode("utf-8"))
            settings.setSetting("ForcedWebServer", "True")

            if retval:
                dlg.ok(addonname, language(30294).encode("utf-8"), language(30293).encode("utf-8"))
                xbmc.executehttpapi("SetGUISetting(1, services.webserver, true)")

			
def GetURL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    link = link.replace('\n','')
    return link


def get_epg():
	link = GetURL(epg)
	return link

def get_mega_epg(link):
	try:
		for a,b,c in re.compile(epg_pattern_1 %('mega')).findall(link): c = c
		for c in re.compile(epg_pattern_2).findall(GetURL(epg+a)): c = c 
		mega_epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), b, c)
		return mega_epg
	except:
	    pass

def get_ant1_epg(link):
	try:
		for a,b,c in re.compile(epg_pattern_1 %('ant1')).findall(link): c = c
		for c in re.compile(epg_pattern_2).findall(GetURL(epg+a)): c = c 
		ant1_epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), b, c)
		return ant1_epg
	except:
	    pass

def get_alpha_epg(link):
	try:
		for a,b,c in re.compile(epg_pattern_1 %('alpha')).findall(link): c = c
		for c in re.compile(epg_pattern_2).findall(GetURL(epg+a)): c = c 
		alpha_epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), b, c)
		return alpha_epg
	except:
	    pass

def get_star_epg(link):
	try:
		for a,b,c in re.compile(epg_pattern_1 %('star')).findall(link): c = c
		for c in re.compile(epg_pattern_2).findall(GetURL(epg+a)): c = c 
		star_epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), b, c)
		return star_epg
	except:
	    pass

def get_skai_epg(link):
	try:
		for a,b,c in re.compile(epg_pattern_1 %('skai')).findall(link): c = c
		for c in re.compile(epg_pattern_2).findall(GetURL(epg+a)): c = c 
		skai_epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), b, c)
		return skai_epg
	except:
	    pass

def get_net_epg(link):
	try:
		for a,b,c in re.compile(epg_pattern_1 %('net')).findall(link): c = c
		for c in re.compile(epg_pattern_2).findall(GetURL(epg+a)): c = c 
		net_epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), b, c)
		return net_epg
	except:
	    pass

def get_et1_epg(link):
	try:
		for a,b,c in re.compile(epg_pattern_1 %('et1')).findall(link): c = c
		for c in re.compile(epg_pattern_2).findall(GetURL(epg+a)): c = c 
		et1_epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), b, c)
		return et1_epg
	except:
	    pass

def get_et3_epg(link):
	try:
		for a,b,c in re.compile(epg_pattern_1 %('et3')).findall(link): c = c
		for c in re.compile(epg_pattern_2).findall(GetURL(epg+a)): c = c 
		et3_epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), b, c)
		return et3_epg
	except:
	    pass

def get_vouli_epg(link):
	try:
		for a,b,c in re.compile(epg_pattern_1 %('vouli')).findall(link): c = c
		for c in re.compile(epg_pattern_2).findall(GetURL(epg+a)): c = c 
		vouli_epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), b, c)
		return vouli_epg
	except:
	    pass

def get_channels():
    xbmc_webserver()

    if settings.getSetting("epgenable") == 'true':
        link = get_epg()
        mega_epg = get_mega_epg(link)
        ant1_epg = get_ant1_epg(link)
        alpha_epg = get_alpha_epg(link)
        star_epg = get_star_epg(link)
        skai_epg = get_skai_epg(link)
        net_epg = get_net_epg(link)
        et1_epg = get_et1_epg(link)
        et3_epg = get_et3_epg(link)
        vouli_epg = get_vouli_epg(link)
    else:
        mega_epg = None
        ant1_epg = None
        alpha_epg = None
        star_epg = None
        skai_epg = None
        net_epg = None
        et1_epg = None
        et3_epg = None
        vouli_epg = None


    name = 'MEGA'
    premiered = '1989'
    url = 'rtmp://178.162.134.45:80/megaweb playpath=megaweb.sdp pageUrl=http://www.kanalia.eu/ live=true timeout=10'
    if mega_epg is None: epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30101).encode("cp1253"))
    else: epg = mega_epg
    add_channels(name,url,premiered,epg)

    name = 'ANT1'
    premiered = '1989'
    url = 'rtmp://tmplive.ant1.gr:80/live playpath=ant1tvnilova swfUrl=http://static.ant1.gr/live.ashx pageUrl=http://webtv.antenna.gr/webtv/live conn=B:0 swfVfy=true live=true'
    if ant1_epg is None: epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30102).encode("cp1253"))
    else: epg = ant1_epg
    add_channels(name,url,premiered,epg)

    name = 'ALPHA'
    premiered = '1993'
    url = 'rtmp://178.162.134.45:80/kanali10 playpath=kanali10.sdp pageUrl=http://www.kanalia.eu/ live=true timeout=10'
    if alpha_epg is None: epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30103).encode("cp1253"))
    else: epg = alpha_epg
    add_channels(name,url,premiered,epg)

    name = 'STAR'
    premiered = '1993'
    url = 'mms://206.222.31.146/star1?sid=18d43610-3556-47bd-bdab-a7ab48d78a5d-15-120756 live=true timeout=10'
    if star_epg is None: epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30104).encode("cp1253"))
    else: epg = star_epg
    add_channels(name,url,premiered,epg)

    name = 'SKAI'
    premiered = '2006'
    url = 'rtmp://cp76154.live.edgefcs.net/live/ playpath=TV_LIVE_1@10773 swfUrl=http://www.skai.gr/files/1/Flash/Shows/SkaiMediaPlayer.swf pageUrl=http://www.skai.gr/player/tvlive/ swfVfy=true live=true timeout=10'
    if skai_epg is None: epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30105).encode("cp1253"))
    else: epg = skai_epg
    add_channels(name,url,premiered,epg)

    name = 'NET'
    premiered = '1966'
    url = 'rtmp://cp76856.live.edgefcs.net/live/ playpath=GRERT_vid_nogeo_NET@25927 pageUrl=http://www.ert.gr/webtv/index.php live=true timeout=10'
    if net_epg is None: epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30106).encode("cp1253"))
    else: epg = net_epg
    add_channels(name,url,premiered,epg)

    name = 'ET1'
    premiered = '1966'
    url = 'rtmp://cp76856.live.edgefcs.net/live/ playpath=GRERT_vid_nogeo_ET1@25926 pageUrl=http://www.ert.gr/webtv/index.php live=true timeout=10'
    if et1_epg is None: epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30107).encode("cp1253"))
    else: epg = et1_epg
    add_channels(name,url,premiered,epg)

    name = 'ET3'
    premiered = '1988'
    url = 'rtmp://178.162.134.45:80/alterweb playpath=alterweb.sdp pageUrl=http://www.kanalia.eu/ live=true timeout=10'
    if et3_epg is None: epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30108).encode("cp1253"))
    else: epg = et3_epg
    add_channels(name,url,premiered,epg)
	
    name = 'BOYLH TV'
    premiered = '1999'
    url = 'mms://media19.internet.gr/ParliamentTV-HQ'
    if vouli_epg is None: epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30110).encode("cp1253"))
    else: epg = vouli_epg
    add_channels(name,url,premiered,epg)

    name = 'ERT WORLD'
    premiered = '1996'
    url = 'mms://wms3.visionip.tv/Hellenic-2'
    epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30109).encode("cp1253"))
    add_channels(name,url,premiered,epg)

    name = 'MAD'
    premiered = '1996'
    url = 'rtmp://freeview.fms.visionip.tv/live/tvnetwork-hellenictv-htv_music-hsslive-25f-4x3-SDh live=true timeout=10'
    epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30127).encode("cp1253"))
    add_channels(name,url,premiered,epg)

    name = 'MTV NRG'
    premiered = '2011'
    url = 'mms://wms-01.visionip.tv/Hellenic-Energy'
    epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30111).encode("cp1253"))
    add_channels(name,url,premiered,epg)

    name = 'KONTRA'
    premiered = '2010'
    url = 'rtmp://flashcloud.mediacdn.com/live/ playpath=kontratv pageUrl=http://live24.gr/webtv/kontrachannel/ live=true timeout=10'
    epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30112).encode("cp1253"))
    add_channels(name,url,premiered,epg)

    name = 'EXTRA 3'
    premiered = '2001'
    url = 'rtmp://cp115021.live.edgefcs.net/live/ playpath=extragtnet@49573 pageUrl=http://www.extra3.tv/ live=true timeout=10'
    epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30113).encode("cp1253"))
    add_channels(name,url,premiered,epg)
	
    name = 'CHANNEL 9'
    premiered = '2005'
    url = 'rtmp://212-102.livestream.com/mogulus-stream-edge/channel9gr/rtmp://212-58.livestream.com/affiliateStream/channel9gr/6c69766572657065617465723a72746d703a2f2f3231322d35382e6c69766573747265616d2e636f6d2f6d6f67756c75732f6368616e6e656c3967722f6368616e6e656c39 swfUrl=http://cdn.livestream.com/chromelessPlayer/v20/playerapi.swf pageUrl=http://www.livestream.com/channel9gr swfVfy=true live=true timeout=10'
    epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30114).encode("cp1253"))
    #add_channels(name,url,premiered,epg)
	
    name = 'SUNNY CHANNEL'
    premiered = '2012'
    url = 'rtmp://212-106.livestream.com/mogulus-stream-edge/sunnychannelgr/rtmp://212-72.livestream.com/affiliateStream/sunnychannelgr/6c69766572657065617465723a72746d703a2f2f3231322d37322e6c69766573747265616d2e636f6d2f6d6f67756c75732f73756e6e796368616e6e656c67722f64656d6f swfUrl=http://cdn.livestream.com/chromelessPlayer/v20/playerapi.swf pageUrl=http://www.livestream.com/sunnychannelgr swfVfy=true live=true timeout=10'
    epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30115).encode("cp1253"))
    #add_channels(name,url,premiered,epg)

    name = 'Body In Balance'
    premiered = '2011'
    url = 'rtmp://flashcloud.mediacdn.com/live/ playpath=shoptv pageUrl=http://www.bodyinbalance.gr/webtv.php/ live=true timeout=10'
    epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30116).encode("cp1253"))
    add_channels(name,url,premiered,epg)

    name = 'TELEASTY'
    premiered = '1990'
    url = 'mms://wms-01.visionip.tv/hellenic-teleasty'
    epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30117).encode("cp1253"))
    add_channels(name,url,premiered,epg)

    name = '902 TV'
    premiered = '1990'
    url = 'mms://wms-03.visionip.tv/hellenic902'
    epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30118).encode("cp1253"))
    add_channels(name,url,premiered,epg)

    name = 'BLUE SKY'
    premiered = '1990'
    url = 'mms://live.blueskytv.gr:8083/publishingpoint1'
    epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30119).encode("cp1253"))
    #add_channels(name,url,premiered,epg)

    name = 'MEGA CYPRUS'
    premiered = '1999'
    url = 'mms://wms-01.visionip.tv/Hellenic-mega'
    epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30120).encode("cp1253"))
    add_channels(name,url,premiered,epg)
	
    name = 'ANT1 CYPRUS'
    premiered = '1993'
    url = 'rtmpt://videos.ant1.com.cy:80/livepkgr playpath=livestream?adbe-live-event=liveevent swfUrl=http://www.ant1.com.cy/flowplayer.rtmp-3.1.3.swf pageUrl=http://www.ant1.com.cy/livestreaming/ swfVfy=true live=true'
    #url = 'rtmp://109.163.236.116/streamhq playpath=122810 pageUrl=http://streamhq.tv/player.php?channel_id=122810 live=true timeout=10'
    epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30121).encode("cp1253"))
    add_channels(name,url,premiered,epg)

    name = 'SIGMA'
    premiered = '1995'
    url = 'mms://wms3.visionip.tv/Hellenic-s'
    epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30122).encode("cp1253"))
    add_channels(name,url,premiered,epg)

    name = 'TV PLUS'
    premiered = '2006'
    url = 'mms://wms-01.visionip.tv/hellenic-tv-plus'
    epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30123).encode("cp1253"))
    add_channels(name,url,premiered,epg)

    name = 'RIK SAT'
    premiered = '1957'
    url = 'rtmp://s10.webvideocore.net/live/ playpath=7zlyq17szhc0o0wwsg4o pageUrl=http://www.cybc.com.cy/video-on-demand/index.php?option=com_content&view=article&id=681&Itemid=83 live=true timeout=10'
    epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30124).encode("cp1253"))
    add_channels(name,url,premiered,epg)

    name = '4E TV'
    premiered = ''
    url = 'rtmp://82.192.84.30:1935/live playpath=myStream.sdp pageUrl=http://www.tv4e.gr/livestreaming.php live=true timeout=10'
    epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30125).encode("cp1253"))
    add_channels(name,url,premiered,epg)

    name = 'TELESPORT'
    premiered = '2011'
    url = 'rtmp://tv1.streampulse.eu/tilesport/ playpath=movie1 pageUrl=http://www.tilesport.tv/ live=true timeout=10'
    epg = "[B][%s] - %s[/B]\n%s" %(language(30100).encode("cp1253"), name, language(30126).encode("cp1253"))
    add_channels(name,url,premiered,epg)
	
    xbmc_view()

def add_channels(name,url,premiered,epg):
    ok=True
    contextMenuItems = []
    iconimage = logoPath+name+'.png'
    liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Label": name, "Duration": "24h", "Plot": epg, "Premiered": premiered } )
    liz.setProperty("IsPlayable", "true")
    liz.setProperty( "Video", "true" )
    liz.setProperty( "Fanart_Image", fanart )
    liz.addContextMenuItems(contextMenuItems, replaceItems=True)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
    return ok


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?','')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


params = get_params()
url = None
name = None
mode = None
try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass


if mode==None or url==None or len(url)<1:
    get_channels()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
