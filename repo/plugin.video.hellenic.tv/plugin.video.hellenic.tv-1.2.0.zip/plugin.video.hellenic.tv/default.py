# -*- coding: utf-8 -*-

'''
    hellenic tv XBMC Addon
    Copyright (C) 2012 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib,urllib2,re,os,xbmcplugin,xbmcgui,xbmcaddon
from urllib2 import Request, build_opener, HTTPCookieProcessor, HTTPHandler
import cookielib
try: import json
except: import simplejson as json

settings = xbmcaddon.Addon(id='plugin.video.hellenic.tv')
data = 'special://profile/addon_data/plugin.video.hellenic.tv'

home = settings.getAddonInfo('path')
language = settings.getLocalizedString
addonname = settings.getAddonInfo("name")
justinaddon = xbmcaddon.Addon(id='plugin.video.jtv.archives').getAddonInfo('name')
icon = xbmc.translatePath(os.path.join(home,'icon.png'))
fanart = xbmc.translatePath(os.path.join(home,'fanart.jpg'))
logopath = xbmc.translatePath(os.path.join(home,'resources/logos/'))
datapath = xbmc.translatePath(data)
skin = xbmc.getSkinDir()

xbmcplugin.setContent(int(sys.argv[1]), 'Episodes')
xbmcplugin.setPluginFanart(int(sys.argv[1]), fanart)


def check_addon(id):
    try:
        check_addon = xbmcaddon.Addon(id=id).getAddonInfo("name")
        if not check_addon == addonname:
            return check_addon
        else:
            return
    except:
        return

def xbmc_view():
    viewenable = settings.getSetting("viewenable")

    if (skin == 'skin.confluence' or skin == 'skin.confluence.svn') and viewenable == 'true':
        confluence_views = [50,51,500,504,503,515]
        view = int(settings.getSetting("confluence"))
        xbmc.executebuiltin("Container.SetViewMode("+str(confluence_views[view])+")")

    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn') and viewenable == 'true':
        rapier_views = [50,52,74,73,68,94]
        view = int(settings.getSetting("rapier"))
        xbmc.executebuiltin("Container.SetViewMode("+str(rapier_views[view])+")")

def xbmc_webserver():
    try:
        forcedserver = settings.getSetting("ForcedWebServer") == "True"
        if forcedserver:
            return
    except:
        forcedserver = False

    try:
        guisettings = xbmc.translatePath('special://masterprofile/guisettings.xml')
        read = open(guisettings, 'r')
        text = read.read()
        read.close()
        if not text.find('<webserver>true</webserver>') == -1:
            return
    except:
        pass

    if forcedserver == False:
        retval = xbmcgui.Dialog().yesno(addonname, language(30201).encode("utf-8"), language(30202).encode("utf-8"))
        settings.setSetting("ForcedWebServer", "True")
        if retval:
            xbmcgui.Dialog().ok(addonname, language(30203).encode("utf-8"), language(30204).encode("utf-8"))
            xbmc.executehttpapi("SetGUISetting(1, services.webserver, true)")
			
def GetURL(url,referer=None):
    if referer is None:
        headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0'}
    else:
        headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0', 'Referer' : referer}
    req = urllib2.Request(url,None,headers)
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    link = link.replace('\n','')
    return link

def GetURL2(url,referer=None):
    if referer is None:
        headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0'}
    else:
        headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0', 'Referer' : referer}
    req = urllib2.Request(url, None, headers)
    response = urllib2.urlopen(req)
    link = response.geturl()
    return link

def GetURL3(url,cookie_url):
    cj = cookielib.CookieJar()
    opener = build_opener(HTTPCookieProcessor(cj), HTTPHandler())
    req = Request(cookie_url)
    response = opener.open(req)
    response.close()
    for cookie in cj:
        cookie = '%s=%s' % (cookie.name, cookie.value)
    headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0', 'Cookie' : cookie}
    req = urllib2.Request(url,None,headers)
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    link = link.replace('\n','')
    return link

def get_epg(name,description):
    epg = "[B][%s] - %s[/B]\n%s" %(language(30200).encode("utf-8"), name, description.encode("utf-8"))
    return epg

def get_pathfinder_data():
    try:
        pathfinder = GetURL('http://tv.pathfinder.gr/now/')
        return pathfinder
    except:
        return

def get_pathfinder(pathfinder,name,channel,description):
    try:
        if settings.getSetting("epgenable") == 'true':
            temp = re.search('<a href="%s/(.+?)">(.+?)</a>.+?<td>(.+?)</td>' %(channel), pathfinder)
            a,b,c = temp.groups()
            temp = GetURL('http://tv.pathfinder.gr/now/%s' % a)
            c = re.compile('</div><div class="movie_header">.+?<p>(.+?)</p>').findall(temp)[0]
            epg = "[B][%s] - %s[/B]\n%s" %(language(30200).encode("cp1253"), b, c)
            return epg.decode("cp1253")
        else:
            epg = "[B][%s] - %s[/B]\n%s" %(language(30200).encode("cp1253"), name, description.encode("cp1253"))
            return epg.decode("cp1253")
    except:
        epg = "[B][%s] - %s[/B]\n%s" %(language(30200).encode("cp1253"), name, description.encode("cp1253"))
        return epg.decode("cp1253")

def get_total():
    total = 0
    if settings.getSetting('MEGA') == "true" : total = total + 1
    if settings.getSetting('ANT1') == "true" : total = total + 1
    if settings.getSetting('STAR') == "true" : total = total + 1
    if settings.getSetting('ALPHA') == "true" : total = total + 1
    if settings.getSetting('SKAI') == "true" : total = total + 1
    if settings.getSetting('NET') == "true" : total = total + 1
    if settings.getSetting('ET1') == "true" : total = total + 1
    if settings.getSetting('ET3') == "true" : total = total + 1
    if settings.getSetting('ERT WORLD') == "true" : total = total + 1
    if settings.getSetting('BOYLH TV') == "true" : total = total + 1
    if settings.getSetting('EURONEWS') == "true" : total = total + 1
    if settings.getSetting('MEGA CYPRUS') == "true" : total = total + 1
    if settings.getSetting('ANT1 CYPRUS') == "true" : total = total + 1
    if settings.getSetting('SIGMA') == "true" : total = total + 1
    if settings.getSetting('TV PLUS') == "true" : total = total + 1
    if settings.getSetting('RIK SAT') == "true" : total = total + 1
    if settings.getSetting('MAD') == "true" : total = total + 1
    if settings.getSetting('ACTION 24') == "true" : total = total + 1
    if settings.getSetting('KONTRA') == "true" : total = total + 1
    if settings.getSetting('EXTRA 3') == "true" : total = total + 1
    if settings.getSetting('ZOUGLA TV') == "true" : total = total + 1
    if settings.getSetting('CHANNEL 9') == "true" : total = total + 1
    if settings.getSetting('BLUE SKY') == "true" : total = total + 1
    if settings.getSetting('ART CHANNEL') == "true" : total = total + 1
    if settings.getSetting('ART SPORT') == "true" : total = total + 1
    if settings.getSetting('0-6 TV') == "true" : total = total + 1
    if settings.getSetting('HIGH TV') == "true" : total = total + 1
    if settings.getSetting('STAR KENTRIKIS ELLADOS') == "true" : total = total + 1
    if settings.getSetting('ENA TV') == "true" : total = total + 1
    if settings.getSetting('ASTRA TV') == "true" : total = total + 1
    if settings.getSetting('EPIRUS TV1') == "true" : total = total + 1
    if settings.getSetting('ITV') == "true" : total = total + 1
    if settings.getSetting('ACHELOOS TV') == "true" : total = total + 1
    if settings.getSetting('START TV') == "true" : total = total + 1
    if settings.getSetting('CORFU CHANNEL') == "true" : total = total + 1
    if settings.getSetting('SUPER B') == "true" : total = total + 1
    if settings.getSetting('ACHAIA CHANNEL') == "true" : total = total + 1
    if settings.getSetting('LEPANTO') == "true" : total = total + 1
    if settings.getSetting('ORT') == "true" : total = total + 1
    if settings.getSetting('BEST TV') == "true" : total = total + 1
    if settings.getSetting('ELLADA TV') == "true" : total = total + 1
    if settings.getSetting('KRITI TV') == "true" : total = total + 1
    if settings.getSetting('CRETA TV') == "true" : total = total + 1
    if settings.getSetting('NEA TV') == "true" : total = total + 1
    if settings.getSetting('KYDON TV') == "true" : total = total + 1
    if settings.getSetting('KISSAMOS TV') == "true" : total = total + 1
    if settings.getSetting('IRIDA TV') == "true" : total = total + 1
    if settings.getSetting('KOSMOS') == "true" : total = total + 1
    if settings.getSetting('DIRAS TV') == "true" : total = total + 1
    if settings.getSetting('TV12') == "true" : total = total + 1
    if settings.getSetting('ARCHIPELAGOS TV') == "true" : total = total + 1
    if settings.getSetting('TVM') == "true" : total = total + 1
    if settings.getSetting('SYROS TV1') == "true" : total = total + 1
    if settings.getSetting('TV 100') == "true" : total = total + 1
    if settings.getSetting('EGNATIA TV') == "true" : total = total + 1
    if settings.getSetting('VERGINA TV') == "true" : total = total + 1
    if settings.getSetting('EUROPE 1') == "true" : total = total + 1
    if settings.getSetting('DION TV') == "true" : total = total + 1
    if settings.getSetting('4E TV') == "true" : total = total + 1
    if settings.getSetting('WEST CHANNEL') == "true" : total = total + 1
    if settings.getSetting('FLASH TV') == "true" : total = total + 1
    if settings.getSetting('TOP CHANNEL') == "true" : total = total + 1
    if settings.getSetting('ENA CHANNEL') == "true" : total = total + 1
    if settings.getSetting('STAR TV DRAMA') == "true" : total = total + 1
    if settings.getSetting('DIKTYO TV') == "true" : total = total + 1
    if settings.getSetting('DELTA TV') == "true" : total = total + 1
    if settings.getSetting('R CHANNEL') == "true" : total = total + 1
    return total

def get_channels():
    total = get_total()
    pathfinder = get_pathfinder_data()

    '''======== PANHELLENIC =============================='''

    name = 'MEGA'
    premiered = '1989'
    type = 'wowza'
    url = 'megaweb'
    base = 'http://kanalia.eu/player.php?id=36'
    epg = get_pathfinder(pathfinder,name,'mega',language(30501))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'ANT1'
    premiered = '1989'
    type = None
    url = 'rtmp://tmplive.ant1.gr:80/live playpath=ant1tvnilova swfUrl=http://static.ant1.gr/live.ashx pageUrl=http://webtv.antenna.gr/webtv/live conn=B:0 swfVfy=true live=true timeout=10'
    base = 'http://www.antenna.gr/webtv/live'
    epg = get_pathfinder(pathfinder,name,'ant1',language(30502))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'STAR'
    premiered = '1993'
    #type = 'wowza'
    #url = 'alterweb'
    #base = 'http://kanalia.eu/player.php?id=40'
    type = 'asx'
    url = 'http://koproskylo.webatu.com/channels/greece-star-tv.asx'
    base = 'http://www.tvfromgreece.com/2011/08/star-tv.html'
    epg = get_pathfinder(pathfinder,name,'star',language(30503))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'ALPHA'
    premiered = '1993'
    type = 'wowza'
    url = 'kanali10'
    base = 'http://kanalia.eu/player.php?id=35'
    #type = None
    #url = 'http://alfakanali-lh.akamaihd.net/i/live_1@90368/index_800_av-b.m3u8'
    #base = 'http://www.alphatv.gr/Live.aspx'
    epg = get_pathfinder(pathfinder,name,'alpha',language(30504))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'SKAI'
    premiered = '2006'
    type = 'skai'
    url = 'http://www.skai.gr/player/tvlive/'
    base = 'http://www.skai.gr/player/tvlive/'
    epg = get_pathfinder(pathfinder,name,'skai',language(30505))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'NET'
    premiered = '1966'
    type = None
    url = 'rtmp://cp76856.live.edgefcs.net/live/ playpath=GRERT_vid_nogeo_NET@25927 live=true timeout=10'
    base = 'http://www.ert.gr/webtv/web-tv-live/net-live'
    epg = get_pathfinder(pathfinder,name,'net',language(30506))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'ET1'
    premiered = '1966'
    type = None
    url = 'rtmp://cp76856.live.edgefcs.net/live/ playpath=GRERT_vid_nogeo_ET1@25926 live=true timeout=10'
    base = 'http://www.ert.gr/webtv/web-tv-live/et1-live'
    epg = get_pathfinder(pathfinder,name,'et1',language(30507))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'ET3'
    premiered = '1988'
    type = None
    url = 'rtmp://cp76856.live.edgefcs.net/live/ playpath=GRERT_vid_nogeo_ET3@25928 live=true timeout=10'
    base = 'http://www.ert.gr/webtv/web-tv-live/et3-live'
    epg = get_pathfinder(pathfinder,name,'et3',language(30508))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'ERT WORLD'
    premiered = '1996'
    type = 'visioniptv'
    url = 'http://tvnetwork.new.visionip.tv/Hellenic_TV/index.php?module=playlist&type=jwASX&broadcastid=4267'
    base = 'http://tvnetwork.new.visionip.tv/Hellenic_TV'
    epg = get_epg(name,language(30509))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'BOYLH TV'
    premiered = '1999'
    type = None
    url = 'rtmp://streamer0.grnet.gr/parliament playpath=parltv.sdp live=true timeout=10'
    base = 'http://www.hellenicparliament.gr/Enimerosi/Vouli-Tileorasi'
    epg = get_pathfinder(pathfinder,name,'vouli',language(30510))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'EURONEWS'
    premiered = '1993'
    type = None
    url = 'rtmp://fr-par-5.stream-relay.hexaglobe.net:1935/rtpeuronewslive/ playpath=gr_video350_flash_all.sdp swfUrl=http://gr.euronews.com/media/player_live_1_14.swf swfVfy=true live=true timeout=10'
    base = 'http://gr.euronews.com/news/streaming-live/'
    epg = get_epg(name,language(30511))
    add_channels(total,name,url,base,premiered,epg,type)

    '''======== CYPRUS =============================='''

    name = 'MEGA CYPRUS'
    premiered = '1999'
    type = None
    url = 'http://stream.livenews.com.cy/livenews.isml/manifest(format=m3u8-aapl).m3u8'
    base = 'http://www.livenews.com.cy/cgibin/hweb?-A=5&-V=livestreaming'
    epg = get_epg(name,language(30521))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'ANT1 CYPRUS'
    premiered = '1993'
    type = None
    url = 'rtmp://videos.ant1.com.cy:80/livepkgr playpath=livestream?adbe-live-event=liveevent swfUrl=http://www.ant1iwo.com/flowplayer.rtmp-3.1.3.swf pageUrl=http://www.ant1iwo.com/livestreaming/ swfVfy=true live=true timeout=10'
    base = 'http://www.ant1iwo.com/livestreaming/'
    epg = get_epg(name,language(30522))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'SIGMA'
    premiered = '1995'
    type = 'videopublishing'
    url = 'http://static.videopublishing.com/?publish=4f331df9922959fc7bd3ba07c10f0f00'
    base = 'http://www.sigmatv.com/'
    epg = get_epg(name,language(30523))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'TV PLUS'
    premiered = '2006'
    type = None
    url = 'rtmp://qatar.zcast.us/liveedge/plustv-beYfikcyBZ pageUrl=http://zcast.us/gen.php?ch=plustv-beYfikcyBZ live=true timeout=10'
    base = 'http://www.lakatamia.tv/cyprus-tv-radios/tv/cncplus-tv.html'
    epg = get_epg(name,language(30524))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'RIK SAT'
    premiered = '1957'
    #url = 'rtmp://m4.webvideocore.net/live/ playpath=7zlyq17szhc0o0wwsg4o swfUrl=http://play.streamingvideoprovider.com/player2.swf swfVfy=true live=true timeout=10'
    #base = 'http://www.cybc.com.cy/index.php/tv?id=90'
    type = 'visioniptv'
    url = 'http://tvnetwork.new.visionip.tv/Hellenic_TV/index.php?module=playlist&type=jwASX&broadcastid=4264'
    base = 'http://tvnetwork.new.visionip.tv/Hellenic_TV'
    epg = get_epg(name,language(30525))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'MAD CYPRUS'
    premiered = '2011'
    type = 'visioniptv'
    url = 'http://tvnetwork.new.visionip.tv/Hellenic_TV/index.php?module=playlist&type=jwASX&broadcastid=4271'
    base = 'http://tvnetwork.new.visionip.tv/Hellenic_TV'
    epg = get_epg(name,language(30526))
    #add_channels(total,name,url,base,premiered,epg,type)

    '''======== ATTICA - AIGINA YMHTTOS =============================='''

    name = 'MAD'
    premiered = '1996'
    type = 'madtv'
    url = 'http://www.mad.tv/players/madtv/'
    base = 'http://www.mad.tv/players/madtv/'
    epg = get_epg(name,language(30541))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'ACTION 24'
    premiered = ''
    type = 'viiideo'
    url = 'http://action24.viiideo.gr/'
    base = 'http://action24.gr/'
    epg = get_epg(name,language(30542))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'KONTRA'
    premiered = '2010'
    type = None
    url = 'rtmp://flashcloud.mediacdn.com/live/ playpath=kontratv live=true timeout=10'
    base = 'http://live24.gr/webtv/kontrachannel/'
    epg = get_epg(name,language(30543))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'EXTRA 3'
    premiered = '2001'
    type = None
    url = 'rtmp://cp115021.live.edgefcs.net/live/ playpath=extragtnet@49573 live=true timeout=10'
    base = 'http://www.extra3.tv/'
    epg = get_epg(name,language(30544))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'ZOUGLA TV'
    premiered = ''
    type = None
    url = 'rtmp://cp67108.live.edgefcs.net/live/ playpath=zouglaradio@15863 live=true timeout=10'
    base = 'http://www.zougla.gr/live'
    epg = get_epg(name,language(30545))
    add_channels(total,name,url,base,premiered,epg,type)
	
    name = 'CHANNEL 9'
    premiered = '2005'
    type = 'livestream'
    url = 'http://www.livestream.com/channel9gr'
    base = 'http://www.channel9.gr/livestream/'
    epg = get_epg(name,language(30546))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'BLUE SKY'
    premiered = '1990'
    type = None
    url = 'mms://live.blueskytv.gr:8083/publishingpoint1'
    base = 'http://www.blueskytv.gr/live-tv/'
    epg = get_epg(name,language(30548))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'ART CHANNEL'
    premiered = '1990'
    type = 'ustream'
    url = 'http://www.ustream.tv/channel/teleasty'
    base = 'http://teleasty.site50.net/'
    epg = get_epg(name,language(30550))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'ART SPORT'
    premiered = '2011'
    type = None
    url = 'rtmp://tv1.streampulse.eu/tilesport/ playpath=movie1 pageUrl=http://www.tilesport.tv/ live=true timeout=10'
    base = 'http://www.tilesport.tv/index_live.php'
    epg = get_epg(name,language(30551))
    add_channels(total,name,url,base,premiered,epg,type)

    name = '0-6 TV'
    premiered = ''
    type = 'livestream'
    url = 'http://www.livestream.com/06television'
    base = 'http://www.0-6.gr/'
    epg = get_epg(name,language(30552))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'HIGH TV'
    premiered = ''
    type = None
    url = 'mms://92.119.201.202:8079'
    base = 'http://skaisat.com/hightv.html'
    epg = get_epg(name,language(30553))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'SUNNY CHANNEL'
    premiered = '2012'
    type = 'livestream'
    url = 'http://www.livestream.com/sunnychannelgr'
    base = 'http://www.sunnychannel.tv/index.php/web-tv'
    epg = get_epg(name,language(30547))
    #add_channels(total,name,url,base,premiered,epg,type)

    name = 'BODY IN BALANCE'
    premiered = '2011'
    type = None
    url = 'rtmp://flashcloud.mediacdn.com/live/ playpath=shoptv live=true timeout=10'
    base = 'http://www.bodyinbalance.gr/home/webtv'
    epg = get_epg(name,language(30549))
    #add_channels(total,name,url,base,premiered,epg,type)

    name = 'ATTICA TV'
    base = ''
    #add_channels(total,name,'','','','')

    name = 'NICKELODEON'
    base = 'http://www.nickelodeon.gr/'
    #add_channels(total,name,'','','','')

    name = 'MTV'
    base = 'http://www.mtvgreece.gr/'
    #add_channels(total,name,'','','','')

    '''======== CENTRAL GREECE - XLWMO KRIKELLO =============================='''

    name = 'STAR KENTRIKIS ELLADOS'
    premiered = ''
    type = 'dailymotion'
    url = 'http://www.dailymotion.com/video/xqjey2_star-lamia-live-streaming_news'
    base = 'http://webtv.lamiastar.gr/index.php'
    epg = get_epg(name,language(30561))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'ENA TV'
    premiered = ''
    type = 'viiideo'
    url = 'http://enatv.viiideo.gr/'
    base = 'http://www.enatv.gr/'
    epg = get_epg(name,language(30562))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'ETV'
    base = 'http://www.etv-hellas.net/'
    #add_channels(total,name,'','','','')

    '''======== THESSALY - DOVROUTSI =============================='''

    name = 'ASTRA TV'
    premiered = ''
    type = 'livestream'
    url = 'http://www.livestream.com/astratelevision'
    base = 'http://www.astratv.gr/index.php/livetv.html'
    epg = get_epg(name,language(30581))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'THESSALIA TV'
    base = 'http://www.thessaliatv.gr/'
    #add_channels(total,name,'','','','')

    name = '�RT'
    base = 'http://www.trttv.com/'
    #add_channels(total,name,'','','','')

    name = 'TV 10'
    base = 'http://www.tv-10.gr/'
    #add_channels(total,name,'','','','')

    '''======== EPIRUS AND WEST GREECE - AKARNANIKA LIGGIADES =============================='''

    name = 'EPIRUS TV1'
    premiered = ''
    type = 'livestream'
    url = 'http://www.livestream.com/epirustv1live'
    base = 'http://epirustv1.gr/'
    epg = get_epg(name,language(30601))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'ITV'
    premiered = ''
    type = 'ustream'
    url = 'http://www.ustream.tv/channel/ioannina-tv1'
    base = '-'
    epg = get_epg(name,language(30602))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'ACHELOOS TV'
    premiered = ''
    type = 'viiideo'
    url = 'http://axeloos.viiideo.gr/'
    base = 'http://www.axeloosradio.gr/axeloos/live/'
    epg = get_epg(name,language(30603))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'START TV'
    premiered = ''
    type = None
    url = 'mms://208.75.230.34/corfutech'
    base = 'http://www.startmedia.gr/start-tv.html'
    epg = get_epg(name,language(30604))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'CORFU CHANNEL'
    premiered = ''
    type = 'ustream'
    url = 'http://www.ustream.tv/channel/corfu-tv'
    base = 'http://www.corfutv.gr/index.php?option=com_content&view=article&id=3583&Itemid=609'
    epg = get_epg(name,language(30605))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'ART TV'
    base = 'http://www.arttv.gr/'
    #add_channels(total,name,'','','','')

    name = 'KOSMO TV'
    base = ''
    #add_channels(total,name,'','','','')

    '''======== PELOPONNESE - AROH PETALIDI =============================='''

    name = 'SUPER B'
    premiered = '1990'
    type = None
    url = 'rtmp://eco.caststream.net/overmedia-tv/overmedia-tv live=true timeout=10'
    base = 'http://www.superb.gr/'
    epg = get_epg(name,language(30621))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'ACHAIA CHANNEL'
    premiered = ''
    type = None
    url = 'mms://www999.connectit.gr/stream-web'
    base = 'http://www.achaianews.gr/'
    epg = get_epg(name,language(30622))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'LEPANTO'
    premiered = '1989'
    type = None
    url = 'rtmp://159.253.143.17:1935/2274 playpath=2274 live=true timeout=10'
    base = 'http://www.lepanto-rtv.gr/players-tv/index.html'
    epg = get_epg(name,language(30623))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'ORT'
    premiered = '1993'
    type = None
    url = 'rtmp://video1-uk.datahost.gr/live/patrisnews playpath=patrisnews live=true timeout=10'
    base = 'http://www.patrisnews.com/ort-live.php'
    epg = get_epg(name,language(30624))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'BEST TV'
    premiered = ''
    type = None
    url = 'http://smooth.istoikona.net/besttv.isml/manifest(format=m3u8-aapl).m3u8'
    base = 'http://www.best-tv.gr/'
    epg = get_epg(name,language(30625))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'PATRA TV'
    base = 'http://www.patratv.gr/'
    #add_channels(total,name,'','','','')

    name = 'IONIAN CHANNEL'
    base = 'http://ioniantv.gr/'
    #add_channels(total,name,'','','','')

    name = 'MESOGEIOS TV'
    base = 'http://www.mesogeiostv.gr/'
    #add_channels(total,name,'','','','')

    name = 'NET TV'
    base = 'http://www.net-tv.gr/'
    #add_channels(total,name,'','','','')

    name = 'KOSMOS TV'
    base = ''
    #add_channels(total,name,'','','','')

    name = 'TELETIME'
    base = ''
    #add_channels(total,name,'','','','')

    '''======== PELOPONNESE - KSYLOKASTRO DOLIANA ANAVRYTH =============================='''

    name = 'ELLADA TV'
    premiered = ''
    type = None
    url = 'rtmp://fml.68FC.edgecastcdn.net/2068FC/elladatv swfUrl=http://www.elladatv.gr/scripts/player.swf swfVfy=true live=true timeout=10'
    base = 'http://www.elladatv.gr/'
    epg = get_epg(name,language(30641))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'MAX TV'
    base = 'http://www.maxtv.gr/'
    #add_channels(total,name,'','','','')

    name = 'SUPER TV'
    base = 'http://tvsupernews.blogspot.gr/'
    #add_channels(total,name,'','','','')

    name = 'DR TV'
    base = 'http://www.drtv.gr/'
    #add_channels(total,name,'','','','')

    name = 'ELECTRA TV'
    base = 'http://www.pelopas.gr/tvbio.htm'
    #add_channels(total,name,'','','','')

    name = 'AXION TV'
    base = ''
    #add_channels(total,name,'','','','')

    name = 'TOP TV'
    base = ''
    #add_channels(total,name,'','','','')

    '''======== AEGEAN - ROGDIA MALAKSA =============================='''

    name = 'KRITI TV'
    premiered = ''
    type = None
    url = 'mms://85.25.236.14/cretetv1'
    base = 'http://www.cretetv.gr/'
    epg = get_epg(name,language(30661))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'CRETA TV'
    premiered = '1992'
    type = 'viiideo'
    url = 'http://hellasonmedia.viiideo.gr/tvcreta1.html'
    base = 'http://tvcreta.gr/v2/index.php?module=menu2&cat1_id=7&cat2_id=36'
    epg = get_epg(name,language(30662))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'NEA TV'
    premiered = ''
    type = 'viiideo'
    url = 'http://hellasonmedia.viiideo.gr/neatv1.html'
    base = 'http://www.neatv.gr/el/webtv.php'
    epg = get_epg(name,language(30663))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'KYDON TV'
    premiered = ''
    type = None
    url = 'http://btslive-lh.akamaihd.net/i/live_1@87036/master.m3u8'
    base = 'http://www.kydon.gr/live2/live.html'
    epg = get_epg(name,language(30664))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'KISSAMOS TV'
    premiered = ''
    type = None
    url = 'rtmp://tvellas.net/live/kissamos live=true timeout=10'
    base = 'http://kissamostv.gr/live-streaming'
    epg = get_epg(name,language(30665))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'CHANNEL 4U'
    base = 'http://www.channel4.gr/'
    #add_channels(total,name,'','','','')

    name = 'SITIA TV'
    base = ''
    #add_channels(total,name,'','','','')

    name = 'MY TV'
    base = ''
    #add_channels(total,name,'','','','')

    name = 'TELE KRITI'
    base = ''
    #add_channels(total,name,'','','','')

    name = 'KRITI TV1'
    base = ''
    #add_channels(total,name,'','','','')

    '''======== AEGEAN - MONTE SMITH =============================='''

    name = 'IRIDA TV'
    premiered = ''
    type = None
    url = 'mms://212.251.44.111:27030'
    base = 'http://www.iridatv.gr/'
    epg = get_epg(name,language(30681))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'KOSMOS'
    premiered = ''
    type = None
    url = 'rtmp://events.yourmedia.gr:1935/ app=tvkosmos playpath=mp4:tvkosmos.mp4 live=true timeout=10'
    base = 'http://www.tvkosmos.gr/webtv.aspx'
    epg = get_epg(name,language(30683))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'DIRAS TV'
    premiered = ''
    type = None
    url = 'rtmp://www.cityofkos.gr/diras/livetv live=true timeout=10'
    base = 'http://www.diras.gr/webtv'
    epg = get_epg(name,language(30684))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'TV12'
    premiered = '1999'
    type = 'livestream'
    url = 'http://www.livestream.com/tv12dodekanisou'
    base = 'http://www.kalymnosweb.gr/tv12.htm'
    epg = get_epg(name,language(30685))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'OMEGA TV'
    premiered = ''
    type = None
    url = 'mms://stream.omegatv.net/Live'
    base = 'http://www.omegatv.net/index.php?option=com_content&view=article&id=21&Itemid=85'
    epg = get_epg(name,language(30682))
    #add_channels(total,name,url,base,premiered,epg,type)

    name = 'RED'
    base = ''
    #add_channels(total,name,'','','','')

    name = 'RODOS TV4'
    base = ''
    #add_channels(total,name,'','','','')

    name = 'TV AIGAIO'
    base = ''
    #add_channels(total,name,'','','','')

    '''======== AEGEAN - MYTILHNH =============================='''

    name = 'ARCHIPELAGOS TV'
    premiered = ''
    type = None
    url = 'mms://stream.isol.gr/ARCHIPELAGOS'
    base = 'http://www.archipelagos.tv/?p=p_5'
    epg = get_epg(name,language(30701))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'TVM'
    premiered = ''
    type = None
    url = 'rtmp://cp77174.live.edgefcs.net/live/ playpath=123456@19937 live=true timeout=10'
    base = 'http://www.tvmitilini.gr/tv-mitilini/live-tv-mitilini'
    epg = get_epg(name,language(30702))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'PATRIDA TV'
    base = 'http://www.tvpatrida.gr/'
    #add_channels(total,name,'','','','')

    '''======== AEGEAN - SYROS =============================='''

    name = 'SYROS TV1'
    premiered = ''
    type = 'wowza'
    url = 'syrostv1'
    base = 'http://www.syrostv1.gr'
    epg = get_epg(name,language(30721))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'ZEUS TV'
    base = ''
    #add_channels(total,name,'','','','')

    '''======== MACEDONIA - XORTIATHS FILIPPEIO =============================='''

    name = 'TV 100'
    premiered = '1988'
    type = None
    url = 'rtmp://eco.caststream.net:1935/tv100/ playpath=tv100 live=true timeout=10'
    base = 'http://www.fm100.gr/media/index.php?option=com_content&view=article&id=56&Itemid=57'
    epg = get_epg(name,language(30741))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'EGNATIA TV'
    premiered = ''
    type = 'ustream'
    url = 'http://www.ustream.tv/channel/egnatiatv'
    base = 'http://www.egnatia.tv/live'
    epg = get_epg(name,language(30742))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'VERGINA TV'
    premiered = ''
    type = 'livestream'
    url = 'http://www.livestream.com/verginatv'
    base = 'http://verginatv.blogspot.gr/'
    epg = get_epg(name,language(30743))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'EUROPE 1'
    premiered = ''
    type = 'ustream'
    url = 'http://www.ustream.tv/embed/12548227'
    base = 'http://www.europeone.gr/index.php?option=com_content&view=article&id=109&Itemid=142'
    epg = get_epg(name,language(30744))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'DION TV'
    premiered = ''
    type = 'ustream'
    url = 'http://www.ustream.tv/channel/dion-tv-live'
    base = 'http://www.diontv.gr/index.php?option=com_wrapper&view=wrapper&Itemid=63'
    epg = get_epg(name,language(30745))
    add_channels(total,name,url,base,premiered,epg,type)

    name = '4E TV'
    premiered = ''
    type = None
    url = 'rtmp://82.192.84.30:1935/live playpath=myStream.sdp live=true timeout=10'
    base = 'http://www.tv4e.gr/livestreaming.php'
    epg = get_epg(name,language(30746))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'KANALI 9'
    base = 'http://www.kanali9.gr/'
    #add_channels(total,name,'','','','')

    name = 'XTV'
    base = 'http://x-tv.gr/'
    #add_channels(total,name,'','','','')

    name = 'GNOMI TV'
    base = 'www.gnominet.gr/'
    #add_channels(total,name,'','','','')

    name = 'EURO CHANNEL'
    base = ''
    #add_channels(total,name,'','','','')

    name = '���� CHANNEL'
    base = ''
    #add_channels(total,name,'','','','')

    name = 'NICKELODEON+'
    base = 'http://www.nickelodeon.gr/'
    #add_channels(total,name,'','','','')

    '''======== MACEDONIA - KELLH =============================='''

    name = 'WEST CHANNEL'
    premiered = ''
    type = 'ustream'
    url = 'http://www.ustream.tv/channel/west-tv-live'
    base = 'http://www.westgroup.gr/'
    epg = get_epg(name,language(30761))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'FLASH TV'
    premiered = ''
    type = 'justin'
    url = 'http://www.justin.tv/flash_television'
    base = 'http://www.flash-tv.gr/index.php?option=com_content&view=article&id=84&Itemid=216'
    epg = get_epg(name,language(30762))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'TOP CHANNEL'
    premiered = ''
    type = 'justin'
    url = 'http://www.justin.tv/top_channel'
    base = 'http://www.top-channel.tripod.com/profil.htm'
    epg = get_epg(name,language(30763))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'PELLA TV'
    base = 'http://www.pellanet.gr/index.php?com=page&item=57'
    #add_channels(total,name,'','','','')

    name = 'TRM'
    base = 'http://www.grevenatv.gr/'
    #add_channels(total,name,'','','','')

    name = 'KANALI 28'
    base = ''
    #add_channels(total,name,'','','','')

    '''======== MACEDONIA - SERRES =============================='''

    name = 'ENA CHANNEL'
    premiered = ''
    type = 'freedocast'
    url = 'http://www.freedocast.com/charalampi'
    base = 'http://enachannel.gr/webtv/'
    epg = get_epg(name,language(30781))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'STAR TV DRAMA'
    premiered = ''
    type = None
    url = 'mms://radiofeeds1.mediabox.gr/startv'
    base = 'http://news.startvfm.gr/'
    epg = get_epg(name,language(30782))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'DIKTYO TV'
    premiered = ''
    type = 'justin'
    url = 'http://www.justin.tv/diktyotv'
    base = 'http://diktyotv.gr/'
    epg = get_epg(name,language(30783))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'TVS'
    base = ''
    epg = get_epg(name,language(30784))
    #add_channels(total,name,'','','','')

    name = 'ALFA TV'
    base = 'http://www.alfadramas.gr/'
    #add_channels(total,name,'','','','')

    name = 'CENTER TV'
    base = 'http://www.centertv.gr/'
    #add_channels(total,name,'','','','')

    name = 'TV DELTA'
    base = ''
    #add_channels(total,name,'','','','')

    name = 'TELE EPILOGES'
    base = ''
    #add_channels(total,name,'','','','')

    '''======== THRACE - PLAKA =============================='''

    name = 'DELTA TV'
    premiered = '1991'
    type = None
    url = 'mms://ams01.egihosting.com/989630'
    base = 'http://www.deltatv.gr/v2/streaming4b.htm'
    epg = get_epg(name,language(30801))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'R CHANNEL'
    premiered = '1991'
    type = 'livestream'
    url = 'http://www.livestream.com/rodopi_tv'
    base = 'http://www.tvrodopi.gr/livetv'
    epg = get_epg(name,language(30802))
    add_channels(total,name,url,base,premiered,epg,type)

    name = 'THRAKI NET'
    premiered = ''
    type = 'livestream'
    url = 'http://www.livestream.com/thrakinet_tv'
    base = 'http://www.thrakinet.tv/'
    epg = get_epg(name,language(30803))
    #add_channels(total,name,url,base,premiered,epg,type)

    name = '���� SHOP'
    base = ''
    #add_channels(total,name,'','','','')

    xbmc_view()

def add_channels(total,name,url,base,premiered,epg,type=None):
    if settings.getSetting(name) == "false": return
    if type is None: type = 'None'
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    sysbase = urllib.quote_plus(base)
    systype = urllib.quote_plus(type)
    u = '%s?name=%s&url=%s&base=%s&type=%s&mode=%s' % (sys.argv[0], sysname, sysurl, sysbase, systype, str(0))
    contextMenuItems = []
    iconimage = '%s%s.png' % (logopath, name)
    item=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Title": name, "Label": name, "Duration": "1440", "Plot": epg, "Premiered": premiered } )
    item.setProperty("IsPlayable", "true")
    item.setProperty( "Video", "true" )
    item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total)

def resolve_channels(url,base,type):
    xbmc_webserver()
    if type == 'wowza': url = wowza_play(url)
    if type == 'skai': url = skai_play(url)
    if type == 'madtv': url = madtv_play(url)
    if type == 'videopublishing': url = videopublishing_play(url)
    if type == 'visioniptv': url = visioniptv_play(url)
    if type == 'asx': url = asx_play(url)
    if type == 'youtube': url = youtube_play(url)
    if type == 'viiideo': url = viiideo_play(url)
    if type == 'livestream': url = livestream_play(url)
    if type == 'ustream': url = ustream_play(url)
    if type == 'dailymotion': url = dailymotion_play(url)
    if type == 'freedocast': url = freedocast_play(url)
    if type == 'justin': url = justin_play(url)

    if url.startswith('plugin://plugin.video.youtube/') and check_addon('plugin.video.youtube') is None:
        xbmcgui.Dialog().ok(addonname, language(30211).encode("utf-8"), language(30212).encode("utf-8"))
        return

    item = xbmcgui.ListItem(path=url)
    return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

'''
functions
Credit to MaxMustermann for the SportsDevil plugin.
Credit to divingmule for the Jtv plugin (0.3.4).
Credit to t0mm0 for the freedocast plugin.
'''
def wowza_play(url):
    wowza_server = '178.162.134.45:80'
    wowza_server = '46.21.146.45:80'
    url = 'rtmp://%s/%s playpath=%s.sdp pageUrl=http://www.kanalia.eu/ live=true timeout=10' % (wowza_server, url, url)
    return url

def skai_play(url):
    try:
        link = GetURL(url)
    except:
        return
    try:
        url = re.compile('var File = "(.+?)"').findall(link)[0]
        if not url.startswith('http://'):
            url = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % url
            return url
        else:
            url = 'http://iphone.skai.gr.edgesuite.net/iphone_iphone.m3u8'
            return url
    except:
        return

def madtv_play(url):
    try:
        link = GetURL(url)
    except:
        return
    try:
        url = re.compile('youtube.com/embed/(.+?)"').findall(link)[0]
        url = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % url
        return url
    except:
        return

def videopublishing_play(url):
    try:
        link = GetURL(url)
    except:
        return
    try:
        server = re.compile('</client><server>(.+?)</server>').findall(link)[0]
        playpath = re.compile('<id>(.+?)</id>').findall(link)[0]
        url = 'http://%s:1935/live/%s/playlist.m3u8' % (server, playpath)
        return url
    except:
        return

def visioniptv_play(url):
    cookie_url = 'http://tvnetwork.new.visionip.tv/Hellenic_TV'
    try:
        link = GetURL3(url,cookie_url)
        rtmp = re.compile('.*(rtmp://.+?)"').findall(link)[0]
        playpath = re.compile('href="(.+?)"').findall(link)[0]
    except:
        return
    url = '%s/%s live=true timeout=10' % (rtmp, playpath)
    return url

def asx_play(url):
    try:
        link = GetURL(url)
    except:
        return
    try:
        url = re.compile('.*(mms://.+?)"').findall(link)[0]
        return url
    except:
        return

def youtube_play(url):
    try:
        url = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % url
        return url
    except:
        return

def viiideo_play(url):
    try:
        link = GetURL(url)
    except:
        return
    try:
        url = re.compile("ipadUrl[:] 'http://(.+?)/playlist[.]m3u8'").findall(link)[0]
        url = 'rtmp://%s live=true timeout=10' % url
        return url
    except:
        return

def livestream_play(url):
    url = url.split("http://www.livestream.com/")[1]
    try:
        link = GetURL('http://x%sx.api.channel.livestream.com/3.0/getstream.json' % url)
        isLive = str(link.find('isLive":true'))
    except:
        return
    if isLive == '-1' and url == 'sunnychannelgr':
        return 'rtmp://extondemand.livestream.com:80/ondemand/trans/dv15/mogulus-user-files/chsunnychannelgr/2012/05/16/602ef5f5-9abc-4d44-bdbe-76f5c23099c5'
    if isLive == '-1':
        return
    try:
        url = re.compile('"rtspUrl"[:]"rtsp://(.+?)"').findall(link)[0]
        url = 'rtmp://%s live=true timeout=10' % url
        return url
    except:
        return

def ustream_play(url):
    pageUrl = ' pageUrl=' + url
    try:
        id = url.split("http://www.ustream.tv/embed/")[1]
    except:
        pass
    try:
        link = GetURL(url)
        id = re.compile('www.ustream.tv/embed/(.+?)"').findall(link)[0]
    except:
        pass
    if id is None:
        return
    try:
        link = GetURL('http://cgw.ustream.tv/Viewer/getStream/1/%s.amf' % id)
        rtmp = re.compile('.*(rtmp://.+?)\x00.*').findall(link)[0]
        playpath = re.compile('.*streamName\W\W\W(.+?)[/]*\x00.*').findall(link)[0]
        swfUrl = GetURL2('http://www.ustream.tv/flash/viewer.swf')
        url = '%s/%s swfUrl=%s swfVfy=true live=true timeout=10' % (rtmp, playpath, swfUrl)
        return url
    except:
        return

def dailymotion_play(url):
    try:
        link = GetURL(url)
        watch_url = re.compile('"sequence":"(.+?)"').findall(link)
        watch_url = urllib.unquote(watch_url[0]).decode('utf8').replace('\\/', '/')
        watch_url = re.compile('"customURL":"(.+?)"').findall(watch_url)[0] + '&redirect=0'
    except:
        return
    try:
        stream_url = GetURL(watch_url)
        url = '%s live=true' % (stream_url)
        return url
    except:
        return

def freedocast_play(url):
    try:
        referer = url
        link = GetURL(url)
        watch_url = re.compile('id="player" src="(.+?)"').findall(link)[0]
        watch_url = 'http://www.freedocast.com/%s' % watch_url
        link = GetURL(watch_url,referer)
    except:
        return
    try:
        stream_url = re.search('file=(.+?)&streamer=(.+?)&', link)
        play, streamer = stream_url.groups()
        app = '/'.join(streamer.split('/')[3:])
        url = '%s app=%s playpath=%s pageurl=%s live=true timeout=10' % (streamer, app, play, watch_url)
        return url
    except:
        pass
    try:
        stream_url = re.compile('stream: \'(rtmp.+?)\'').findall(link)[0]
        url = '%s swfUrl=http://cdn.freedocast.com/player-octo/yume/v4/infinite-hd-player-FREEDOCAST.SWF pageUrl=%s swfVfy=true live=true timeout=10' % (stream_url, watch_url)
        return url
    except:
        pass
    try:
        stream_url = re.search('streamsUrl:  \'(.+?)\'', link)
        xml_url = s.group(1)
        xml = GetURL(xml_url)
        stream_url = re.search('<stream uri="(.+?)" stream="(.+?)"', xml)
        tcurl, play = stream_url.groups()
        url = '%s/%s swfUrl=http://cdn.freedocast.com/player-octo/playerv2/swfs/broadkastplayer-yupp.swf pageUrl=%s swfVfy=true live=true timeout=10' % (tcurl, play, watch_url)
        return url
    except:
        pass
    return

def justin_play(url, password=None):
    base_url = 'http://www.justin.tv/'
    name = url.split("http://www.justin.tv/")[1]
    q_type = "live"
    streams = []

    try:
        if not justinaddon == addonname:
            return 'plugin://plugin.video.jtv.archives/?mode=2&name=%s' % name
    except:
        pass

    try:
        temp_url = 'http://www.justin.tv/widgets/live_embed_player.swf?channel=%s' % name
        swf_url = GetURL2(temp_url,url)
    except:
        return

    try:
        temp_url = 'http://usher.justin.tv/find/%s.json?type=any&group=&channel_subscription=' % name
        if not password is None: temp_url += '&private_code='+password
        data = GetURL(temp_url,base_url)
        data = json.loads(data)
    except:
        return
    try:
        for i in data:
            token = None
            try:
                token = ' jtv='+i['token'].replace('\\','\\5c').replace(' ','\\20').replace('"','\\22')
                if i['needed_info'] == 'private': token = 'private'
            except:
                return
            try:
                rtmp = i['connect']+'/'+i['play']
            except:
                return
            try:
                if q_type == i['type']: stream_url = rtmp+token
                else: streams.append((i['type'], rtmp, token))
            except:
                continue
    except:
        return

    try:
        if len(streams) < 1:
            pass
        elif len(streams) == 1:
            stream_url = streams[0][1]+streams[0][2]
        else:
            for i in range(len(s_type)):
                quality = s_type[str(i)]
                for q in streams:
                    if q[0] == quality:
                        stream_url = (q[1]+q[2])
                    else:
                        continue
        url = '%s swfUrl=%s pageUrl=%s swfVfy=true live=true' % (stream_url, swf_url, url)
        return url
    except:
        return


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?','')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


params = get_params()
url = None
name = None
mode = None
type = None
try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    base = urllib.unquote_plus(params["base"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    type = urllib.unquote_plus(params["type"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass

if mode == None or url == None or len(url) < 1:
    get_channels()

elif mode == 0:
    resolve_channels(url,base,type)

xbmcplugin.endOfDirectory(int(sys.argv[1]))