# -*- coding: utf-8 -*-

'''
    hellenic tv XBMC Addon
    Copyright (C) 2013 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib,urllib2,re,os,xbmc,xbmcplugin,xbmcgui,xbmcaddon
try:
    import CommonFunctions
except:
    import commonfunctionsdummy as CommonFunctions


language			= xbmcaddon.Addon().getLocalizedString
setSetting			= xbmcaddon.Addon().setSetting
getSetting			= xbmcaddon.Addon().getSetting
addonname			= xbmcaddon.Addon().getAddonInfo("name")
addonVersion		= xbmcaddon.Addon().getAddonInfo("version")
addonId				= xbmcaddon.Addon().getAddonInfo("id")
addonPath			= xbmcaddon.Addon().getAddonInfo('path')
addonIcon			= xbmc.translatePath(os.path.join(addonPath,'icon.png'))
akamaiProxyServer	= xbmc.translatePath(os.path.join(addonPath,'akamaisecurehd.py'))
fallback			= xbmc.translatePath(os.path.join(addonPath,'resources/fallback/fallback.mp4'))
channelData			= xbmc.translatePath(os.path.join(addonPath,'resources/channels.xml'))
logoPath			= xbmc.translatePath(os.path.join(addonPath,'resources/logos/'))
fanart				= xbmc.translatePath(os.path.join(addonPath,'fanart.jpg'))
common				= CommonFunctions
sysbase				= sys.argv[0]
handle				= int(sys.argv[1])
paramString			= sys.argv[2]

channel_list		= []

def main():
    params = {}
    splitparams = paramString[paramString.find('?') + 1:].split('&')
    for param in splitparams:
        if (len(param) > 0):
            splitparam = param.split('=')
            key = splitparam[0]
            try:	value = splitparam[1].encode("utf-8")
            except:	value = splitparam[1]
            params[key] = value

    try:		action	= urllib.unquote_plus(params["action"])
    except:		action	= None
    try:		channel = urllib.unquote_plus(params["channel"])
    except:		channel = None

    if action	==	None:						get_channels()
    elif action	== 'play_video':				play_video(channel)

    xbmcplugin.setContent(handle, 'Episodes')
    xbmcplugin.setPluginFanart(handle, fanart)
    xbmcplugin.endOfDirectory(handle)
    return

def check_addon(id):
    check_addon = xbmcaddon.Addon(id=id).getAddonInfo("name")
    if not check_addon == addonname: return check_addon
    return

def get_url(url,fetch=True,mobile=False,proxy=None,referer=None,cookie=None):
    if not proxy is None:
        proxy_handler = urllib2.ProxyHandler({'http':'%s' % (proxy)})
        opener = urllib2.build_opener(proxy_handler, urllib2.HTTPHandler)
        opener = urllib2.install_opener(opener)
    request = urllib2.Request(url,None)
    if not cookie is None:
        from urllib2 import Request, build_opener, HTTPCookieProcessor, HTTPHandler
        import cookielib
        cj = cookielib.CookieJar()
        opener = build_opener(HTTPCookieProcessor(cj), HTTPHandler())
        cookiereq = Request(cookie)
        response = opener.open(cookiereq)
        response.close()
        for cookie in cj:
            cookie = '%s=%s' % (cookie.name, cookie.value)
        request.add_header('Cookie', cookie)
    if mobile == True:
        request.add_header('User-Agent', 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_0 like Mac OS X; en-us) AppleWebKit/532.9 (KHTML, like Gecko) Version/4.0.5 Mobile/8A293 Safari/6531.22.7')
    else:
        request.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0')
    if not referer is None:
        request.add_header('Referer', referer)
    response = urllib2.urlopen(request)
    if fetch == True:
        result = response.read()
    else:
        result = response.geturl()
    response.close()
    return result

def get_epg_list():
    ch_dict = {
        'MEGA'	:	'MEGA',
        'ANT1'	:	'ANT1',
        'STAR'	:	'STAR',
        '%CE%A3%CE%9A%CE%91%CE%AA'	:	'SKAI',
        'ALPHA'	:	'ALPHA',
        'ET1'	:	'ET1',
        'NET'	:	'NET',
        'ET3'	:	'ET3',
        '%CE%9C%CE%91%CE%9A%CE%95%CE%94%CE%9F%CE%9D%CE%99%CE%91'	:	'MACEDONIA TV',
        'MAD+TV'	:	'MAD TV',
        'MTV'	:	'MTV',
        'CHANNEL+9'	:	'CHANNEL 9',
        'ACTION+24'	:	'ACTION 24',
        'KONTRA'	:	'KONTRA CHANNEL',
        '%CE%92%CE%9F%CE%A5%CE%9B%CE%97'	:	'BOYLH TV',
        '%CE%9A%CE%A1%CE%97%CE%A4%CE%97+TV'	:	'KRITI TV',
        'EXTRA+3'	:	'EXTRA CHANNEL',
        'TV100'	:	'TV 100',
        'STAR+%CE%9A%CE%95%CE%9D%CE%A4%CE%A1.+%CE%95%CE%9B.'	:	'STAR KENTRIKIS ELLADOS',
        '%CE%94%CE%95%CE%9B%CE%A4%CE%91+TV'	:	'DELTA TV',
        '%CE%94%CE%99%CE%9A%CE%A4%CE%A5%CE%9F+%CE%A4%CE%97%CE%9B%CE%95%CE%9F%CE%A1%CE%91%CE%A3%CE%97'	:	'DIKTYO TV',
        '%CE%89%CE%A0%CE%95%CE%99%CE%A1%CE%9F%CE%A3+TV1'	:	'EPIRUS TV1',
        'BLUE+SKY+TV'	:	'BLUE SKY',
        '4%CE%95'	:	'4E TV',
        'NICKELODEON'	:	'NICKELODEON',
        'EURONEWS'	:	'EURONEWS',
        'ART'	:	'ART CHANNEL',
        '902'	:	'902 TV',
        'ZOOM+TV'	:	'GR TV'
    }

    try:
        epg_list = []
        url = 'http://www.tvcontrol.gr/Ajax.NowPlayingResults.php?ChannelTypeValue=0&ChannelPacketValue=5'
        result = common.fetchPage({"link": url})
        tables = common.parseDOM(result["content"], "table", attrs = { "class": "NowPlayingRow" })
        for table in tables:
            try:
                channel = common.parseDOM(table, "div", attrs = { "class": "ListingPerChannelCellPadding" })[0]
                channel = urllib.quote_plus(channel.encode('utf-8'))
                title = common.parseDOM(table, "div", attrs = { "class": "ListingBubbleTitle" })[0]
                desc_data = common.parseDOM(table, "div", attrs = { "id": "BubbleDescription.+?" })[0]
                desc = re.compile('</div>(.+?)<div').findall(desc_data.replace('\n',''))[0].strip()
                epg = "[B][%s] - %s[/B]\n%s" % (language(30450), title, desc)
                epg = common.replaceHTMLCodes(epg)
                if channel in ch_dict: epg_list.append({'channel': ch_dict[channel], 'epg': epg})
            except:
                pass
    except:
        pass

    return epg_list

def get_channel_list(mode=None):
    global channel_list
    channel_list = []

    if getSetting("epg") == 'true' and mode is not None:
        epg_list = get_epg_list()
    else:
        epg_list = []

    try:
        file = open(channelData,'r')
        result = file.read()
        file.close()
    except:
        return

    channels = common.parseDOM(result, "channel", attrs = { "active": "True" })

    for channel in channels:
        try:
            name = common.parseDOM(channel, "name")[0]
            type = common.parseDOM(channel, "type")[0]
            url = common.parseDOM(channel, "url")[0]
            url = common.replaceHTMLCodes(url)
            epg = ""
            filter_list = [i for i in epg_list if name == i['channel']]
            if filter_list == []:
                epg = common.parseDOM(channel, "epg")[0]
                epg = "[B][%s] - %s[/B]\n%s" % (language(30450), name, language(int(epg)))
            else:
                for item in filter_list: epg = item['epg']

            channel_list.append({'name': name, 'url': url, 'epg': epg.encode('utf-8'), 'type': type})
        except:
            pass

    return channel_list

def get_channels():
    get_channel_list('')
    total = len(channel_list)
    for item in channel_list:
        name = item['name']
        epg = item['epg']
        add_channels(total,name,epg)
    return

def add_channels(total,name,epg):
    if getSetting(name) == "false": return
    channel = name.replace(' ','_')
    syschannel = urllib.quote_plus(channel)
    image = '%s%s.png' % (logoPath, name)
    u = '%s?action=play_video&channel=%s' % (sysbase, syschannel)
    cm = []
    item = xbmcgui.ListItem(name, iconImage=image, thumbnailImage=image)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "Duration": "1440", "Plot": epg } )
    item.setProperty("IsPlayable", "true")
    item.setProperty( "Video", "true" )
    item.setProperty("Fanart_Image", fanart)
    item.addContextMenuItems(cm, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=handle,url=u,listitem=item,totalItems=total)
    return

def play_video(channel):
    get_channel_list()
    channel = channel.replace('_',' ')

    filter_list = [i for i in channel_list if channel == i['name']]
    for item in filter_list:
        name = item['name']
        epg = item['epg']
        type = item['type']
        url = item['url']

    if filter_list == []:
        xbmcgui.Dialog().ok(addonname, language(30351).encode("utf-8"), language(30352).encode("utf-8"))
        xbmcplugin.setResolvedUrl(handle, True, xbmcgui.ListItem(path=fallback))
        return

    player = {
        ''					:	direct_play,
        'hls'				:	hls_play,
        'visionip'			:	visionip_play,
        'madtv'				:	madtv_play,
        'viiideo'			:	viiideo_play,
        'videopublishing'	:	videopublishing_play,
        'dailymotion'		:	dailymotion_play,
        'livestream'		:	livestream_play,
        'ustream'			:	ustream_play,
        'veetle'			:	veetle_play,
        'justin'			:	justin_play
    }

    url = player[type](url)
    if url is None: url = fallback
    image = '%s%s.png' % (logoPath, name)
    if not xbmc.getInfoLabel('ListItem.Plot') == '' : epg = xbmc.getInfoLabel('ListItem.Plot')

    item = xbmcgui.ListItem(path=url, iconImage=image, thumbnailImage=image)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "Duration": "1440", "Plot": epg } )
    xbmcplugin.setResolvedUrl(handle, True, item)
    return

def direct_play(url):
    return url

def hls_play(url):
    try:
        result = common.fetchPage({"link": url})
        if "EXTM3U" in result["content"]: return url
    except:
        return

def visionip_play(url):
    try:
        cookie = 'http://tvnetwork.new.visionip.tv/Hellenic_TV'
        result = get_url(url,cookie=cookie)
        result = common.parseDOM(result, "entry")[0]
        streamer = common.parseDOM(result, "param", ret="value")[0]
        playPath = common.parseDOM(result, "ref", ret="href")[0]
        url = '%s/%s live=1 timeout=10' % (streamer, playPath)
        return url
    except:
        return

def madtv_play(url):
    try:
        result = common.fetchPage({"link": url})
        url = re.compile('youtube.com/embed/(.+?)"').findall(result["content"])[0]
        url = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % url
        return url
    except:
        return

def viiideo_play(url):
    try:
        result = common.fetchPage({"link": url})
        url = re.compile("ipadUrl.+?'http://(.+?)/playlist[.]m3u8'").findall(result["content"])[0]
        url = 'rtmp://%s live=1 timeout=10' % url
        return url
    except:
        return

def videopublishing_play(url):
    try:
        result = common.fetchPage({"link": url})
        print result["content"]
        result = re.compile('<playlist>(.+?)</playlist>').findall(result["content"])[-1]
        streamer = common.parseDOM(result, "server")[0]
        playpath = common.parseDOM(result, "id")[0]
        url = 'http://%s:1935/live/%s/playlist.m3u8' % (streamer, playpath)
        print url
        result = common.fetchPage({"link": url})
        if "EXTM3U" in result["content"]: return url
        return
    except:
        return

def dailymotion_play(url):
    try:
        result = common.fetchPage({"link": url})
        url = re.compile('"sequence":"(.+?)"').findall(result["content"])
        url = urllib.unquote(url[0]).decode('utf8').replace('\\/', '/')
        url = re.compile('"customURL":"(.+?)"').findall(url)[0] + '&redirect=0'
        url = common.fetchPage({"link": url})["content"]
        url = '%s live=1 timeout=10' % url
        return url
    except:
        return

def livestream_play(url):
    try:
        name = url.split("/")[-1]
        url = 'http://x%sx.api.channel.livestream.com/3.0/getstream.json' % name
        result = common.fetchPage({"link": url})
        isLive = str(result["content"].find('isLive":true'))
        if isLive == '-1': return
        url = re.compile('"httpUrl".+?"(.+?)"').findall(result["content"])[0]
        return url
    except:
        return

def ustream_play(url):
    try:
        try:
            result = common.fetchPage({"link": url})
            id = re.compile('ustream.tv/embed/(.+?)"').findall(result["content"])[0]
        except:
            id = url.split("/embed/")[-1]
        url = 'http://iphone-streaming.ustream.tv/uhls/%s/streams/live/iphone/playlist.m3u8' % id
        for i in range(1, 51):
            result = common.fetchPage({"link": url})
            if "EXT-X-STREAM-INF" in result["content"]: return url
            if not "EXTM3U" in result["content"]: return
        return
    except:
        return

def veetle_play(url):
    try:
        xbmc.executebuiltin('RunScript(%s)' % akamaiProxyServer)
        name = url.split("#")[-1]
        url = 'http://www.veetle.com/index.php/channel/ajaxStreamLocation/%s/flash' % name
        result = common.fetchPage({"link": url})
        try: import json
        except: import simplejson as json
        url = json.loads(result["content"])
        import base64
        url = base64.encodestring(url['payload']).replace('\n', '')
        url = 'http://127.0.0.1:64653/veetle/%s' % url
        return url
    except:
        return

def justin_play(url):
    try:
        streams = []
        pageUrl = url
        name = url.split("/")[-1]
        swfUrl = 'http://www.justin.tv/widgets/live_embed_player.swf?channel=%s' % name
        swfUrl = get_url(swfUrl,fetch=False,referer=url)
        data = 'http://usher.justin.tv/find/%s.json?type=any&group=&channel_subscription=' % name
        data = get_url(data,referer=url)
        try: import json
        except: import simplejson as json
        data = json.loads(data)
        for i in data:
            token = None
            token = ' jtv='+i['token'].replace('\\','\\5c').replace(' ','\\20').replace('"','\\22')
            if i['needed_info'] == 'private': token = 'private'
            rtmp = i['connect']+'/'+i['play']
            try:
                if i['type'] == "live": streamer = rtmp+token
                else: streams.append((i['type'], rtmp, token))
            except:
                continue
        if len(streams) < 1: pass
        elif len(streams) == 1: streamer = streams[0][1]+streams[0][2]
        else:
            for i in range(len(s_type)):
                quality = s_type[str(i)]
                for q in streams:
                    if q[0] == quality: streamer = (q[1]+q[2])
                    else: continue
        url = '%s swfUrl=%s pageUrl=%s swfVfy=1 live=1 timeout=10' % (streamer, swfUrl, pageUrl)
        return url
    except:
        return

main()