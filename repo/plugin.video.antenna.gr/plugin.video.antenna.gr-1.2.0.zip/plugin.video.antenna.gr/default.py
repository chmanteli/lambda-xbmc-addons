# -*- coding: utf-8 -*-

'''
    ant1 player XBMC Addon
    Copyright (C) 2013 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib,urllib2,re,os,xbmc,xbmcplugin,xbmcgui,xbmcaddon
from operator import itemgetter
try:
    import StorageServer
except:
    import storageserverdummy as StorageServer
try:
    import CommonFunctions
except:
    import commonfunctionsdummy as CommonFunctions


language = xbmcaddon.Addon().getLocalizedString
setSetting = xbmcaddon.Addon().setSetting
getSetting = xbmcaddon.Addon().getSetting
addonname = xbmcaddon.Addon().getAddonInfo("name")
addonVersion = xbmcaddon.Addon().getAddonInfo("version")
addonId = xbmcaddon.Addon().getAddonInfo("id")
addonPath = xbmcaddon.Addon().getAddonInfo('path')
addonIcon = xbmc.translatePath(os.path.join(addonPath,'icon.png'))
artPath = xbmc.translatePath(os.path.join(addonPath,'resources/art/'))
fanart = xbmc.translatePath(os.path.join(addonPath,'fanart.jpg'))
dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))
favData = xbmc.translatePath(os.path.join(dataPath,'favourites.cfg'))
viewData = xbmc.translatePath(os.path.join(dataPath,'views.cfg'))
cacheFull = StorageServer.StorageServer(addonname+addonVersion,720).cacheFunction
cache = StorageServer.StorageServer(addonname+addonVersion,6).cacheFunction
description = language(30450).encode("utf-8")
common = CommonFunctions
sysbase = sys.argv[0]
handle = int(sys.argv[1])
paramString = sys.argv[2]
skin = xbmc.getSkinDir()

shows_list = []
episodes_list = []
antenna_base = 'http://www.antenna.gr'
antenna_url = 'http://www.antenna.gr/webtv/'

def main():
    xbmc_data()
    params = {}
    splitparams = paramString[paramString.find('?') + 1:].split('&')
    for param in splitparams:
        if (len(param) > 0):
            splitparam = param.split('=')
            key = splitparam[0]
            try: 
                value = splitparam[1].encode("utf-8")
            except:
                value = splitparam[1]
            params[key] = value

    try:		action = urllib.unquote_plus(params["action"])
    except:		action = None
    try:		name = urllib.unquote_plus(params["name"])
    except:		name = None
    try:		show = urllib.unquote_plus(params["show"])
    except:		show = None
    try:		url = urllib.unquote_plus(params["url"])
    except:		url = None
    try:		image = urllib.unquote_plus(params["image"])
    except:		image = None
    try:		mode = urllib.unquote_plus(params["mode"])
    except:		mode = None

    if action == None:							get_categories()
    elif action == 'play_item':					play_item()
    elif action == 'random_play_item':			random_play_item()
    elif action == 'queue_item':				queue_item()
    elif action == 'play_from_here_item':		play_from_here_item(url)
    elif action == 'add_favourite_item':		add_favourite_item(name,url)
    elif action == 'delete_favourite_item':		delete_favourite_item(name,url)
    elif action == 'move_favourite_item_up':	move_favourite_item_up(name,url)
    elif action == 'move_favourite_item_down':	move_favourite_item_down(name,url)
    elif action == 'play_queue':				play_queue()
    elif action == 'open_playlist':				open_playlist()
    elif action == 'xbmc_set_view':				xbmc_set_view()
    elif action == 'open_settings':				open_settings()
    elif action == 'get_favourites':			get_favourites()
    elif action == 'get_shows':					get_shows()
    elif action == 'get_recent':				get_recent()
    elif action == 'get_news':					get_news()
    elif action == 'get_sports':				get_sports()
    elif action == 'get_episodes':				get_episodes(show,url,image)
    elif action == 'play_video':				play_video(url)

    xbmcplugin.setContent(handle, 'Episodes')
    xbmcplugin.setPluginFanart(handle, fanart)
    xbmcplugin.endOfDirectory(handle)
    xbmc_view()
    return

def unique_list(list):
    unique_set = set()
    unique_list = []
    for n in list:
        if n not in unique_set:
            unique_set.add(n)
            unique_list.append(n)
    return unique_list

def GetURL_Proxy(url,proxyIp,proxyPort,referer=None):
    if referer is None:
        headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0'}
    else:
        headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0', 'Referer' : referer}
    proxy_handler = urllib2.ProxyHandler({'http':'%s:%s' % (proxyIp, proxyPort)})
    opener = urllib2.build_opener(proxy_handler, urllib2.HTTPHandler)
    opener = urllib2.install_opener(opener)
    req = urllib2.Request(url,None,headers)
    response = urllib2.urlopen(req)
    result = response.read()
    response.close()
    return result

def check_addon(id):
    check_addon = xbmcaddon.Addon(id=id).getAddonInfo("name")
    if not check_addon == addonname: return check_addon
    return

def xbmc_notify(mode):
    if mode == 'setview':
        viewName = xbmc.getInfoLabel('Container.Viewmode')
        xbmc.executebuiltin("Notification(%s,%s, 3000)" % (addonname, '%s%s%s') % (language(30301).encode("utf-8"), viewName, language(30302).encode("utf-8")))
    elif mode == 'favadd':
        xbmc.executebuiltin("Notification(%s,%s, 3000)" % (addonname, language(30303).encode("utf-8")))
    elif mode == 'favrem':
        xbmc.executebuiltin("Notification(%s,%s, 3000)" % (addonname, language(30304).encode("utf-8")))
    elif mode == 'favup':
        xbmc.executebuiltin("Notification(%s,%s, 3000)" % (addonname, language(30305).encode("utf-8")))
    elif mode == 'favdown':
        xbmc.executebuiltin("Notification(%s,%s, 3000)" % (addonname, language(30306).encode("utf-8")))

def xbmc_refresh():
    xbmc.executebuiltin('Container.Refresh')

def xbmc_data():
    if not os.path.exists(dataPath):
        os.makedirs(dataPath)
    if not os.path.isfile(favData):
        file = open(favData, 'w')
        file.write('')
        file.close()
    if not os.path.isfile(viewData):
        file = open(viewData, 'w')
        file.write('')
        file.close()

def xbmc_view():
    try:
        file = open(viewData,'r')
        read = file.read().replace('\n','')
        file.close()
        view = re.compile('"%s"[|]"(.+?)"' % (skin)).findall(read)[0]
        xbmc.executebuiltin('Container.SetViewMode(%s)' % str(view))
    except:
        if (skin == 'skin.confluence'):			xbmc.executebuiltin('Container.SetViewMode(503)')
        if (skin == 'skin.ace'):				xbmc.executebuiltin('Container.SetViewMode(59)')
        if (skin == 'skin.aeon.nox'):			xbmc.executebuiltin('Container.SetViewMode(518)')
        if (skin == 'skin.back-row'):			xbmc.executebuiltin('Container.SetViewMode(529)')
        if (skin == 'skin.carmichael'):			xbmc.executebuiltin('Container.SetViewMode(50)')
        if (skin == 'skin.diffuse'):			xbmc.executebuiltin('Container.SetViewMode(55)')
        if (skin == 'skin.metropolis'):			xbmc.executebuiltin('Container.SetViewMode(55)')
        if (skin == 'skin.pm3-hd'):				xbmc.executebuiltin('Container.SetViewMode(58)')
        if (skin == 'skin.transparency'):		xbmc.executebuiltin('Container.SetViewMode(51)')
        if (skin == 'skin.xeebo'):				xbmc.executebuiltin('Container.SetViewMode(50)')
        if (skin == 'skin.xperience-more'):		xbmc.executebuiltin('Container.SetViewMode(50)')
        if (skin == 'skin.fusion.migma.v3'):	xbmc.executebuiltin('Container.SetViewMode(504)')
        if (skin == 'skin.bello'):				xbmc.executebuiltin('Container.SetViewMode(50)')
        if (skin == 'skin.cirrus.extended.v3'):	xbmc.executebuiltin('Container.SetViewMode(55)')
        if (skin == 'skin.neon'):				xbmc.executebuiltin('Container.SetViewMode(53)')
        if (skin == 'skin.quartz'):				xbmc.executebuiltin('Container.SetViewMode(52)')
        if (skin == 'skin.quartz.reloaded'):	xbmc.executebuiltin('Container.SetViewMode(52)')
        if (skin == 'skin.rapier'):				xbmc.executebuiltin('Container.SetViewMode(68)')
        if (skin == 'skin.re-touched'):			xbmc.executebuiltin('Container.SetViewMode(550)')
        if (skin == 'skin.refocus'):			xbmc.executebuiltin('Container.SetViewMode(50)')
        if (skin == 'skin.simplicity.frodo'):	xbmc.executebuiltin('Container.SetViewMode(50)')
        if (skin == 'skin.touched'):			xbmc.executebuiltin('Container.SetViewMode(50)')
        if (skin == 'skin.xperience1080'):		xbmc.executebuiltin('Container.SetViewMode(50)')

def xbmc_set_view():
    try:
        skinInfo = xbmc.translatePath('special://xbmc/addons/%s/addon.xml' % (skin))
        videoNav = 'special://xbmc/addons/%s/%s/MyVideoNav.xml'
        if not os.path.isfile(skinInfo):
            skinInfo = xbmc.translatePath('special://home/addons/%s/addon.xml' % (skin))
            videoNav = 'special://home/addons/%s/%s/MyVideoNav.xml'
        file = open(skinInfo,'r')
        read = file.read().replace('\n','')
        file.close()
        try:
            skinInfo = re.compile('defaultresolution="(.+?)"').findall(read)[0]
        except:
            skinInfo = re.compile('<res.+?folder="(.+?)"').findall(read)[0]
        videoNav = xbmc.translatePath(videoNav % (skin, skinInfo))
        file = open(videoNav,'r')
        read = file.read().replace('\n','')
        file.close()
        views = re.compile('<views>(.+?)</views>').findall(read)[0]
        views = [int(x) for x in views.split(',')]
        for view in views:
            viewLabel = xbmc.getInfoLabel('Control.GetLabel(%s)' % (view))
            if not (viewLabel == '' or viewLabel is None): break
        file = open(viewData, 'r')
        read = file.read()
        file.close()
        file = open(viewData, 'w')
        for line in re.compile('(".+?\n)').findall(read):
            if not line.startswith('"%s"|"' % (skin)): file.write(line)
        file.write('"%s"|"%s"\n' % (skin, str(view)))
        file.close()
        xbmc_notify('setview')
    except:
        return

def play_item():
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    xbmc.executebuiltin('Action(Queue)')
    playlist.unshuffle()
    xbmc.Player().play(playlist)

def random_play_item():
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    xbmc.executebuiltin('Action(Queue)')
    playlist.shuffle()
    xbmc.Player().play(playlist)

def queue_item():
    xbmc.executebuiltin('Action(Queue)')

def play_from_here_item(url):
    try:
        deamon = url
        folderPath = xbmc.getInfoLabel('Container.FolderPath')
        params = dict(arg.split("=") for arg in folderPath.split("&"))
        show = urllib.unquote_plus(params["show"])
        url = urllib.unquote_plus(params["url"])
        image = urllib.unquote_plus(params["image"])
        episodes_list = get_episodes(show,url,image)
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()
        playlist.unshuffle()
        episodes_list.reverse()
        play_from_here_list = []
        for item in episodes_list:
            play_from_here_list.append({'name': item['name'], 'show': item['show'], 'url': item['url'], 'image': item['image']})
            if deamon == item['url']: break
        play_from_here_list.reverse()
        for item in play_from_here_list:
            add_episodes(0,item['name'],item['show'],item['url'],item['image'],'playlist')
        xbmc.Player().play(playlist)
    except:
        return

def add_favourite_item(name,url):
    xbmc_refresh()
    file = open(favData, 'a+')
    file.write('"%s"|"%s"\n' % (name, url))
    file.close()
    xbmc_notify('favadd')

def delete_favourite_item(name,url):
    xbmc_refresh()
    file = open(favData, 'r')
    read = file.read().replace('"%s"|"%s"' % (name, url),'')
    file.close()
    file = open(favData, 'w')
    for line in re.compile('(".+?\n)').findall(read):
        file.write(line)
    file.close()
    xbmc_notify('favrem')

def move_favourite_item_up(name,url):
    xbmc_refresh()
    file = open(favData,'r')
    read = file.read()
    file.close()
    favourites_list = []
    for line in re.compile('(".+?)\n').findall(read):
        favourites_list.append(line)
    i = favourites_list.index('"%s"|"%s"' % (name, url))
    if i == 0: return
    favourites_list[i],favourites_list[i-1] = favourites_list[i-1],favourites_list[i]
    file = open(favData, 'w')
    for line in favourites_list:
        file.write('%s\n' % (line))
    file.close()
    xbmc_notify('favup')

def move_favourite_item_down(name,url):
    xbmc_refresh()
    file = open(favData,'r')
    read = file.read()
    file.close()
    favourites_list = []
    for line in re.compile('(".+?)\n').findall(read):
        favourites_list.append(line)
    i = favourites_list.index('"%s"|"%s"' % (name, url))
    if i+1 == len(favourites_list): return
    favourites_list[i],favourites_list[i+1] = favourites_list[i+1],favourites_list[i]
    file = open(favData, 'w')
    for line in favourites_list:
        file.write('%s\n' % (line))
    file.close()
    xbmc_notify('favdown')

def play_queue():
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.unshuffle()
    xbmc.Player().play(playlist)

def open_playlist():
    xbmc.executebuiltin('ActivateWindow(VideoPlaylist)')

def open_settings():
    xbmc.executebuiltin('Addon.OpenSettings(%s)' % (addonId))

def get_favourites():
    file = open(favData, 'r')
    read = file.read()
    file.close()
    list = re.compile('"(.+?)"[|]"(.+?)"').findall(read)
    total = len(list)
    for name,url in list:
        image = cacheFull(get_episodes,name,url,'','image')
        #image = get_episodes(name,url,'','image')
        add_favourites(total,name,url,image)
    return

def add_favourites(total,name,url,image):
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    sysimage = urllib.quote_plus(image)
    u = '%s?action=get_episodes&show=%s&url=%s&image=%s' % (sysbase, sysname, sysurl, sysimage)
    cm = []
    cm.append((language(30401).encode("utf-8"), 'RunPlugin(%s?action=play_item)' % (sysbase)))
    cm.append((language(30402).encode("utf-8"), 'RunPlugin(%s?action=random_play_item)' % (sysbase)))
    cm.append((language(30404).encode("utf-8"), 'RunPlugin(%s?action=queue_item)' % (sysbase)))
    cm.append((language(30406).encode("utf-8"), 'RunPlugin(%s?action=play_queue)' % (sysbase)))
    cm.append((language(30407).encode("utf-8"), 'RunPlugin(%s?action=open_playlist)' % (sysbase)))
    cm.append((language(30408).encode("utf-8"), 'RunPlugin(%s?action=xbmc_set_view)' % (sysbase)))
    cm.append((language(30409).encode("utf-8"), 'RunPlugin(%s?action=open_settings)' % (sysbase)))
    cm.append((language(30410).encode("utf-8"), 'RunPlugin(%s?action=move_favourite_item_up&name=%s&url=%s)' % (sysbase, sysname, sysurl)))
    cm.append((language(30411).encode("utf-8"), 'RunPlugin(%s?action=move_favourite_item_down&name=%s&url=%s)' % (sysbase, sysname, sysurl)))
    cm.append((language(30412).encode("utf-8"), 'RunPlugin(%s?action=delete_favourite_item&name=%s&url=%s)' % (sysbase, sysname, sysurl)))
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=image)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    item.setProperty("Fanart_Image", fanart)
    item.addContextMenuItems(cm, replaceItems=True)
    xbmcplugin.addDirectoryItem(handle=handle,url=u,listitem=item,totalItems=total,isFolder=True)
    return

def get_categories():
    total = 5
    add_categories(total,language(30501).encode("utf-8"),artPath+'Favourites.png','get_favourites')
    add_categories(total,language(30502).encode("utf-8"),artPath+'Shows.png','get_shows')
    add_categories(total,language(30503).encode("utf-8"),artPath+'Recent.png','get_recent')
    add_categories(total,language(30504).encode("utf-8"),artPath+'News.png','get_news')
    add_categories(total,language(30505).encode("utf-8"),artPath+'Sports.png','get_sports')
    return

def add_categories(total,name,image,action):
    u = '%s?action=%s' % (sysbase, action)
    cm = []
    cm.append((language(30406).encode("utf-8"), 'RunPlugin(%s?action=play_queue)' % (sysbase)))
    cm.append((language(30407).encode("utf-8"), 'RunPlugin(%s?action=open_playlist)' % (sysbase)))
    cm.append((language(30408).encode("utf-8"), 'RunPlugin(%s?action=xbmc_set_view)' % (sysbase)))
    cm.append((language(30409).encode("utf-8"), 'RunPlugin(%s?action=open_settings)' % (sysbase)))
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=image)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    item.setProperty("Fanart_Image", fanart)
    item.addContextMenuItems(cm, replaceItems=True)
    xbmcplugin.addDirectoryItem(handle=handle,url=u,listitem=item,totalItems=total,isFolder=True)
    return

def get_recent():
    global episodes_list
    episodes_list = []
    try:
        result = common.fetchPage({"link": antenna_url})
        episodes = common.parseDOM(result["content"], "div", attrs = { "id": "ctl00_slidesmall_ContentDiv" })[0]
        episodes = common.parseDOM(episodes, "div", attrs = { "class": "smallwteaser" })
        episodes_list = get_antenna_cat_episodes('ANT1',episodes)
    except:
        return

def get_news():
    global episodes_list
    episodes_list = []
    try:
        result = common.fetchPage({"link": antenna_url})
        episodes = common.parseDOM(result["content"], "div", attrs = { "id": "ctl00_homebulletins1_contentDiv" })[0]
        episodes = common.parseDOM(episodes, "div", attrs = { "class": "videoTeaser" })
        episodes_list = get_antenna_cat_episodes('ANT1',episodes)
    except:
        return

def get_sports():
    global episodes_list
    episodes_list = []
    try:
        result = common.fetchPage({"link": antenna_url})
        episodes = common.parseDOM(result["content"], "div", attrs = { "id": "ctl00_homeSports1_contentDiv" })[0]
        episodes = common.parseDOM(episodes, "div", attrs = { "class": "videoTeaser" })
        episodes_list = get_antenna_cat_episodes('ANT1',episodes)
    except:
        return

def get_shows():
    global shows_list
    shows_list = []

    total = 0
    #shows_list = get_antenna_list()
    shows_list = cache(get_antenna_list)
    shows_list = sorted(shows_list, key=itemgetter('name'))

    for item in shows_list:
        name = item['name']
        url = item['url']
        image = item['image']
        total += 1
        add_shows(total,name,url,image)

    return shows_list

def get_antenna_list():
    letters = ['%u0391','%u0392','%u0393','%u0394','%u0395','%u0396','%u0397','%u0398','%u0399','%u039A','%u039B','%u039C','%u039D','%u039E','%u039F','%u03A0','%u03A1','%u03A3','%u03A4','%u03A5','%u03A6','%u03A7','%u03A8','%u03A9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','1-9']
    shows = ""
    try:
        for letter in letters:
            url = '%saz?letter=%s' % (antenna_url, letter)
            result = common.fetchPage({"link": url})
            shows += result["content"]
        shows = common.parseDOM(shows, "div", attrs = { "class": "videoTeaser" })
        total = len(shows)
    except:
        return
    for show in shows:
        try:
            name = common.parseDOM(show, "a")[-1]
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            url = common.parseDOM(show, "a", ret="href")[0]
            url = '%s%s' % (antenna_base, url)
            url = common.replaceHTMLCodes(url)
            url = url.encode('utf-8')
            image = common.parseDOM(show, "a", ret="rel")[0]
            image = image.split(".jpg")[0]
            image = '%s%s.jpg' % (antenna_base, image)
            image = common.replaceHTMLCodes(image)
            image = image.encode('utf-8')
            shows_list.append({'name': name, 'url': url, 'image': image})
        except:
            total = total - 1
            pass

    return shows_list

def add_shows(total,name,url,image):
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    sysimage = urllib.quote_plus(image)
    u = '%s?action=get_episodes&show=%s&url=%s&image=%s' % (sysbase, sysname, sysurl, sysimage)
    file = open(favData, 'r')
    read = file.read()
    file.close()
    cm = []
    cm.append((language(30401).encode("utf-8"), 'RunPlugin(%s?action=play_item)' % (sysbase)))
    cm.append((language(30402).encode("utf-8"), 'RunPlugin(%s?action=random_play_item)' % (sysbase)))
    cm.append((language(30404).encode("utf-8"), 'RunPlugin(%s?action=queue_item)' % (sysbase)))
    cm.append((language(30406).encode("utf-8"), 'RunPlugin(%s?action=play_queue)' % (sysbase)))
    cm.append((language(30407).encode("utf-8"), 'RunPlugin(%s?action=open_playlist)' % (sysbase)))
    if not url in read:
        cm.append((language(30413).encode("utf-8"), 'RunPlugin(%s?action=add_favourite_item&name=%s&url=%s)' % (sysbase, sysname, sysurl)))
    else:
        cm.append((language(30414).encode("utf-8"), 'RunPlugin(%s?action=delete_favourite_item&name=%s&url=%s)' % (sysbase, sysname, sysurl)))
    cm.append((language(30408).encode("utf-8"), 'RunPlugin(%s?action=xbmc_set_view)' % (sysbase)))
    cm.append((language(30409).encode("utf-8"), 'RunPlugin(%s?action=open_settings)' % (sysbase)))
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=image)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    item.setProperty("Fanart_Image", fanart)
    item.addContextMenuItems(cm, replaceItems=True)
    xbmcplugin.addDirectoryItem(handle=handle,url=u,listitem=item,totalItems=total,isFolder=True)
    return

def get_episodes(show,url,image,mode=None):
    global episodes_list
    episodes_list = []

    if url.startswith(antenna_url):
        if mode is None:
            episodes_list = get_antenna_episodes(show,url)
        else:
            image = get_antenna_episodes(show,url,mode)
            return image

    return episodes_list

def get_antenna_episodes(show,url,mode=None):
    try:
        episodes_url = url.replace('categories','templates/data/videocategories')
        result = common.fetchPage({"link": episodes_url})
        episodes = result["content"]

        pages = common.parseDOM(result["content"], "a", attrs = { "class": "paging" })
        pages = unique_list(pages)
        for page in pages:
            url = '%s&p=%s' % (episodes_url, page)
            result = common.fetchPage({"link": url})
            episodes += result["content"]
    except:
        pass
    try:
        episodes = common.parseDOM(episodes, "div", attrs = { "class": "videoTeaser" })
        total = len(episodes)
    except:
        return
    for episode in episodes:
        try:
            name = common.parseDOM(episode, "div", attrs = { "class": "greytxt.+?" })[-1]
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            image = common.parseDOM(episode, "a", ret="rel")[0]
            image = image.split(".jpg")[0]
            image = '%s%s.jpg' % (antenna_base, image)
            image = common.replaceHTMLCodes(image)
            image = image.encode('utf-8')
            if mode == 'image': return image
            url = common.parseDOM(episode, "a", ret="href")[0]
            url = '%s%s' % (antenna_base, url)
            url = common.replaceHTMLCodes(url)
            url = url.encode('utf-8')
            episodes_list.append({'name': name, 'show': show, 'url': url, 'image': image})
            add_episodes(total,name,show,url,image)
        except:
            total = total - 1
            pass

    return episodes_list

def get_antenna_cat_episodes(show,url):
    episodes = url
    total = len(episodes)
    for episode in episodes:
        try:
            name = common.parseDOM(episode, "div", attrs = { "class": "greytxt.+?" })[-1]
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            image = common.parseDOM(episode, "a", ret="rel")[0]
            image = image.split(".jpg")[0]
            image = '%s%s.jpg' % (antenna_base, image)
            image = common.replaceHTMLCodes(image)
            image = image.encode('utf-8')
            url = common.parseDOM(episode, "a", ret="href")[0]
            url = '%s%s' % (antenna_base, url)
            url = common.replaceHTMLCodes(url)
            url = url.encode('utf-8')
            episodes_list.append({'name': name, 'show': show, 'url': url, 'image': image})
            add_episodes(total,name,show,url,image)
        except:
            total = total - 1
            pass

    return episodes_list

def add_episodes(total,name,show,url,image,mode=None):
    sysurl = urllib.quote_plus(url)
    u = '%s?action=play_video&url=%s' % (sysbase, sysurl)
    cm = []
    cm.append((language(30405).encode("utf-8"), 'RunPlugin(%s?action=queue_item)' % (sysbase)))
    cm.append((language(30403).encode("utf-8"), 'RunPlugin(%s?action=play_from_here_item&url=%s)' % (sysbase, sysurl)))
    cm.append((language(30406).encode("utf-8"), 'RunPlugin(%s?action=play_queue)' % (sysbase)))
    cm.append((language(30407).encode("utf-8"), 'RunPlugin(%s?action=open_playlist)' % (sysbase)))
    cm.append((language(30408).encode("utf-8"), 'RunPlugin(%s?action=xbmc_set_view)' % (sysbase)))
    cm.append((language(30409).encode("utf-8"), 'RunPlugin(%s?action=open_settings)' % (sysbase)))
    item = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=image)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": show, "Plot": description } )
    item.setProperty("IsPlayable", "true")
    item.setProperty( "Video", "true" )
    item.setProperty("Fanart_Image", fanart)
    if mode == 'playlist':
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.add(u, item)
    else:
        item.addContextMenuItems(cm, replaceItems=True)
        xbmcplugin.addDirectoryItem(handle=handle,url=u,listitem=item,totalItems=total)
    return

def play_video(url):
    pageUrl = url
    swfUrl = 'http://www.antenna.gr/webtv/images/fbplayer.swf'
    url = url.replace('watch','templates/data/player')

    try:
        result = common.fetchPage({"link": url})
        rtmp = common.parseDOM(result["content"], "FMS")[0]
        playpath = common.parseDOM(result["content"], "appStream")[0]
        if not playpath.endswith('/GR.flv'):
            url = '%s playpath=%s pageUrl=%s swfUrl=%s swfVfy=true timeout=10' % (rtmp, playpath, pageUrl, swfUrl)
            if playpath.startswith('http://'): url = playpath
            item = xbmcgui.ListItem(path=url)
            xbmcplugin.setResolvedUrl(handle, True, item)
            return
    except:
        return

    try:
        proxyIp = getSetting("proxyip")
        proxyPort = getSetting("proxyport")
        result = GetURL_Proxy(url,proxyIp,proxyPort)
        result = unicode(result, 'utf-8', 'ignore')
        rtmp = common.parseDOM(result, "FMS")[0]
        playpath = common.parseDOM(result, "appStream")[0]
        if not playpath.endswith('/GR.flv'):
            url = '%s playpath=%s pageUrl=%s swfUrl=%s swfVfy=true timeout=10' % (rtmp, playpath, pageUrl, swfUrl)
            if playpath.startswith('http://'): url = playpath
            item = xbmcgui.ListItem(path=url)
            xbmcplugin.setResolvedUrl(handle, True, item)
            return
        else:
            xbmcgui.Dialog().ok(addonname, language(30353).encode("utf-8"), "")
            open_settings()
            return
    except:
        xbmcgui.Dialog().ok(addonname, language(30353).encode("utf-8"), "")
        open_settings()
        return

main()