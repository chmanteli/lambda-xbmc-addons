# -*- coding: utf-8 -*-

'''
    ant1 player XBMC Addon
    Copyright (C) 2012 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib,urllib2,re,os,xbmcplugin,xbmcgui,xbmcaddon
import random
import sets

settings = xbmcaddon.Addon(id='plugin.video.antenna.gr')
data = 'special://profile/addon_data/plugin.video.antenna.gr'

home = settings.getAddonInfo('path')
language = settings.getLocalizedString
addonname = settings.getAddonInfo("name")
description = language(30508).encode("utf-8")
icon = xbmc.translatePath(os.path.join(home,'icon.png'))
artPath = xbmc.translatePath(os.path.join(home,'resources/art/'))
fanart = xbmc.translatePath(os.path.join(home,'fanart.jpg'))
favPath = xbmc.translatePath(os.path.join(data,'favourites.cfg'))
dataPath = xbmc.translatePath(data)
skin = xbmc.getSkinDir()

xbmcplugin.setContent(int(sys.argv[1]), 'Episodes')
xbmcplugin.setPluginFanart(int(sys.argv[1]), fanart)

try:
    import StorageServer
    cache = StorageServer.StorageServer(addonname,720)
except:
    import storageserverdummy as StorageServer
    cache = StorageServer.StorageServer(addonname,720)

try:
    import CommonFunctions
    common = CommonFunctions
except:
    import commonfunctionsdummy as CommonFunctions
    common = CommonFunctions



base_url = 'http://www.antenna.gr'
shows_url = 'http://www.antenna.gr/webtv/'


def unique_list(list):
    unique_set = sets.Set()
    unique_list = []
    for n in list:
        if n not in unique_set:
            unique_set.add(n)
            unique_list.append(n)
    return unique_list

def xbmc_notify(type):
    if type == 'favadd':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30201).encode("utf-8")))
    elif type == 'favrem':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30202).encode("utf-8")))
    elif type == 'favup':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30203).encode("utf-8")))
    elif type == 'favdown':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30204).encode("utf-8")))

def xbmc_refresh():
    xbmc.executebuiltin("Container.Refresh")

def xbmc_view():
    viewenable = settings.getSetting("viewenable")

    if (skin == 'skin.confluence' or skin == 'skin.confluence.svn') and viewenable == 'true':
        confluence_views = [50,51,500,504,503,515]
        view = int(settings.getSetting("confluence"))
        xbmc.executebuiltin("Container.SetViewMode("+str(confluence_views[view])+")")

    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn') and viewenable == 'true':
        rapier_views = [50,52,74,73,68,94]
        view = int(settings.getSetting("rapier"))
        xbmc.executebuiltin("Container.SetViewMode("+str(rapier_views[view])+")")

def xbmc_data():
    if not os.path.exists(dataPath):
        os.makedirs(dataPath)
    if not os.path.isfile(favPath):
        read = open(favPath, 'w')
        read.write('')
        read.close()

def add_favourite_item(name,url):
    xbmc_refresh()
    read = open(favPath, 'a+')
    read.write('"'+name+'"|"'+url+'"\n')
    read.close()
    xbmc_notify('favadd')

def delete_favourite_item(name,url):
    xbmc_refresh()
    read = open(favPath, 'r')
    text = read.read().replace('"'+name+'"|"'+url+'"','')
    read.close()
    read = open(favPath, 'w')
    for line in re.compile('"(.+?)\n').findall(text):
        read.write('"'+line+'\n')
    read.close()
    xbmc_notify('favrem')

def move_favourite_item(name,url,type):
    xbmc_refresh()
    replaced = []
    j = []
    i = 0
    f = open(favPath,'r')
    for line in f:
        if re.search('"'+url.replace('?','[?]')+'"',line) is not None:
            j = i
        i = i+1
    f.close()
    if type == 'favup':
        i = 1
    if type == 'favdown':
        i = -1
    f = open(favPath,'r')
    for line in f:
        if i == j:
            replaced = line
        i = i+1
    f.close()

    if not replaced == []:
        read = open(favPath, 'r')
        text = read.read()
        if type == 'favup':
            text = text.replace(replaced+'"'+name+'"|"'+url+'"','"'+name+'"|"'+url+'"'+replaced)
            text = text.replace('\n','')
        if type == 'favdown':
            text = text.replace('"'+name+'"|"'+url+'"\n'+replaced,replaced+'"'+name+'"|"'+url+'"')
            text = text.replace('\n','')
        read.close()
        read = open(favPath, 'w')
        for name,cid in re.compile('"(.+?)"[|]"(.+?)"').findall(text):
            read.write('"'+name+'"|"'+cid+'"\n')
        if type == 'favup':
            xbmc_notify('favup')
        if type == 'favdown':
            xbmc_notify('favdown')
	    read.close()

def get_favourites():
    xbmc_data()
    read = open(favPath, 'r')
    text = read.read()
    read.close()
    list = re.compile('"(.+?)"[|]"(.+?)"').findall(text)
    total = len(list)
    for name,url in list:
        iconimage = cache.cacheFunction(get_iconimage, url)
        #iconimage = get_iconimage(url)
        add_favourites(total,name,url,600,iconimage)
    xbmc_view()

def add_favourites(total,name,url,mode,iconimage):
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    contextMenuItems = []
    contextMenuItems.append((xbmc.getLocalizedString(13332), 'XBMC.RunPlugin(%s?mode=102&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    contextMenuItems.append((xbmc.getLocalizedString(13333), 'XBMC.RunPlugin(%s?mode=103&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    contextMenuItems.append((xbmc.getLocalizedString(1210), 'XBMC.RunPlugin(%s?mode=101&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    u = '%s?mode=%s&show=%s&url=%s' % (sys.argv[0], str(mode), sysname, sysurl)
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        item.setProperty( "Fanart_Image", iconimage )
    else: item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)

def get_categories():
    xbmc_data()
    total = 7
    add_categories(total,language(30501).encode("utf-8"),base_url,200,'0',artPath+'favorites.png')
    add_categories(total,language(30502).encode("utf-8"),base_url,300,'0',artPath+'search.png')
    add_categories(total,language(30503).encode("utf-8"),base_url,400,'1',artPath+'latest.png')
    add_categories(total,language(30504).encode("utf-8"),base_url,400,'2',artPath+'latest-news.png')
    add_categories(total,language(30505).encode("utf-8"),base_url,400,'3',artPath+'latest-sports.png')
    add_categories(total,language(30506).encode("utf-8"),base_url,400,'4',artPath+'latest-shows.png')
    add_categories(total,language(30507).encode("utf-8"),base_url,400,'5',artPath+'latest-series.png')
    xbmc_view()
    return

def get_cat_shows():
    xbmc_data()
    total = 10
    add_categories(total,language(30511).encode("utf-8"),base_url,500,'1',artPath+'search-1.png')
    add_categories(total,language(30512).encode("utf-8"),base_url,500,'2',artPath+'search-2.png')
    add_categories(total,language(30513).encode("utf-8"),base_url,500,'3',artPath+'search-3.png')
    add_categories(total,language(30514).encode("utf-8"),base_url,500,'4',artPath+'search-4.png')
    add_categories(total,language(30515).encode("utf-8"),base_url,500,'5',artPath+'search-5.png')
    add_categories(total,language(30516).encode("utf-8"),base_url,500,'6',artPath+'search-6.png')
    add_categories(total,language(30517).encode("utf-8"),base_url,500,'7',artPath+'search-7.png')
    add_categories(total,language(30518).encode("utf-8"),base_url,500,'8',artPath+'search-8.png')
    add_categories(total,language(30519).encode("utf-8"),base_url,500,'9',artPath+'search-9.png')
    add_categories(total,language(30520).encode("utf-8"),base_url,500,'10',artPath+'search-10.png')
    xbmc_view()
    return

def add_categories(total,name,url,mode,type,iconimage):
    sysname = urllib.quote_plus(name)
    systype = urllib.quote_plus(type)
    sysurl = urllib.quote_plus(url)
    contextMenuItems = []
    u = '%s?mode=%s&type=%s&url=%s' % (sys.argv[0], str(mode), systype, sysurl)
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        item.setProperty( "Fanart_Image", iconimage )
    else: item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)

def get_cat_episodes(type):
    xbmc_data()
    try:
        result = common.fetchPage({"link": shows_url})
        cat_episodes = result["content"]
        if type == '1':
            cat_episodes = common.parseDOM(cat_episodes, "div", attrs = { "id": "ctl00_slidesmall_ContentDiv" })[0]
            cat_episodes = common.parseDOM(cat_episodes, "div", attrs = { "class": "smallwteaser" })
        if type == '2':
            cat_episodes = common.parseDOM(cat_episodes, "div", attrs = { "id": "ctl00_homebulletins1_contentDiv" })[0]
            cat_episodes = common.parseDOM(cat_episodes, "div", attrs = { "class": "videoTeaser" })
        if type == '3':
            cat_episodes = common.parseDOM(cat_episodes, "div", attrs = { "id": "ctl00_homeSports1_contentDiv" })[0]
            cat_episodes = common.parseDOM(cat_episodes, "div", attrs = { "class": "videoTeaser" })
        if type == '4':
            cat_episodes = common.parseDOM(cat_episodes, "div", attrs = { "id": "ctl00_homeEnter1_contentDiv" })[0]
            cat_episodes = common.parseDOM(cat_episodes, "div", attrs = { "class": "videoTeaser" })
        if type == '5':
            cat_episodes = common.parseDOM(cat_episodes, "div", attrs = { "id": "ctl00_homeSeries1_contentDiv" })[0]
            cat_episodes = common.parseDOM(cat_episodes, "div", attrs = { "class": "videoTeaser" })
        total = len(cat_episodes)
    except:
        xbmc_view()
        return
    for cat_episode in cat_episodes:
        try:
            name = common.parseDOM(cat_episode, "div", attrs = { "class": "greytxt font11txt" })[0]
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            show = common.parseDOM(cat_episode, "a", attrs = { "href": "/webtv/categories.+?" })[0]
            show = common.replaceHTMLCodes(show)
            show = show.encode('utf-8')
            url = common.parseDOM(cat_episode, "a", ret="href")[0]
            url = common.replaceHTMLCodes(url)
            url = base_url + url
            url = url.encode('utf-8')
            iconimage = common.parseDOM(cat_episode, "a", ret="rel")[0]
            iconimage = iconimage.split(".jpg")[0]
            iconimage = common.replaceHTMLCodes(iconimage)
            iconimage = '%s%s.jpg' % (base_url, iconimage)
            iconimage = iconimage.encode('utf-8')
            add_cat_episodes(total,name,show,url,iconimage)
        except:
            total = total - 1
            pass
    xbmc_view()
    return

def add_cat_episodes(total,name,show,url,iconimage):
    mode = 900
    sysurl = urllib.quote_plus(url)
    u = '%s?mode=%s&url=%s' % (sys.argv[0], str(mode), sysurl)
    contextMenuItems = []
    item = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": show, "Plot": description } )
    item.setProperty("IsPlayable", "true")
    item.setProperty( "Video", "true" )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        item.setProperty( "Fanart_Image", iconimage )
    else: item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)	
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total)

def get_shows(type):
    xbmc_data()
    shows = ''
    # 1-9
    if type == '1': navs = ['1-9']
    # �-�
    if type == '2': navs = ['%u0391','%u0392','%u0393','%u0394']
    # �-�
    if type == '3': navs = ['%u0395','%u0396','%u0397','%u0398']
    # �-�
    if type == '4': navs = ['%u0399','%u039A','%u039B','%u039C']
    # �-�
    if type == '5': navs = ['%u039D','%u039E','%u039F','%u03A0']
    # �-�
    if type == '6': navs = ['%u03A1','%u03A3','%u03A4','%u03A5']
    # �-�
    if type == '7': navs = ['%u03A6','%u03A7','%u03A8','%u03A9']
    # A-I
    if type == '8': navs = ['A','B','C','D','E','F','G','H','I']
    # J-R
    if type == '9': navs = ['J','K','L','M','N','O','P','Q','R']
    # S-Z
    if type == '10': navs = ['S','T','U','V','W','X','Y','Z']
    try:
        for nav in navs:
            try:
                nav_url = '%saz?letter=%s' % (shows_url, nav)
                result = common.fetchPage({"link": nav_url})
                shows += result["content"]
            except:
                pass
    except:
        xbmc_view()
        return
    try:
        shows = common.parseDOM(shows, "div", attrs = { "class": "videoTeaser" })
        total = len(shows)
    except:
        xbmc_view()
        return
    for show in shows:
        try:
            name = common.parseDOM(show, "a", attrs = { "href": ".+?" })[1]
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            url = common.parseDOM(show, "a", ret="href")[0]
            url = common.replaceHTMLCodes(url)
            url = base_url + url
            url = url.encode('utf-8')
            iconimage = common.parseDOM(show, "a", ret="rel")[0]
            iconimage = iconimage.split(".jpg")[0]
            iconimage = common.replaceHTMLCodes(iconimage)
            iconimage = '%s%s.jpg' % (base_url, iconimage)
            iconimage = iconimage.encode('utf-8')
            add_shows(total,name,url,600,iconimage)
        except:
            total = total - 1
            pass
    xbmc_view()
    return

def add_shows(total,name,url,mode,iconimage):
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    read = open(favPath, 'r')
    text = read.read()
    read.close()
    contextMenuItems = []
    if not url in text: contextMenuItems.append((xbmc.getLocalizedString(14076), 'XBMC.RunPlugin(%s?mode=100&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    else: contextMenuItems.append((xbmc.getLocalizedString(14077), 'XBMC.RunPlugin(%s?mode=101&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    u = '%s?mode=%s&show=%s&url=%s' % (sys.argv[0], str(mode), sysname, sysurl)
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        item.setProperty( "Fanart_Image", iconimage )
    else: item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)

def get_episodes(show,url):
    xbmc_data()
    try:
        url = url.replace('categories','templates/data/videocategories')
        result = common.fetchPage({"link": url})
        episodes = result["content"]
    except:
        xbmc_view()
        return
    try:
        navs = common.parseDOM(result["content"], "a", attrs = { "class": "paging" })
        navs = unique_list(navs)
        for nav in navs:
            nav_url = '%s&p=%s' % (url, nav)
            result = common.fetchPage({"link": nav_url})
            episodes += result["content"]
    except:
        pass
    try:
        episodes = common.parseDOM(episodes, "div", attrs = { "class": "videoTeaser" })
        total = len(episodes)
    except:
        xbmc_view()
        return
    for episode in episodes:
        try:
            name = common.parseDOM(episode, "div", attrs = { "class": "greytxt font11txt" })[0]
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            url = common.parseDOM(episode, "a", ret="href")[0]
            url = common.replaceHTMLCodes(url)
            url = base_url + url
            url = url.encode('utf-8')
            iconimage = common.parseDOM(episode, "a", ret="rel")[0]
            iconimage = iconimage.split(".jpg")[0]
            iconimage = common.replaceHTMLCodes(iconimage)
            iconimage = '%s%s.jpg' % (base_url, iconimage)
            iconimage = iconimage.encode('utf-8')
            add_episodes(total,name,show,url,iconimage)
        except:
            total = total - 1
            pass
    xbmc_view()
    return

def add_episodes(total,name,show,url,iconimage):
    mode = 900
    sysurl = urllib.quote_plus(url)
    u = '%s?mode=%s&url=%s' % (sys.argv[0], str(mode), sysurl)
    contextMenuItems = []
    item = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": show, "Plot": description } )
    item.setProperty("IsPlayable", "true")
    item.setProperty( "Video", "true" )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        item.setProperty( "Fanart_Image", iconimage )
    else: item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)	
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total)

def resolve_episodes(url):
    try:
        pageUrl = url
        swfUrl = 'http://www.antenna.gr/webtv/images/fbplayer.swf'
        url = url.replace('watch','templates/data/player')
        result = common.fetchPage({"link": url})
        rtmp = common.parseDOM(result["content"], "FMS")[0]
        playpath = common.parseDOM(result["content"], "appStream")[0]
        url = '%s playpath=%s pageUrl=%s swfUrl=%s swfVfy=true timeout=10' % (rtmp, playpath, pageUrl, swfUrl)
        if playpath.startswith('http://'): url = playpath
        item = xbmcgui.ListItem(path=url)
        return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
    except:
        return

def get_iconimage(url):
    try:
        url = url.replace('categories','templates/data/videocategories')
        result = common.fetchPage({"link": url})
        iconimage = common.parseDOM(result["content"], "div", attrs = { "class": "videoTeaser" })[0]
        iconimage = common.parseDOM(iconimage, "a", ret="rel")[0]
        iconimage = iconimage.split(".jpg")[0]
        iconimage = common.replaceHTMLCodes(iconimage)
        iconimage = '%s%s.jpg' % (base_url, iconimage)
        iconimage = iconimage.encode('utf-8')
        return iconimage
    except:
        return

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?','')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


params = get_params()
url = None
name = None
show = None
type = None
mode = None
try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    show = urllib.unquote_plus(params["show"])
except:
    pass
try:
    type = urllib.unquote_plus(params["type"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass


if mode == None or url == None or len(url) < 1:
    get_categories()

elif mode == 100:
    add_favourite_item(name,url)

elif mode == 101:
    delete_favourite_item(name,url)

elif mode == 102:
    move_favourite_item(name,url,'favup')

elif mode == 103:
    move_favourite_item(name,url,'favdown')

elif mode == 200:
    get_favourites()

elif mode == 300:
    get_cat_shows()

elif mode == 400:
    get_cat_episodes(type)

elif mode == 500:
    get_shows(type)

elif mode == 600:
    get_episodes(show,url)

elif mode == 900:
    resolve_episodes(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))