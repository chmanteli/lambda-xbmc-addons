# -*- coding: cp1253 -*-

'''
    ant1 player XBMC Addon
    Copyright (C) 2012 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib,urllib2,re,os,xbmcplugin,xbmcgui,xbmcaddon
from urllib import FancyURLopener
import random


settings = xbmcaddon.Addon(id='plugin.video.antenna.gr')
data = 'special://profile/addon_data/plugin.video.antenna.gr'

home = settings.getAddonInfo('path')
language = settings.getLocalizedString
addonname = settings.getAddonInfo("name")
description = language(30018).encode("utf-8")
icon = xbmc.translatePath(os.path.join(home,'icon.png'))
fanart = xbmc.translatePath(os.path.join(home,'fanart.jpg'))
artPath = xbmc.translatePath(os.path.join(home,'resources/art/'))
favPath = xbmc.translatePath(os.path.join(data,'favourites.cfg'))
datapath = xbmc.translatePath(data)
skin = xbmc.getSkinDir()

xbmcplugin.setContent(int(sys.argv[1]), 'Episodes')
xbmcplugin.setPluginFanart(int(sys.argv[1]), fanart)

try:
    import StorageServer
    cache = StorageServer.StorageServer(addonname,240)
except:
    import storageserverdummy as StorageServer
    cache = StorageServer.StorageServer(addonname,240)
	

match1 = 'class="img" rel="(.+?)&amp.+?cid=(.+?)"><img.+?href.+?">(.+?)</a>'
match2 = 'class="img" rel="(.+?)&amp.+?href="/webtv/watch(.+?)".+?txt">(.+?)<'
match3 = 'class="himg" rel="(.+?)&amp.+?href="/webtv/watch(.+?)">.+?txt">(.+?)<'

def xbmc_notify(type):
    if type == 'favadd':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30101).encode("utf-8")))
    elif type == 'favrem':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30102).encode("utf-8")))
    elif type == 'favup':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30103).encode("utf-8")))
    elif type == 'favdown':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30104).encode("utf-8")))

def xbmc_refresh():
    xbmc.executebuiltin("Container.Refresh")

def xbmc_view():
    viewenable = settings.getSetting("viewenable")

    if (skin == 'skin.confluence' or skin == 'skin.confluence-vertical' \
    or skin == 'skin.confluence.moviesets'):
        if viewenable == 'true':
            confluence_views = [50,51,500,503,504]
            view = int(settings.getSetting("confluence"))
            xbmc.executebuiltin("Container.SetViewMode("+str(confluence_views[view])+")")

    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        if viewenable == 'true':
            rapier_views = [50,52,74,73,68,94]
            view = int(settings.getSetting("rapier"))
            xbmc.executebuiltin("Container.SetViewMode("+str(rapier_views[view])+")")

def xbmc_data():
    if not os.path.exists(datapath):
        os.makedirs(datapath)
    if not os.path.isfile(favPath):
        read = open(favPath, 'w')
        read.write('')
        read.close()
		
def thumbnail_fixer(thumbnail):
	thumbnail = 'http://www.antenna.gr'+thumbnail
	return thumbnail
		
def GetURL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    link = link.replace('\n','')
    return link

def FancyURL(url):
    version = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
    opener = urllib.FancyURLopener({})
    response = opener.open(url)
    link = response.read()
    link = link.replace('\n','')
    return link


def get_categories(): # (UPDATABLE)
    xbmc_data()
    add_categories(language(30012).encode("utf-8"),200,artPath+'favorites.png')
    add_categories(language(30001).encode("utf-8"),300,artPath+'search.png')
    add_categories(language(30013).encode("utf-8"),500,artPath+'latest.png')
    add_categories(language(30014).encode("utf-8"),501,artPath+'latest-news.png')
    add_categories(language(30015).encode("utf-8"),502,artPath+'latest-sports.png')
    add_categories(language(30016).encode("utf-8"),503,artPath+'latest-shows.png')
    add_categories(language(30017).encode("utf-8"),504,artPath+'latest-series.png')
    xbmc_view()

def add_categories(name,mode,iconimage):
    contextMenuItems = []
    url = 'http://www.antenna.gr'
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        liz.setProperty( "Fanart_Image", iconimage )
    else: liz.setProperty( "Fanart_Image", fanart )
    liz.addContextMenuItems(contextMenuItems, replaceItems=True)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok


def get_favourites():
    xbmc_data()
    read = open(favPath, 'r')
    text = read.read()
    read.close()
    for name,cid in re.compile('"(.+?)"[|]"(.+?)"').findall(text):
        thumbnail = cache.cacheFunction(get_favourites_icon, cid)
        #thumbnail = get_favourites_icon(cid)
        add_favourites(name,cid,900,thumbnail)
    xbmc_view()

def get_favourites_icon(url): # (UPDATABLE)
    url = url.replace('categories','templates/data/videocategories')
    link = FancyURL(url+'&p=1')
    for thumbnail,cid,name in re.compile(match2).findall(link):
        thumbnail = thumbnail_fixer(thumbnail)
    return thumbnail

def add_favourites(name,url,mode,iconimage):
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    contextMenuItems = []
    contextMenuItems.append((xbmc.getLocalizedString(13332), 'XBMC.RunPlugin(%s?mode=102&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    contextMenuItems.append((xbmc.getLocalizedString(13333), 'XBMC.RunPlugin(%s?mode=103&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    contextMenuItems.append((xbmc.getLocalizedString(1210), 'XBMC.RunPlugin(%s?mode=101&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        liz.setProperty( "Fanart_Image", iconimage )
    else: liz.setProperty( "Fanart_Image", fanart )
    liz.addContextMenuItems(contextMenuItems, replaceItems=True)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def add_favourite_item(name,url):
    xbmc_refresh()
    read = open(favPath, 'a+')
    read.write('"'+name+'"|"'+url+'"\n')
    read.close()
    xbmc_notify('favadd')

def delete_favourite_item(name,url):
    xbmc_refresh()
    read = open(favPath, 'r')
    text = read.read().replace('"'+name+'"|"'+url+'"','')
    read.close()
    read = open(favPath, 'w')
    for line in re.compile('"(.+?)\n').findall(text):
        read.write('"'+line+'\n')
    read.close()
    xbmc_notify('favrem')

def move_favourite_item(name,url,type):
    xbmc_refresh()
    replaced = []
    j = []
    i = 0
    f = open(favPath,'r')
    for line in f:
        if re.search('"'+url.replace('?','[?]')+'"',line) is not None:
            j = i
        i = i+1
    f.close()
    if type == 'favup':
        i = 1
    if type == 'favdown':
        i = -1
    f = open(favPath,'r')
    for line in f:
        if i == j:
            replaced = line
        i = i+1
    f.close()

    if not replaced == []:
        read = open(favPath, 'r')
        text = read.read()
        if type == 'favup':
            text = text.replace(replaced+'"'+name+'"|"'+url+'"','"'+name+'"|"'+url+'"'+replaced)
            text = text.replace('\n','')
        if type == 'favdown':
            text = text.replace('"'+name+'"|"'+url+'"\n'+replaced,replaced+'"'+name+'"|"'+url+'"')
            text = text.replace('\n','')
        read.close()
        read = open(favPath, 'w')
        for name,cid in re.compile('"(.+?)"[|]"(.+?)"').findall(text):
            read.write('"'+name+'"|"'+cid+'"\n')
        if type == 'favup':
            xbmc_notify('favup')
        if type == 'favdown':
            xbmc_notify('favdown')
	    read.close()


def get_shows_categories(): # (UPDATABLE)
    add_shows_categories(language(30002).encode("utf-8"),400,artPath+'search-1.png')
    add_shows_categories(language(30003).encode("utf-8"),401,artPath+'search-2.png')
    add_shows_categories(language(30004).encode("utf-8"),402,artPath+'search-3.png')
    add_shows_categories(language(30005).encode("utf-8"),403,artPath+'search-4.png')
    add_shows_categories(language(30006).encode("utf-8"),404,artPath+'search-5.png')
    add_shows_categories(language(30007).encode("utf-8"),405,artPath+'search-6.png')
    add_shows_categories(language(30008).encode("utf-8"),406,artPath+'search-7.png')
    add_shows_categories(language(30009).encode("utf-8"),407,artPath+'search-8.png')
    add_shows_categories(language(30010).encode("utf-8"),408,artPath+'search-9.png')
    add_shows_categories(language(30011).encode("utf-8"),409,artPath+'search-10.png')
    xbmc_view()

def add_shows_categories(name,mode,iconimage):
    contextMenuItems = []
    url = 'http://www.antenna.gr'
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        liz.setProperty( "Fanart_Image", iconimage )
    else: liz.setProperty( "Fanart_Image", fanart )
    liz.addContextMenuItems(contextMenuItems, replaceItems=True)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def get_shows_1(v1,v2,v3,v4): # (UPDATABLE)
    link = GetURL(url+'/webtv/az?letter='+v1)+FancyURL(url+'/webtv/az?letter='+v2)+ \
    GetURL(url+'/webtv/az?letter='+v3)+FancyURL(url+'/webtv/az?letter='+v4)
    for thumbnail,cid,name in re.compile(match1).findall(link):
        name = name.replace('&amp;','&')
        thumbnail = thumbnail_fixer(thumbnail)
        cid = 'http://www.antenna.gr/webtv/categories?cid='+cid
        add_shows(name,cid,900,thumbnail)
    xbmc_view()

def get_shows_2(v1,v2,v3,v4,v5,v6,v7,v8,v9): # (UPDATABLE)
    link = GetURL(url+'/webtv/az?letter='+v1)+FancyURL(url+'/webtv/az?letter='+v2)+ \
    GetURL(url+'/webtv/az?letter='+v3)+FancyURL(url+'/webtv/az?letter='+v4)+ \
    GetURL(url+'/webtv/az?letter='+v5)+FancyURL(url+'/webtv/az?letter='+v6)+ \
    GetURL(url+'/webtv/az?letter='+v7)+FancyURL(url+'/webtv/az?letter='+v8)+ \
    GetURL(url+'/webtv/az?letter='+v9)
    for thumbnail,cid,name in re.compile(match1).findall(link):
        name = name.replace('&amp;','&')
        thumbnail = thumbnail_fixer(thumbnail)
        cid = 'http://www.antenna.gr/webtv/categories?cid='+cid
        add_shows(name,cid,900,thumbnail)
    xbmc_view()

def add_shows(name,url,mode,iconimage):
    read = open(favPath, 'r')
    text = read.read()
    read.close()
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    contextMenuItems = []
    if not url in text:
        contextMenuItems.append((xbmc.getLocalizedString(14076), 'XBMC.RunPlugin(%s?mode=100&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    else:
        contextMenuItems.append((xbmc.getLocalizedString(14077), 'XBMC.RunPlugin(%s?mode=101&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        liz.setProperty( "Fanart_Image", iconimage )
    else: liz.setProperty( "Fanart_Image", fanart )
    liz.addContextMenuItems(contextMenuItems, replaceItems=True)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok


def get_latest_episodes(v1,v2):
    link = GetURL('http://www.antenna.gr/webtv/')
    for link in re.compile(v1+'(.+?)'+v2).findall(link):
        for thumbnail,cid,name in re.compile(match3).findall(link):
            name = name.replace('&amp;','&')
            thumbnail = thumbnail_fixer(thumbnail)
            cid = 'http://www.antenna.gr/webtv/watch'+cid
            add_episodes(name,cid,thumbnail)
    xbmc_view()

def get_episodes(url): # (UPDATABLE)
    url = url.replace('categories','templates/data/videocategories')
    link = FancyURL(url+'&p=1')+FancyURL(url+'&p=2')+FancyURL(url+'&p=3')+FancyURL(url+'&p=4')+FancyURL(url+'&p=5')+ \
    FancyURL(url+'&p=6')+FancyURL(url+'&p=7')+FancyURL(url+'&p=8')+FancyURL(url+'&p=9')+FancyURL(url+'&p=10')+ \
    FancyURL(url+'&p=11')+FancyURL(url+'&p=12')+FancyURL(url+'&p=13')+FancyURL(url+'&p=14')+FancyURL(url+'&p=15')+ \
    FancyURL(url+'&p=16')+FancyURL(url+'&p=17')+FancyURL(url+'&p=18')+FancyURL(url+'&p=19')+FancyURL(url+'&p=20')
    for thumbnail,cid,name in re.compile(match2).findall(link):
        name = name.replace('&amp;','&')
        thumbnail = thumbnail_fixer(thumbnail)
        cid = 'http://www.antenna.gr/webtv/watch'+cid
        add_episodes(name,cid,thumbnail)
    xbmc_view()

def add_episodes(name,url,iconimage):
    mode = 901
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok = True
    contextMenuItems = []
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    liz.setProperty("IsPlayable", "true")
    liz.setProperty( "Video", "true" )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        liz.setProperty( "Fanart_Image", iconimage )
    else: liz.setProperty( "Fanart_Image", fanart )
    liz.addContextMenuItems(contextMenuItems, replaceItems=True)	
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
    return ok

def resolve_episodes(url): # (UPDATABLE)
    path = []
    playpath = []
    swfUrl = []
    pageUrl = url
    url = url.replace('watch','templates/data/player')
    search = re.compile('<WEBPATH>(.+?)</WEBPATH>').findall(GetURL(url))[-1]

    if re.search('.+?[.].+?[.].+?[.].+?/vod/',search) is not None:
        path_1 = re.split('\/vod/+', search)[0]+'/vod/ playpath='+re.split('\/vod/+', search)[-1].replace('.flv','')
        path_2 = 'rtmp://streamvideo.antenna.mediacdn.com/ondemand/ playpath='+re.split('\/vod/+', search)[-1].replace('mp4:','mp4:ant12/live24get/')
        path = random.choice([path_1, path_2])
        swfUrl = 'http://www.antenna.gr/webtv/images/fbplayer.swf'
        playpath = re.split('\/vod/+', search)[-1].replace('.flv','')
        url = path+' pageUrl='+pageUrl+' swfUrl='+swfUrl+' swfVfy=true'

    if re.search('.+?[.].+?[.].+?[.].+?/ondemand/',search) is not None:
        path = re.split('\/ondemand/+', search)[0]+'/ondemand/'
        swfUrl = 'http://www.antenna.gr/webtv/images/fbplayer.swf'
        playpath = re.split('\/ondemand/+', search)[-1].replace('ant1/mp4:','mp4:').replace('.flv','')
        url = path+' playpath='+playpath+' pageUrl='+pageUrl+' swfUrl='+swfUrl+' swfVfy=true'

    if re.search('.+?[.].+?[.].+?[.].+?/content/',search) is not None:
        path = re.split('\/content/+', search)[0]+'/content/'
        swfUrl = 'http://www.antenna.gr/webtv/images/fbplayer.swf'
        playpath = re.split('\/content/+', search)[-1].replace('.flv','')
        url = path+' playpath='+playpath+' pageUrl='+pageUrl+' swfUrl='+swfUrl+' swfVfy=true'

    if re.search('forth.cloud.ant1.gr/content/',search) is not None:
        path = re.split('\/content/+', search)[0].replace('rtmp://','rtmpe://')+'/content/'
        swfUrl = 'http://a.forth.cloud.ant1.gr/images/player.swf'
        playpath = re.split('\/content/+', search)[-1].replace('.flv','')
        url = path+' playpath='+playpath+' pageUrl='+pageUrl+' swfUrl='+swfUrl+' swfVfy=true'

    if re.search('media.123play.gr/vod/',search) is not None:
        path = 'rtmp://media.123play.gr/vod/'
        swfUrl = 'http://www.antenna.gr/webtv/images/fbplayer.swf'
        playpath = re.split('\/vod/+', search)[-1].replace('.flv','')
        url = path+' playpath='+playpath+' pageUrl='+pageUrl+' swfUrl='+swfUrl+' swfVfy=true'

    item = xbmcgui.ListItem(path=url)
    return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?','')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


params = get_params()
url = None
name = None
mode = None
try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass


if mode == None or url == None or len(url) < 1:
    get_categories()

elif mode == 100:
    add_favourite_item(name,url)

elif mode == 101:
    delete_favourite_item(name,url)

elif mode == 102:
    move_favourite_item(name,url,'favup')

elif mode == 103:
    move_favourite_item(name,url,'favdown')

elif mode == 200:
    get_favourites()

elif mode == 300:
    get_shows_categories()

elif mode == 400:
    get_shows_1('%u0391','%u0392','%u0393','%u0394')

elif mode == 401:
    get_shows_1('%u0395','%u0396','%u0397','%u0398')

elif mode == 402:
    get_shows_1('%u0399','%u039A','%u039B','%u039C')

elif mode == 403:
    get_shows_1('%u039D','%u039E','%u039F','%u03A0')

elif mode == 404:
    get_shows_1('%u03A1','%u03A3','%u03A4','%u03A5')

elif mode == 405:
    get_shows_1('%u03A6','%u03A7','%u03A8','%u03A9')

elif mode == 406:
    get_shows_1('1-9','','','')

elif mode == 407:
    get_shows_2('A','B','C','D','E','F','G','H','I')

elif mode == 408:
    get_shows_2('J','K','L','M','N','O','P','Q','R')

elif mode == 409:
    get_shows_2('S','T','U','V','W','X','Y','Z','')

elif mode == 500:
    get_latest_episodes('ctl00_slidesmall_ContentDiv','<div class="tab')

elif mode == 501:
    get_latest_episodes('ctl00_homebulletins1_contentDiv','</div></div>')

elif mode == 502:
    get_latest_episodes('ctl00_homeSports1_contentDiv','</div></div>')

elif mode == 503:
    get_latest_episodes('ctl00_homeEnter1_contentDiv','</div></div>')

elif mode == 504:
    get_latest_episodes('ctl00_homeSeries1_contentDiv','</div></div>')
	
elif mode == 900:
    get_episodes(url)

elif mode == 901:
    resolve_episodes(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))