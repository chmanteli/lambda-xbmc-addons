# -*- coding: cp1253 -*-

'''
    real fm podcast XBMC Addon
    Copyright (C) 2012 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib,urllib2,re,os,xbmcplugin,xbmcgui,xbmcaddon
import random


settings = xbmcaddon.Addon(id='plugin.audio.real.gr')
data = 'special://profile/addon_data/plugin.audio.real.gr'

home = settings.getAddonInfo('path')
language = settings.getLocalizedString
addonname = settings.getAddonInfo("name")
description = language(30002).encode("utf-8")
icon = xbmc.translatePath(os.path.join(home,'icon.png'))
fanart1 = xbmc.translatePath(os.path.join(home,'resources/fanart/1.jpg'))
fanart2 = xbmc.translatePath(os.path.join(home,'resources/fanart/2.jpg'))
logoPath = xbmc.translatePath(os.path.join(home,'resources/logos/'))
datapath = xbmc.translatePath(data)
skin = xbmc.getSkinDir()

try:
    import StorageServer
    cache = StorageServer.StorageServer(addonname,240)
except:
    import storageserverdummy as StorageServer
    cache = StorageServer.StorageServer(addonname,240)

xbmcplugin.setContent(int(sys.argv[1]), 'Songs')

base_url = 'http://www.real.gr/?page=radioathens&catID=50'
shows_pattern_1 = '<td valign="top"><a href="[?]page=radioathens&amp;(.+?)".+?src="(.+?)"'
shows_pattern_2 = '<span class="RealSpan">.+?</span>(.+?)</a>'
podcasts_pattern_1 = 'article_header_1stline".+?href="(.+?)">(.+?)</a></td>.+?src='+"'Files/Articles/(.+?)'"
podcasts_pattern_2 = "<img  src='Files/Articles/(.+?)'.+?<a class="+'"ArticleContent2".+?"(.+?)">(.+?)</a>'
parts_pattern_1 = "<a href='.+?VideoViewer.aspx.+?FileName=(.+?)'.+?src='(.+?)'.+?title='(.+?)'"

def GetURL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    link = link.replace('\n','')
    return link
	
def xbmc_view():
    viewenable = settings.getSetting("viewenable")

    if (skin == 'skin.confluence' or skin == 'skin.confluence-vertical' \
    or skin == 'skin.confluence.moviesets'):
        if viewenable == 'true':
            confluence_views = [50,51,500,506]
            view = int(settings.getSetting("confluence"))
            xbmc.executebuiltin("Container.SetViewMode("+str(confluence_views[view])+")")

    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        if viewenable == 'true':
            rapier_views = [50,63,52,77,62,67]
            view = int(settings.getSetting("rapier"))
            xbmc.executebuiltin("Container.SetViewMode("+str(rapier_views[view])+")")

def get_shows():
	add_shows(language(30001).encode("utf-8"),base_url,1,icon)
	link = GetURL(base_url)
	for url,thumbnail in re.compile(shows_pattern_1).findall(link):
		url = 'http://www.real.gr/?page=radioathens&'+url
		thumbnail = 'http://www.real.gr/'+thumbnail.replace(' ','%20')
		try:
			name = cache.cacheFunction(get_shows_name, url)
			#name = get_shows_name(url)
			add_shows(name,url,1,thumbnail)
		except:
			pass
	xbmc_view()

def get_shows_name(url):
	for name in re.compile(shows_pattern_2).findall(GetURL(url)):
		name = name.replace('  ','')
	return name

def add_shows(name,url,mode,iconimage):
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="music", infoLabels={ "Title": name, "Label": name, "Album": "Real Fm", "Comment": description } )
    liz.setProperty( "Album_Description", description )
    liz.setProperty( "Fanart_Image", random.choice([fanart1, fanart2]) )
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def get_podcasts(show):
	try:
		link = GetURL(show+'&curPage=1')
		for url,name,thumbnail in re.compile(podcasts_pattern_1).findall(link):
			thumbnail = 'http://www.real.gr/Files/Articles/'+thumbnail.replace(' ','%20')
			url = 'http://www.real.gr/'+url
			name = name.replace('  ','')
			add_podcasts(name,url,2,thumbnail)
		for thumbnail,url,name in re.compile(podcasts_pattern_2).findall(link):
			thumbnail = 'http://www.real.gr/Files/Articles/'+thumbnail.replace(' ','%20')
			url = 'http://www.real.gr/'+url
			name = name.replace('  ','')
			add_podcasts(name,url,2,thumbnail)
	except:
	    pass

	try:
		link = GetURL(show+'&curPage=2')
		for url,name,thumbnail in re.compile(podcasts_pattern_1).findall(link):
			thumbnail = 'http://www.real.gr/Files/Articles/'+thumbnail.replace(' ','%20')
			url = 'http://www.real.gr/'+url
			name = name.replace('  ','')
			add_podcasts(name,url,2,thumbnail)
		for thumbnail,url,name in re.compile(podcasts_pattern_2).findall(link):
			thumbnail = 'http://www.real.gr/Files/Articles/'+thumbnail.replace(' ','%20')
			url = 'http://www.real.gr/'+url
			name = name.replace('  ','')
			add_podcasts(name,url,2,thumbnail)
	except:
	    pass
	xbmc_view()

def add_podcasts(name,url,mode,iconimage):
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="music", infoLabels={ "Title": name, "Label": name, "Album": "Real Fm", "Comment": description } )
    liz.setProperty( "Album_Description", description )
    liz.setProperty( "Fanart_Image", random.choice([fanart1, fanart2]) )
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def get_parts(url):
	try:
		link = GetURL(url)
		for url,thumbnail,name in re.compile(parts_pattern_1).findall(link):
			url = 'http://www.real.gr/audiofiles/'+url
			add_parts(name,url,3,thumbnail)
	except:
	    pass
	xbmc_view()
		
def add_parts(name,url,mode,iconimage):
    mode = 0
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="music", infoLabels={ "Title": name, "Label": name, "Album": "Real Fm", "Comment": description } )
    liz.setProperty("IsPlayable", "true")
    liz.setProperty( "music", "true" )
    liz.setProperty( "Album_Description", description )
    liz.setProperty( "Fanart_Image", random.choice([fanart1, fanart2]) )
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok
	
def resolve_parts(url):
    item = xbmcgui.ListItem(path=url, iconImage=logoPath+'Real Fm.png', thumbnailImage=logoPath+'Real Fm.png')
    return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?','')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


params = get_params()
url = None
name = None
mode = None
try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass


if mode==None or url==None or len(url)<1:
    get_shows()
	
elif mode==0:
    resolve_parts(url)

elif mode==1:
    get_podcasts(url)

elif mode==2:
    get_parts(url)
	

xbmcplugin.endOfDirectory(int(sys.argv[1]))
