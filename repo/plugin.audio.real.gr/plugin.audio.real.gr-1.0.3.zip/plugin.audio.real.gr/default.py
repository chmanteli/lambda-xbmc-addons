# -*- coding: utf-8 -*-

'''
    real fm podcast XBMC Addon
    Copyright (C) 2012 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib,urllib2,re,os,xbmcplugin,xbmcgui,xbmcaddon
import random
import sets


settings = xbmcaddon.Addon(id='plugin.audio.real.gr')
data = 'special://profile/addon_data/plugin.audio.real.gr'

home = settings.getAddonInfo('path')
language = settings.getLocalizedString
addonname = settings.getAddonInfo("name")
genre = language(30502).encode("utf-8")
description = language(30503).encode("utf-8")
icon = xbmc.translatePath(os.path.join(home,'icon.png'))
fanart1 = xbmc.translatePath(os.path.join(home,'resources/fanart/1.jpg'))
fanart2 = xbmc.translatePath(os.path.join(home,'resources/fanart/2.jpg'))
image1 = xbmc.translatePath(os.path.join(home,'resources/images/1.png'))
image2 = xbmc.translatePath(os.path.join(home,'resources/images/2.png'))
datapath = xbmc.translatePath(data)
skin = xbmc.getSkinDir()
album = 'Real Fm'

xbmcplugin.setContent(int(sys.argv[1]), 'Songs')

try:
    import StorageServer
    cache = StorageServer.StorageServer(addonname,720)
except:
    import storageserverdummy as StorageServer
    cache = StorageServer.StorageServer(addonname,720)

try:
    import CommonFunctions
    common = CommonFunctions
except:
    import commonfunctionsdummy as CommonFunctions
    common = CommonFunctions



base_url = 'http://www.real.gr/'
producers_url = 'http://www.real.gr/?page=radioathens&catID=50'


def unique_list(list):
    unique_set = sets.Set()
    unique_list = []
    for n in list:
        if n not in unique_set:
            unique_set.add(n)
            unique_list.append(n)
    return unique_list

def xbmc_view():
    viewenable = settings.getSetting("viewenable")

    if (skin == 'skin.confluence' or skin == 'skin.confluence.svn') and viewenable == 'true':
        confluence_views = [50,51,500,506]
        view = int(settings.getSetting("confluence"))
        xbmc.executebuiltin("Container.SetViewMode("+str(confluence_views[view])+")")

    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn') and viewenable == 'true':
        rapier_views = [50,63,52,77,62,67]
        view = int(settings.getSetting("rapier"))
        xbmc.executebuiltin("Container.SetViewMode("+str(rapier_views[view])+")")

def get_producers():
    try:
        result = common.fetchPage({"link": producers_url})
        producers = common.parseDOM(result["content"], "td", attrs = { "id": "_ctl12__ctl0_HTML" })[0]
        producers = common.parseDOM(producers, "td", attrs = { "valign": "top" })
        total = len(producers) + 1
    except:
        total = 1
        xbmc_view()
        return
    add_producers(total,language(30501).encode("utf-8"),producers_url,1,image1)
    for producer in producers:
        try:
            iconimage = common.parseDOM(producer, "img", ret="src")[0]
            iconimage = base_url + iconimage
            iconimage = iconimage.replace(' ','%20')
            iconimage = iconimage.encode('utf-8')
            url = common.parseDOM(producer, "a", ret="href")[0]
            url = 'http://www.real.gr/DefaultArthro.aspx'+url
            url = common.replaceHTMLCodes(url)
            url = url.encode('utf-8')
            try:
                name = cache.cacheFunction(get_producers_name, url)
                #name = get_producers_name(url)
                name = common.replaceHTMLCodes(name)
                name = name.encode('utf-8')
                if name is not None:
                    add_producers(total,name,url,1,iconimage)
            except:
                pass
        except:
            total = total - 1
            pass
    xbmc_view()
    return

def get_producers_name(url):
    try:
        result = common.fetchPage({"link": url})
        name = common.parseDOM(result["content"], "tr", attrs = { "class": "CategoryTr" })[0]
        name = common.parseDOM(name, "a")[0]
        name = name.split("</span>")[1]
        return name
    except:
        return

def add_producers(total,name,url,mode,iconimage):
    sysartist = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    contextMenuItems = []
    u = '%s?mode=%s&url=%s&artist=%s' % (sys.argv[0], str(mode), sysurl, sysartist)
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    item.setInfo( type="music", infoLabels={ "Title": name, "Label": name, "Artist": name, "Album": album, "Genre": genre, "Comment": description } )
    item.setProperty( "Album_Description", description )
    item.setProperty( "Fanart_Image", random.choice([fanart1, fanart2]) )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)

def get_podcasts(url,artist):
    try:
        result = common.fetchPage({"link": url+'&curPage=1'})
        podcasts = common.parseDOM(result["content"], "td", attrs = { "class": "real_article_header_1stline" })[0]
        podcasts += common.parseDOM(result["content"], "div", attrs = { "id": "_ctl14__ctl0_Article" })[0]
        podcasts = podcasts.replace('real_article_header_1stline', 'ArticleContent2')
        podcasts = '<tr>%s</tr>' % (podcasts)
        podcasts += common.parseDOM(result["content"], "div", attrs = { "id": "_ctl14__ctl0_ArticleList" })[0]
    except:
        xbmc_view()
        return
    try:
        result = common.fetchPage({"link": url+'&curPage=2'})
        podcasts2 = common.parseDOM(result["content"], "td", attrs = { "class": "real_article_header_1stline" })[0]
        podcasts2 += common.parseDOM(result["content"], "div", attrs = { "id": "_ctl14__ctl0_Article" })[0]
        podcasts2 = podcasts2.replace('real_article_header_1stline', 'ArticleContent2')
        podcasts2 = '<tr>%s</tr>' % (podcasts2)
        podcasts2 += common.parseDOM(result["content"], "div", attrs = { "id": "_ctl14__ctl0_ArticleList" })[0]
        podcasts += podcasts2
    except:
        pass
    try:
        podcasts = common.parseDOM(podcasts, "tr")
        total = len(podcasts)
    except:
        xbmc_view()
        return
    for podcast in podcasts:
        try:
            name = common.parseDOM(podcast, "a", attrs = { "class": "ArticleContent2" })[0]
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            url = common.parseDOM(podcast, "a", attrs = { "class": "ArticleContent2" }, ret="href")[0]
            url = common.replaceHTMLCodes(url)
            url = base_url + url
            url = url.encode('utf-8')
            iconimage = common.parseDOM(podcast, "img", ret="src")[0]
            iconimage = base_url + iconimage
            iconimage = iconimage.replace(' ','%20')
            iconimage = iconimage.encode('utf-8')
            add_podcasts(total,name,artist,url,2,iconimage)
        except:
            total = total - 1
            pass
    xbmc_view()
    return

def add_podcasts(total,name,artist,url,mode,iconimage):
    sysartist = urllib.quote_plus(artist)
    sysurl = urllib.quote_plus(url)
    contextMenuItems = []
    u = '%s?mode=%s&url=%s&artist=%s' % (sys.argv[0], str(mode), sysurl, sysartist)
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    item.setInfo( type="music", infoLabels={ "Title": name, "Label": name, "Artist": artist, "Album": album, "Genre": genre, "Comment": description } )
    item.setProperty( "Album_Description", description )
    item.setProperty( "Fanart_Image", random.choice([fanart1, fanart2]) )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)

def get_podcasts_parts(url,artist):
    try:
        result = common.fetchPage({"link": url})
        podcasts_parts = common.parseDOM(result["content"], "ul", attrs = { "id": ".+?CarouselList" })[0]
        podcasts_parts = common.parseDOM(podcasts_parts, "li")
        total = len(podcasts_parts)
    except:
        xbmc_view()
        return
    for podcasts_part in podcasts_parts:
        try:
            name = common.parseDOM(podcasts_part, "img", ret="alt")[0]
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            url = common.parseDOM(podcasts_part, "a", ret="href")[0]
            url = url.split('FileName=')[1]
            url = 'http://www.real.gr/audiofiles/'+url
            url = url.encode('utf-8')
            iconimage = common.parseDOM(podcasts_part, "img", ret="src")[0]
            iconimage = iconimage.encode('utf-8')
            add_podcasts_parts(total,name,artist,url,iconimage)
        except:
            total = total - 1
            pass
    xbmc_view()
    return

def add_podcasts_parts(total,name,artist,url,iconimage):
    mode = 0
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    contextMenuItems = []
    u = '%s?mode=%s&name=%s&url=%s' % (sys.argv[0], str(mode), sysname, sysurl)
    item = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    item.setInfo( type="music", infoLabels={ "Title": name, "Label": name, "Artist": artist, "Album": album, "Genre": genre, "Comment": description } )
    item.setProperty("IsPlayable", "true")
    item.setProperty( "music", "true" )
    item.setProperty( "Album_Description", description )
    item.setProperty( "Fanart_Image", random.choice([fanart1, fanart2]) )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total)

def resolve_podcasts_parts(url):
    item = xbmcgui.ListItem(path=url, iconImage=image2, thumbnailImage=image2)
    return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?','')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


params = get_params()
url = None
name = None
mode = None
artist = None
iconimage = None
try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    artist = urllib.unquote_plus(params["artist"])
except:
    pass
try:
    iconimage = urllib.unquote_plus(params["iconimage"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass


if mode==None or url==None or len(url)<1:
    get_producers()

elif mode==1:
    get_podcasts(url,artist)

elif mode==2:
    get_podcasts_parts(url,artist)

elif mode==0:
    resolve_podcasts_parts(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))