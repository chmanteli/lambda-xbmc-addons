# -*- coding: utf-8 -*-

'''
    mega replay XBMC Addon
    Copyright (C) 2013 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib,urllib2,re,os,xbmc,xbmcplugin,xbmcgui,xbmcaddon
from operator import itemgetter
try:
    import StorageServer
except:
    import storageserverdummy as StorageServer
try:
    import CommonFunctions
except:
    import commonfunctionsdummy as CommonFunctions


language = xbmcaddon.Addon().getLocalizedString
setSetting = xbmcaddon.Addon().setSetting
getSetting = xbmcaddon.Addon().getSetting
addonname = xbmcaddon.Addon().getAddonInfo("name")
addonVersion = xbmcaddon.Addon().getAddonInfo("version")
addonId = xbmcaddon.Addon().getAddonInfo("id")
addonPath = xbmcaddon.Addon().getAddonInfo('path')
addonIcon = xbmc.translatePath(os.path.join(addonPath,'icon.png'))
artPath = xbmc.translatePath(os.path.join(addonPath,'resources/art/'))
showsPath = xbmc.translatePath(os.path.join(addonPath,'resources/shows/'))
fanart = xbmc.translatePath(os.path.join(addonPath,'fanart.jpg'))
dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))
favData = xbmc.translatePath(os.path.join(dataPath,'favourites3.cfg'))
viewData = xbmc.translatePath(os.path.join(dataPath,'views.cfg'))
cacheFull = StorageServer.StorageServer(addonname+addonVersion,720).cacheFunction
cache = StorageServer.StorageServer(addonname+addonVersion,720).cacheFunction
description = language(30450).encode("utf-8")
common = CommonFunctions
sysbase = sys.argv[0]
handle = int(sys.argv[1])
paramString = sys.argv[2]
skin = xbmc.getSkinDir()

shows_list = []
episodes_list = []
youtube_url = 'http://gdata.youtube.com'
youtube_search = 'http://gdata.youtube.com/feeds/api/videos?q='
youtube_playlist = 'http://gdata.youtube.com/feeds/api/playlists/'
youtube_user = 'http://gdata.youtube.com/feeds/api/users/'
megatv_url = 'http://www.megatv.com'
cinegreece_url = 'http://www.cinegreece.com'
greek_movies_url = 'http://greek-movies.com'

def main():
    xbmc_data()
    params = {}
    splitparams = paramString[paramString.find('?') + 1:].split('&')
    for param in splitparams:
        if (len(param) > 0):
            splitparam = param.split('=')
            key = splitparam[0]
            try: 
                value = splitparam[1].encode("utf-8")
            except:
                value = splitparam[1]
            params[key] = value

    try:		action = urllib.unquote_plus(params["action"])
    except:		action = None
    try:		name = urllib.unquote_plus(params["name"])
    except:		name = None
    try:		show = urllib.unquote_plus(params["show"])
    except:		show = None
    try:		url = urllib.unquote_plus(params["url"])
    except:		url = None
    try:		image = urllib.unquote_plus(params["image"])
    except:		image = None
    try:		mode = urllib.unquote_plus(params["mode"])
    except:		mode = None

    if action == None:							get_categories()
    elif action == 'play_item':					play_item()
    elif action == 'random_play_item':			random_play_item()
    elif action == 'queue_item':				queue_item()
    elif action == 'play_from_here_item':		play_from_here_item(url)
    elif action == 'add_favourite_item':		add_favourite_item(name,url)
    elif action == 'delete_favourite_item':		delete_favourite_item(name,url)
    elif action == 'move_favourite_item_up':	move_favourite_item_up(name,url)
    elif action == 'move_favourite_item_down':	move_favourite_item_down(name,url)
    elif action == 'play_queue':				play_queue()
    elif action == 'open_playlist':				open_playlist()
    elif action == 'xbmc_set_view':				xbmc_set_view()
    elif action == 'open_settings':				open_settings()
    elif action == 'get_favourites':			get_favourites()
    elif action == 'get_sub_categories':		get_sub_categories()
    elif action == 'get_news':					get_news()
    elif action == 'get_sports':				get_sports()
    elif action == 'get_megatv_series':			get_megatv_series()
    elif action == 'get_megatv_shows':			get_megatv_shows()
    elif action == 'get_megatv_info_shows':		get_megatv_info_shows()
    elif action == 'get_megatv_cook_shows':		get_megatv_cook_shows()
    elif action == 'get_megatv_classics':		get_megatv_classics()
    elif action == 'get_youtube_shows':			get_youtube_shows()
    elif action == 'get_episodes':				get_episodes(show,url,image)
    elif action == 'play_video':				play_video(url)

    xbmcplugin.setContent(handle, 'Episodes')
    xbmcplugin.setPluginFanart(handle, fanart)
    xbmcplugin.endOfDirectory(handle)
    xbmc_view()
    return

def fetchGreekPage(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    link = GreekCharacters(link,'replace')
    link = unicode(link, errors='ignore')
    link = link.encode('utf-8')
    return link

def unique_list(list):
    unique_set = set()
    unique_list = []
    for n in list:
        if n not in unique_set:
            unique_set.add(n)
            unique_list.append(n)
    return unique_list

def GreekCharacters(data,mode):
    list = []
    list.append({'1': '�', '2': '\u0386', '3': '\u0391', '4': u'\u0386'}) # capital alpha with acute, U+0386'
    list.append({'1': '�', '2': '\u0388', '3': '\u0395', '4': u'\u0388'}) # capital epsilon with acute, U+0388'
    list.append({'1': '�', '2': '\u0389', '3': '\u0397', '4': u'\u0389'}) # capital eta with acute, U+0389'
    list.append({'1': '�', '2': '\u038A', '3': '\u0399', '4': u'\u038A'}) # capital iota with acute, U+A'
    list.append({'1': '�', '2': '\u038C', '3': '\u039F', '4': u'\u038C'}) # capital omicron with acute, U+038C'
    list.append({'1': '�', '2': '\u038E', '3': '\u03A5', '4': u'\u038E'}) # capital upsilon with acute, U+038E'
    list.append({'1': '�', '2': '\u038F', '3': '\u03A9', '4': u'\u038F'}) # capital omega with acute, U+038F'
    list.append({'1': '�', '2': '\u0390', '3': '\u03AA', '4': u'\u0390'}) # small iota with acute and diaeresis, U+0390'
    list.append({'1': '�', '2': '\u0391', '3': '\u0391', '4': u'\u0391'}) # capital alpha, U+0391'
    list.append({'1': '�', '2': '\u0392', '3': '\u0392', '4': u'\u0392'}) # capital beta, U+0392'
    list.append({'1': '�', '2': '\u0393', '3': '\u0393', '4': u'\u0393'}) # capital gamma, U+0393'
    list.append({'1': '�', '2': '\u0394', '3': '\u0394', '4': u'\u0394'}) # capital delta, U+0394'
    list.append({'1': '�', '2': '\u0395', '3': '\u0395', '4': u'\u0395'}) # capital epsilon, U+0395'
    list.append({'1': '�', '2': '\u0396', '3': '\u0396', '4': u'\u0396'}) # capital zeta, U+0396'
    list.append({'1': '�', '2': '\u0397', '3': '\u0397', '4': u'\u0397'}) # capital eta, U+0397'
    list.append({'1': '�', '2': '\u0398', '3': '\u0398', '4': u'\u0398'}) # capital theta, U+0398'
    list.append({'1': '�', '2': '\u0399', '3': '\u0399', '4': u'\u0399'}) # capital iota, U+0399'
    list.append({'1': '�', '2': '\u039A', '3': '\u039A', '4': u'\u039A'}) # capital kappa, U+039A'
    list.append({'1': '�', '2': '\u039B', '3': '\u039B', '4': u'\u039B'}) # capital lambda, U+039B'
    list.append({'1': '�', '2': '\u039C', '3': '\u039C', '4': u'\u039C'}) # capital mu, U+039C'
    list.append({'1': '�', '2': '\u039D', '3': '\u039D', '4': u'\u039D'}) # capital nu, U+039D'
    list.append({'1': '�', '2': '\u039E', '3': '\u039E', '4': u'\u039E'}) # capital chi, U+039E'
    list.append({'1': '�', '2': '\u039F', '3': '\u039F', '4': u'\u039F'}) # capital omicron, U+039F'
    list.append({'1': '�', '2': '\u03A0', '3': '\u03A0', '4': u'\u03A0'}) # capital pi, U+03A0'
    list.append({'1': '�', '2': '\u03A1', '3': '\u03A1', '4': u'\u03A1'}) # capital rho, U+03A1'
    list.append({'1': '�', '2': '\u03A3', '3': '\u03A3', '4': u'\u03A3'}) # capital sigma, U+03A3'
    list.append({'1': '�', '2': '\u03A4', '3': '\u03A4', '4': u'\u03A4'}) # capital tau, U+03A4'
    list.append({'1': '�', '2': '\u03A5', '3': '\u03A5', '4': u'\u03A5'}) # capital upsilon, U+03A5'
    list.append({'1': '�', '2': '\u03A6', '3': '\u03A6', '4': u'\u03A6'}) # capital phi, U+03A6'
    list.append({'1': '�', '2': '\u03A7', '3': '\u03A7', '4': u'\u03A7'}) # capital xi, U+03A7'
    list.append({'1': '�', '2': '\u03A8', '3': '\u03A8', '4': u'\u03A8'}) # capital psi, U+03A8'
    list.append({'1': '�', '2': '\u03A9', '3': '\u03A9', '4': u'\u03A9'}) # capital omega, U+03A9'
    list.append({'1': '�', '2': '\u03AA', '3': '\u03AA', '4': u'\u03AA'}) # capital iota with diaeresis, U+03AA'
    list.append({'1': '�', '2': '\u03AB', '3': '\u03AB', '4': u'\u03AB'}) # capital upsilon with diaeresis, U+03AB'
    list.append({'1': '�', '2': '\u03AC', '3': '\u0391', '4': u'\u03AC'}) # small alpha with acute, U+03AC'
    list.append({'1': '�', '2': '\u03AD', '3': '\u0395', '4': u'\u03AD'}) # small epsilon with acute, U+03AD'
    list.append({'1': '�', '2': '\u03AE', '3': '\u0397', '4': u'\u03AE'}) # small eta with acute, U+03AE'
    list.append({'1': '�', '2': '\u03AF', '3': '\u0399', '4': u'\u03AF'}) # small iota with acute, U+03AF'
    list.append({'1': '�', '2': '\u03B0', '3': '\u03AB', '4': u'\u03B0'}) # small upsilon with acute and diaeresis, U+03B0'
    list.append({'1': '�', '2': '\u03B1', '3': '\u0391', '4': u'\u03B1'}) # small alpha, U+03B1'
    list.append({'1': '�', '2': '\u03B2', '3': '\u0392', '4': u'\u03B2'}) # small beta, U+03B2'
    list.append({'1': '�', '2': '\u03B3', '3': '\u0393', '4': u'\u03B3'}) # small gamma, U+03B3'
    list.append({'1': '�', '2': '\u03B4', '3': '\u0394', '4': u'\u03B4'}) # small delta, U+03B4'
    list.append({'1': '�', '2': '\u03B5', '3': '\u0395', '4': u'\u03B5'}) # small epsilon, U+03B5'
    list.append({'1': '�', '2': '\u03B6', '3': '\u0396', '4': u'\u03B6'}) # small zeta, U+03B6'
    list.append({'1': '�', '2': '\u03B7', '3': '\u0397', '4': u'\u03B7'}) # small eta, U+03B7'
    list.append({'1': '�', '2': '\u03B8', '3': '\u0398', '4': u'\u03B8'}) # small theta, U+03B8'
    list.append({'1': '�', '2': '\u03B9', '3': '\u0399', '4': u'\u03B9'}) # small iota, U+03B9'
    list.append({'1': '�', '2': '\u03BA', '3': '\u039A', '4': u'\u03BA'}) # small kappa, U+03BA'
    list.append({'1': '�', '2': '\u03BB', '3': '\u039B', '4': u'\u03BB'}) # small lambda, U+03BB'
    list.append({'1': '�', '2': '\u03BC', '3': '\u039C', '4': u'\u03BC'}) # small mu, U+03BC'
    list.append({'1': '�', '2': '\u03BD', '3': '\u039D', '4': u'\u03BD'}) # small nu, U+03BD'
    list.append({'1': '�', '2': '\u03BE', '3': '\u039E', '4': u'\u03BE'}) # small chi, U+03BE'
    list.append({'1': '�', '2': '\u03BF', '3': '\u039F', '4': u'\u03BF'}) # small omicron, U+03BF'
    list.append({'1': '�', '2': '\u03C0', '3': '\u03A0', '4': u'\u03C0'}) # small pi, U+03C0'
    list.append({'1': '�', '2': '\u03C1', '3': '\u03A1', '4': u'\u03C1'}) # small rho, U+03C1'
    list.append({'1': '�', '2': '\u03C2', '3': '\u03A3', '4': u'\u03C2'}) # small final sigma, U+03C2'
    list.append({'1': '�', '2': '\u03C3', '3': '\u03A3', '4': u'\u03C3'}) # small sigma, U+03C3'
    list.append({'1': '�', '2': '\u03C4', '3': '\u03A4', '4': u'\u03C4'}) # small tau, U+03C4'
    list.append({'1': '�', '2': '\u03C5', '3': '\u03A5', '4': u'\u03C5'}) # small upsilon, U+03C5'
    list.append({'1': '�', '2': '\u03C6', '3': '\u03A6', '4': u'\u03C6'}) # small phi, U+03C6'
    list.append({'1': '�', '2': '\u03C7', '3': '\u03A7', '4': u'\u03C7'}) # small xi, U+03C7'
    list.append({'1': '�', '2': '\u03C8', '3': '\u03A8', '4': u'\u03C8'}) # small psi, U+03C8'
    list.append({'1': '�', '2': '\u03C9', '3': '\u03A9', '4': u'\u03C9'}) # small omega, U+03C9'
    list.append({'1': '�', '2': '\u03CA', '3': '\u03AA', '4': u'\u03CA'}) # small iota with diaeresis, U+03CA'
    list.append({'1': '�', '2': '\u03CB', '3': '\u03AB', '4': u'\u03CB'}) # small upsilon with diaeresis, U+03CB'
    list.append({'1': '�', '2': '\u03CC', '3': '\u039F', '4': u'\u03CC'}) # small omicron with acute, U+03CC'
    list.append({'1': '�', '2': '\u03CD', '3': '\u03A5', '4': u'\u03CD'}) # small upsilon with acute, U+03CD'
    list.append({'1': '�', '2': '\u03CE', '3': '\u03A9', '4': u'\u03CE'}) # small omega with acute, U+03CE'

    if mode == 'complete':
        for item in list: data = data.replace(item['1'], item['2'])
        for item in list: data = data.replace(item['2'], item['4'])
    if mode == 'replace':
        for item in list: data = data.replace(item['1'], item['2'])
    if mode == 'restore':
        for item in list: data = data.replace(item['2'], item['4'])
    if mode == 'replace_low':
        for item in list: data = data.replace(item['1'], item['2'].lower())
    if mode == 'restore_low':
        for item in list: data = data.replace(item['2'].lower(), item['4'])
    if mode == 'upper':
        for item in list: data = data.replace(item['2'], item['3'])
    if mode == 'low':
        for item in list: data = data.replace(item['3'], item['2'])
    return data

def check_addon(id):
    check_addon = xbmcaddon.Addon(id=id).getAddonInfo("name")
    if not check_addon == addonname: return check_addon
    return

def xbmc_notify(mode):
    if mode == 'setview':
        viewName = xbmc.getInfoLabel('Container.Viewmode')
        xbmc.executebuiltin("Notification(%s,%s, 3000)" % (addonname, '%s%s%s') % (language(30301).encode("utf-8"), viewName, language(30302).encode("utf-8")))
    elif mode == 'favadd':
        xbmc.executebuiltin("Notification(%s,%s, 3000)" % (addonname, language(30303).encode("utf-8")))
    elif mode == 'favrem':
        xbmc.executebuiltin("Notification(%s,%s, 3000)" % (addonname, language(30304).encode("utf-8")))
    elif mode == 'favup':
        xbmc.executebuiltin("Notification(%s,%s, 3000)" % (addonname, language(30305).encode("utf-8")))
    elif mode == 'favdown':
        xbmc.executebuiltin("Notification(%s,%s, 3000)" % (addonname, language(30306).encode("utf-8")))

def xbmc_refresh():
    xbmc.executebuiltin('Container.Refresh')

def xbmc_data():
    if not os.path.exists(dataPath):
        os.makedirs(dataPath)
    if not os.path.isfile(favData):
        file = open(favData, 'w')
        file.write('')
        file.close()
    if not os.path.isfile(viewData):
        file = open(viewData, 'w')
        file.write('')
        file.close()

def xbmc_view():
    try:
        file = open(viewData,'r')
        read = file.read().replace('\n','')
        file.close()
        view = re.compile('"%s"[|]"(.+?)"' % (skin)).findall(read)[0]
        xbmc.executebuiltin('Container.SetViewMode(%s)' % str(view))
    except:
        if (skin == 'skin.confluence'):			xbmc.executebuiltin('Container.SetViewMode(503)')
        if (skin == 'skin.ace'):				xbmc.executebuiltin('Container.SetViewMode(59)')
        if (skin == 'skin.aeon.nox'):			xbmc.executebuiltin('Container.SetViewMode(518)')
        if (skin == 'skin.back-row'):			xbmc.executebuiltin('Container.SetViewMode(529)')
        if (skin == 'skin.carmichael'):			xbmc.executebuiltin('Container.SetViewMode(50)')
        if (skin == 'skin.diffuse'):			xbmc.executebuiltin('Container.SetViewMode(55)')
        if (skin == 'skin.metropolis'):			xbmc.executebuiltin('Container.SetViewMode(55)')
        if (skin == 'skin.pm3-hd'):				xbmc.executebuiltin('Container.SetViewMode(58)')
        if (skin == 'skin.transparency'):		xbmc.executebuiltin('Container.SetViewMode(51)')
        if (skin == 'skin.xeebo'):				xbmc.executebuiltin('Container.SetViewMode(50)')
        if (skin == 'skin.xperience-more'):		xbmc.executebuiltin('Container.SetViewMode(50)')
        if (skin == 'skin.fusion.migma.v3'):	xbmc.executebuiltin('Container.SetViewMode(504)')
        if (skin == 'skin.bello'):				xbmc.executebuiltin('Container.SetViewMode(50)')
        if (skin == 'skin.cirrus.extended.v3'):	xbmc.executebuiltin('Container.SetViewMode(55)')
        if (skin == 'skin.neon'):				xbmc.executebuiltin('Container.SetViewMode(53)')
        if (skin == 'skin.quartz'):				xbmc.executebuiltin('Container.SetViewMode(52)')
        if (skin == 'skin.quartz.reloaded'):	xbmc.executebuiltin('Container.SetViewMode(52)')
        if (skin == 'skin.rapier'):				xbmc.executebuiltin('Container.SetViewMode(68)')
        if (skin == 'skin.re-touched'):			xbmc.executebuiltin('Container.SetViewMode(550)')
        if (skin == 'skin.refocus'):			xbmc.executebuiltin('Container.SetViewMode(50)')
        if (skin == 'skin.simplicity.frodo'):	xbmc.executebuiltin('Container.SetViewMode(50)')
        if (skin == 'skin.touched'):			xbmc.executebuiltin('Container.SetViewMode(50)')
        if (skin == 'skin.xperience1080'):		xbmc.executebuiltin('Container.SetViewMode(50)')

def xbmc_set_view():
    try:
        skinInfo = xbmc.translatePath('special://xbmc/addons/%s/addon.xml' % (skin))
        videoNav = 'special://xbmc/addons/%s/%s/MyVideoNav.xml'
        if not os.path.isfile(skinInfo):
            skinInfo = xbmc.translatePath('special://home/addons/%s/addon.xml' % (skin))
            videoNav = 'special://home/addons/%s/%s/MyVideoNav.xml'
        file = open(skinInfo,'r')
        read = file.read().replace('\n','')
        file.close()
        try:
            skinInfo = re.compile('defaultresolution="(.+?)"').findall(read)[0]
        except:
            skinInfo = re.compile('<res.+?folder="(.+?)"').findall(read)[0]
        videoNav = xbmc.translatePath(videoNav % (skin, skinInfo))
        file = open(videoNav,'r')
        read = file.read().replace('\n','')
        file.close()
        views = re.compile('<views>(.+?)</views>').findall(read)[0]
        views = [int(x) for x in views.split(',')]
        for view in views:
            viewLabel = xbmc.getInfoLabel('Control.GetLabel(%s)' % (view))
            if not (viewLabel == '' or viewLabel is None): break
        file = open(viewData, 'r')
        read = file.read()
        file.close()
        file = open(viewData, 'w')
        for line in re.compile('(".+?\n)').findall(read):
            if not line.startswith('"%s"|"' % (skin)): file.write(line)
        file.write('"%s"|"%s"\n' % (skin, str(view)))
        file.close()
        xbmc_notify('setview')
    except:
        return

def play_item():
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    xbmc.executebuiltin('Action(Queue)')
    playlist.unshuffle()
    xbmc.Player().play(playlist)

def random_play_item():
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    xbmc.executebuiltin('Action(Queue)')
    playlist.shuffle()
    xbmc.Player().play(playlist)

def queue_item():
    xbmc.executebuiltin('Action(Queue)')

def play_from_here_item(url):
    try:
        deamon = url
        folderPath = xbmc.getInfoLabel('Container.FolderPath')
        params = folderPath.split("?")[-1]
        params = dict(arg.split("=") for arg in params.split("&"))
        if params["action"] == "get_news": episodes_list = get_news()
        if params["action"] == "get_sports": episodes_list = get_sports()
        if params["action"] == "get_episodes":
            show = urllib.unquote_plus(params["show"])
            url = urllib.unquote_plus(params["url"])
            image = urllib.unquote_plus(params["image"])
            episodes_list = get_episodes(show,url,image)
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()
        playlist.unshuffle()
        episodes_list.reverse()
        play_from_here_list = []
        for item in episodes_list:
            play_from_here_list.append({'name': item['name'], 'show': item['show'], 'url': item['url'], 'image': item['image']})
            if deamon == item['url']: break
        play_from_here_list.reverse()
        for item in play_from_here_list:
            add_episodes(0,item['name'],item['show'],item['url'],item['image'],'playlist')
        xbmc.Player().play(playlist)
    except:
        return

def add_favourite_item(name,url):
    xbmc_refresh()
    file = open(favData, 'a+')
    file.write('"%s"|"%s"\n' % (name, url))
    file.close()
    xbmc_notify('favadd')

def delete_favourite_item(name,url):
    xbmc_refresh()
    file = open(favData, 'r')
    read = file.read().replace('"%s"|"%s"' % (name, url),'')
    file.close()
    file = open(favData, 'w')
    for line in re.compile('(".+?\n)').findall(read):
        file.write(line)
    file.close()
    xbmc_notify('favrem')

def move_favourite_item_up(name,url):
    xbmc_refresh()
    file = open(favData,'r')
    read = file.read()
    file.close()
    favourites_list = []
    for line in re.compile('(".+?)\n').findall(read):
        favourites_list.append(line)
    i = favourites_list.index('"%s"|"%s"' % (name, url))
    if i == 0: return
    favourites_list[i],favourites_list[i-1] = favourites_list[i-1],favourites_list[i]
    file = open(favData, 'w')
    for line in favourites_list:
        file.write('%s\n' % (line))
    file.close()
    xbmc_notify('favup')

def move_favourite_item_down(name,url):
    xbmc_refresh()
    file = open(favData,'r')
    read = file.read()
    file.close()
    favourites_list = []
    for line in re.compile('(".+?)\n').findall(read):
        favourites_list.append(line)
    i = favourites_list.index('"%s"|"%s"' % (name, url))
    if i+1 == len(favourites_list): return
    favourites_list[i],favourites_list[i+1] = favourites_list[i+1],favourites_list[i]
    file = open(favData, 'w')
    for line in favourites_list:
        file.write('%s\n' % (line))
    file.close()
    xbmc_notify('favdown')

def play_queue():
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.unshuffle()
    xbmc.Player().play(playlist)

def open_playlist():
    xbmc.executebuiltin('ActivateWindow(VideoPlaylist)')

def open_settings():
    xbmc.executebuiltin('Addon.OpenSettings(%s)' % (addonId))

def get_favourites():
    file = open(favData, 'r')
    read = file.read()
    file.close()
    fix_list = fix_favourites()
    for item in fix_list: read = read.replace(item['1'], item['2'])
    file = open(favData, 'w')
    file.write(read)
    file.close()

    file = open(favData, 'r')
    read = file.read()
    file.close()
    list = re.compile('"(.+?)"[|]"(.+?)"').findall(read)
    total = len(list)
    for name,url in list:
        image = cacheFull(get_episodes,name,url,'','image')
        #image = get_episodes(name,url,'','image')
        if image == [] or image == "" or image is None: image = artPath+'Favourites.png'
        add_favourites(total,name,url,image)
    return

def add_favourites(total,name,url,image):
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    sysimage = urllib.quote_plus(image)
    u = '%s?action=get_episodes&show=%s&url=%s&image=%s' % (sysbase, sysname, sysurl, sysimage)
    cm = []
    cm.append((language(30401).encode("utf-8"), 'RunPlugin(%s?action=play_item)' % (sysbase)))
    cm.append((language(30402).encode("utf-8"), 'RunPlugin(%s?action=random_play_item)' % (sysbase)))
    cm.append((language(30404).encode("utf-8"), 'RunPlugin(%s?action=queue_item)' % (sysbase)))
    cm.append((language(30406).encode("utf-8"), 'RunPlugin(%s?action=play_queue)' % (sysbase)))
    cm.append((language(30407).encode("utf-8"), 'RunPlugin(%s?action=open_playlist)' % (sysbase)))
    cm.append((language(30408).encode("utf-8"), 'RunPlugin(%s?action=xbmc_set_view)' % (sysbase)))
    #cm.append((language(30409).encode("utf-8"), 'RunPlugin(%s?action=open_settings)' % (sysbase)))
    cm.append((language(30410).encode("utf-8"), 'RunPlugin(%s?action=move_favourite_item_up&name=%s&url=%s)' % (sysbase, sysname, sysurl)))
    cm.append((language(30411).encode("utf-8"), 'RunPlugin(%s?action=move_favourite_item_down&name=%s&url=%s)' % (sysbase, sysname, sysurl)))
    cm.append((language(30412).encode("utf-8"), 'RunPlugin(%s?action=delete_favourite_item&name=%s&url=%s)' % (sysbase, sysname, sysurl)))
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=image)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    item.setProperty("Fanart_Image", fanart)
    item.addContextMenuItems(cm, replaceItems=True)
    xbmcplugin.addDirectoryItem(handle=handle,url=u,listitem=item,totalItems=total,isFolder=True)
    return

def get_categories():
    total = 5
    add_categories(total,language(30501).encode("utf-8"),artPath+'Favourites.png','get_favourites')
    add_categories(total,language(30502).encode("utf-8"),artPath+'MEGA TV.png','get_sub_categories')
    add_categories(total,language(30503).encode("utf-8"),artPath+'YouTube.png','get_youtube_shows')
    add_categories(total,language(30504).encode("utf-8"),artPath+'News.png','get_news')
    add_categories(total,language(30505).encode("utf-8"),artPath+'Sports.png','get_sports')
    return

def get_sub_categories():
    total = 5
    add_categories(total,language(30506).encode("utf-8"),artPath+'Series.png','get_megatv_series')
    add_categories(total,language(30507).encode("utf-8"),artPath+'Shows.png','get_megatv_shows')
    add_categories(total,language(30508).encode("utf-8"),artPath+'Info.png','get_megatv_info_shows')
    add_categories(total,language(30509).encode("utf-8"),artPath+'Cook.png','get_megatv_cook_shows')
    add_categories(total,language(30510).encode("utf-8"),artPath+'Classics.png','get_megatv_classics')
    return

def add_categories(total,name,image,action):
    u = '%s?action=%s' % (sysbase, action)
    cm = []
    if action == 'get_news' or action == 'get_sports':
        cm.append((language(30401).encode("utf-8"), 'RunPlugin(%s?action=play_item)' % (sysbase)))
        cm.append((language(30402).encode("utf-8"), 'RunPlugin(%s?action=random_play_item)' % (sysbase)))
        cm.append((language(30404).encode("utf-8"), 'RunPlugin(%s?action=queue_item)' % (sysbase)))
    cm.append((language(30406).encode("utf-8"), 'RunPlugin(%s?action=play_queue)' % (sysbase)))
    cm.append((language(30407).encode("utf-8"), 'RunPlugin(%s?action=open_playlist)' % (sysbase)))
    cm.append((language(30408).encode("utf-8"), 'RunPlugin(%s?action=xbmc_set_view)' % (sysbase)))
    #cm.append((language(30409).encode("utf-8"), 'RunPlugin(%s?action=open_settings)' % (sysbase)))
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=image)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    item.setProperty("Fanart_Image", fanart)
    item.addContextMenuItems(cm, replaceItems=True)
    xbmcplugin.addDirectoryItem(handle=handle,url=u,listitem=item,totalItems=total,isFolder=True)
    return

def get_megatv_series():
    global shows_list
    shows_list = []
 
    total = 0
    shows_list = get_megatv_shows_list('http://www.megatv.com/webtv/default.asp?catid=27548')
    #shows_list = sorted(shows_list, key=itemgetter('name'))

    for item in shows_list:
        name = item['name']
        url = item['url']
        image = item['image']
        total += 1
        add_shows(total,name,url,image)

    return shows_list

def get_megatv_shows():
    global shows_list
    shows_list = []
 
    total = 0
    shows_list = get_megatv_shows_list('http://www.megatv.com/webtv/default.asp?catid=30453')
    #shows_list = sorted(shows_list, key=itemgetter('name'))

    for item in shows_list:
        name = item['name']
        url = item['url']
        image = item['image']
        total += 1
        add_shows(total,name,url,image)

    return shows_list

def get_megatv_info_shows():
    global shows_list
    shows_list = []
 
    total = 0
    shows_list = get_megatv_shows_list('http://www.megatv.com/webtv/default.asp?catid=30457')
    #shows_list = sorted(shows_list, key=itemgetter('name'))

    for item in shows_list:
        name = item['name']
        url = item['url']
        image = item['image']
        total += 1
        add_shows(total,name,url,image)

    return shows_list

def get_megatv_cook_shows():
    global shows_list
    shows_list = []
 
    total = 0
    shows_list = get_megatv_shows_list('http://www.megatv.com/webtv/cook/default.asp?catid=30088')
    #shows_list = sorted(shows_list, key=itemgetter('name'))

    for item in shows_list:
        name = item['name']
        url = item['url']
        image = item['image']
        total += 1
        add_shows(total,name,url,image)

    return shows_list

def get_megatv_classics():
    global shows_list
    shows_list = []
 
    total = 0
    shows_list = get_megatv_shows_list('http://www.megatv.com/classics.asp?catid=29991')
    #shows_list = sorted(shows_list, key=itemgetter('name'))

    for item in shows_list:
        name = item['name']
        url = item['url']
        image = item['image']
        total += 1
        add_shows(total,name,url,image)

    return shows_list

def get_megatv_shows_list(url):
    try:
        catUrl = url
        content = fetchGreekPage(url)
        v1 = '/webtv/'
        if re.search('/webtv/',url) is None: v1 = '/'
        match = re.search("addPrototypeElement[(]'.+?','REST','(.+?)','(.+?)'.+?[)]", content)
        v2,v3 = match.groups()
        aspUrl = '%s%s%s?%s' % (megatv_url, v1, v2, v3)
        aspUrl = aspUrl.replace('/../','/')

        content = fetchGreekPage(aspUrl)
        shows_data = common.parseDOM(content, "ul")[0]
        shows_data = shows_data.replace('<li><a href="classics.asp?catid=29241">','')
        shows = common.parseDOM(shows_data, "li", attrs = { "class": "lichild" })
        if not shows:
            shows = common.parseDOM(shows_data, "li")
        total = len(shows)
    except:
        return
    for show in shows:
        try:
            name = common.parseDOM(show, "a")[-1]
            name = common.replaceHTMLCodes(name)
            name = GreekCharacters(name,'restore')
            name = name.encode('utf-8')
            url = common.parseDOM(show, "a", ret="href")[0]
            url = url.split("catid=")[-1].replace("')",'')
            url = '%s&catidlocal=%s' % (catUrl, url)
            url = url.encode('utf-8')
            imgName = common.parseDOM(show, "a")[-1]
            image = get_megatv_shows_image(imgName,content,url)
            image = image.encode('utf-8')
            shows_list.append({'name': name, 'url': url, 'image': image})
        except:
            total = total - 1
            pass

    return shows_list

def get_megatv_shows_image(imgName,content,url):
    imgName = GreekCharacters(imgName,'upper')
    matches = common.parseDOM(content, "div", attrs = { "class": "thumbboxna" })
    for match in matches:
        try:
            imgMatch = common.parseDOM(match, "h3")[0]
            imgMatch = common.parseDOM(imgMatch, "a")[0]
        except:
            pass
        if imgMatch.upper() == imgName.upper():
            image = common.parseDOM(match, "img", ret="src")[0]
            return image
    image = cache(get_episodes,'',url,'','image')
    #image = get_episodes('',url,'','image')
    return image

def get_youtube_shows(mode=None):
    global shows_list
    shows_list = []

    name = "�� ������� ��� ��� �����������"
    url = "http://gdata.youtube.com/feeds/api/playlists/PL_AVbb8Ku5p_W1HvcGBwqrpu4V0yLWaiM"
    image = showsPath+"To Mystiko tou Arh Bonsalenth.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "� ������� �����"
    url = "http://gdata.youtube.com/feeds/api/playlists/PL_AVbb8Ku5p__ZWtD_ndwilaL42SbaIWR"
    image = showsPath+"O Megalos Thymos.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "��������"
    url = "http://gdata.youtube.com/feeds/api/playlists/PL_AVbb8Ku5p8hPEAM0aktNzJWv81QglYi"
    image = showsPath+"Gynaikes.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�� ������� ��� ������"
    url = "http://gdata.youtube.com/feeds/api/playlists/PL_AVbb8Ku5p-gZJ7JB5DohpxzvR49YxwW"
    image = showsPath+"Oi Frouroi ths Axaias.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�� ��� ���"
    url = "http://gdata.youtube.com/feeds/api/playlists/PL_AVbb8Ku5p8kptojbJk8-CG1QCCIh4Zi"
    image = showsPath+"To Soi mas.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�� ��� ����������"
    url = "http://gdata.youtube.com/feeds/api/playlists/PL_AVbb8Ku5p9Nx8WZvRAte35iZMBzB_DG"
    image = showsPath+"To Dis Eksamartein.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�����������������"
    url = "http://gdata.youtube.com/feeds/api/playlists/PL_AVbb8Ku5p8gylbmBqLTS9nyVaoQ2u7Z"
    image = showsPath+"Savvatogennhmenes.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "���������"
    url = "http://gdata.youtube.com/feeds/api/playlists/PL_AVbb8Ku5p9ihHKQOVMqZphKSkDlfSlz"
    image = showsPath+"Anastasia.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�' ����� �' ������"
    url = "http://gdata.youtube.com/feeds/api/playlists/PL_AVbb8Ku5p_V94Pqpqk1zpbjWCT91_FM"
    image = showsPath+"S' agapw m' agapas.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "��� �����"
    url = "http://gdata.youtube.com/feeds/api/playlists/PLC80C6EC45E7EF5E5"
    image = showsPath+"Dyo Ksenoi.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�� �����������"
    url = "http://gdata.youtube.com/feeds/api/playlists/PLAE53AE96DCCE5ECF"
    image = showsPath+"Oi Aparadektoi.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�� ����� �������"
    url = "http://gdata.youtube.com/feeds/api/playlists/PL185CA46FEEC787FA"
    image = showsPath+"Oi Treis Xarites.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "����� ������"
    url = "http://gdata.youtube.com/feeds/api/playlists/PL8ED49878FDBAF824"
    image = showsPath+"Ekmek Pagwto.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "������� ����"
    url = "http://gdata.youtube.com/feeds/api/playlists/PLF81DF1E323462913"
    image = showsPath+"Ntoltse Vita.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�� ������"
    url = "http://gdata.youtube.com/feeds/api/playlists/PL88E488596CB36FD7"
    image = showsPath+"To Retire.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�� ����������"
    url = "http://gdata.youtube.com/feeds/api/playlists/PL50622153AB9EDE3A"
    image = showsPath+"Oi Afthairetoi.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�������� ��� ���"
    url = "http://www.cinegreece.com/2013/01/1992_24.html"
    image = showsPath+"Mpelades gia Dyo.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�� ���� ���� ��� ������ ���"
    url = "http://www.cinegreece.com/2013/01/1991_1408.html"
    image = showsPath+"Ta Efta Kaka ths Moiras mou.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "��� �� ���� ��� ������ ���"
    url = "http://www.cinegreece.com/2013/01/1994.html"
    image = showsPath+"Ola ta Kaka ths Moiras mou.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "� ����� ��� �����"
    url = "http://www.cinegreece.com/2013/02/1991.html"
    image = showsPath+"H Agaph ths Gatas.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "���������"
    url = "http://www.cinegreece.com/2013/02/1996.html"
    image = showsPath+"Palirroia.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "��� �����"
    url = "http://www.cinegreece.com/2013/02/1994_6773.html"
    image = showsPath+"Lav Sorry.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�� ������� �������"
    url = "http://www.cinegreece.com/2013/02/1994_2540.html"
    image = showsPath+"To Kokkino Feggari.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "����� �� �����"
    url = "http://www.cinegreece.com/2013/02/1994_9.html"
    image = showsPath+"Emeis ki Emeis.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "���� ������"
    url = "http://www.cinegreece.com/2013/02/1996_13.html"
    image = showsPath+"Enas Erwtas.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "��������"
    url = "http://www.cinegreece.com/2013/02/1995_17.html"
    image = showsPath+"Skorpios.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "��������"
    url = "http://www.cinegreece.com/2013/02/1996_20.html"
    image = showsPath+"Prodosia.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "��������"
    url = "http://www.cinegreece.com/2013/02/1997_21.html"
    image = showsPath+"Tzivaeri.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "������� ���� ����"
    url = "http://www.cinegreece.com/2013/02/1997_585.html"
    image = showsPath+"Eimaste ston Aera.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "������"
    url = "http://www.cinegreece.com/2013/02/1992_24.html"
    image = showsPath+"Afrika.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "� ����� �������"
    url = "http://www.cinegreece.com/2013/02/1997_5196.html"
    image = showsPath+"O Kakos Vezyrhs.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�� ������������"
    url = "http://www.cinegreece.com/2013/03/1992.html"
    image = showsPath+"Oi Mikromesaioi.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�� �������������"
    url = "http://www.cinegreece.com/2013/03/1996.html"
    image = showsPath+"Oi Epaggelmaties.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�� ���������� �������"
    url = "http://www.cinegreece.com/2013/03/1991_4.html"
    image = showsPath+"Oi Teleftaioi Eggonoi.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "� ������� ��� ������"
    url = "http://www.cinegreece.com/2013/03/1998_8.html"
    image = showsPath+"H Aithousa tou Thronou.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "���� �����������"
    url = "http://www.cinegreece.com/2013/03/1998_13.html"
    image = showsPath+"Vios Anthospartos.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "��������"
    url = "http://www.cinegreece.com/2013/03/1999.html"
    image = showsPath+"Ventetta.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "� ��� ��� ��� �����"
    url = "http://www.cinegreece.com/2013/03/1998_6742.html"
    image = showsPath+"H Zwh pou den Ezhsa.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�� ������ ��� �����"
    url = "http://www.cinegreece.com/2013/03/1998_16.html"
    image = showsPath+"To Shmadi tou Erwta.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "� ��� ��� ��� �����"
    url = "http://www.cinegreece.com/2013/03/1999_6154.html"
    image = showsPath+"H Zwh mas mia Volta.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "��� ���� ��� �������"
    url = "http://www.cinegreece.com/2013/03/1999_18.html"
    image = showsPath+"Sth Skia tou Polemou.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "���� ����"
    url = "http://www.cinegreece.com/2013/03/1999_9297.html"
    image = showsPath+"Kris Kros.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "���� ������ �� ���� �����"
    url = "http://www.cinegreece.com/2013/03/1999_9593.html"
    image = showsPath+"Kati Trexei me tous Dipla.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "��� ����"
    url = "http://www.cinegreece.com/2013/03/1998_20.html"
    image = showsPath+"Gia Sena.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�� ��� �������"
    url = "http://www.cinegreece.com/2013/03/1999_20.html"
    image = showsPath+"Me Dyo Mamades.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "� ��� ��� ������"
    url = "http://www.cinegreece.com/2013/03/1996_27.html"
    image = showsPath+"O Ios tou Patera.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "����� ����� ���������"
    url = "http://www.cinegreece.com/2013/03/1990_25.html"
    image = showsPath+"Fonos Xwris Taftothta.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "����"
    url = "http://www.cinegreece.com/2013/03/1995.html"
    image = showsPath+"Apwn.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "������"
    url = "http://www.cinegreece.com/2013/03/1999_28.html"
    image = showsPath+"Fygame.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "��� �� ������"
    url = "http://www.cinegreece.com/2013/03/2000_28.html"
    image = showsPath+"Pes to Psemata.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "������� ������"
    url = "http://www.cinegreece.com/2013/03/2000_31.html"
    image = showsPath+"Aerines Siwpes.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "���� ������ ������"
    url = "http://www.cinegreece.com/2013/04/1992.html"
    image = showsPath+"Deka Mikroi Mhtsoi.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�� ��������� �����"
    url = "http://www.cinegreece.com/2013/04/1994.html"
    image = showsPath+"To Teleftaio Antio.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "���� �����"
    url = "http://www.cinegreece.com/2013/04/1996_5.html"
    image = showsPath+"Logw Timhs.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "���� ����� ���� ���"
    url = "http://www.cinegreece.com/2013/04/1993.html"
    image = showsPath+"Mana einai Mono Mia.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�� ���� ��� ������"
    url = "http://www.cinegreece.com/2013/04/1997_9.html"
    image = showsPath+"To Kare ths Damas.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "������ ������"
    url = "http://www.cinegreece.com/2013/04/1997_9924.html"
    image = showsPath+"Froyta Epoxhs.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "��������� �������"
    url = "http://www.cinegreece.com/2013/04/1996_11.html"
    image = showsPath+"Asynhtheis Ypoptoi.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})


    name = "4"
    url = "http://greek-movies.com/series.php?s=233"
    image = showsPath+"4.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "Big Bang"
    url = "http://greek-movies.com/series.php?s=88"
    image = showsPath+"Big Bang.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "L.A.P.D."
    url = "http://greek-movies.com/series.php?s=155"
    image = showsPath+"L.A.P.D..jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�� �������� �� ������ ���"
    url = "http://greek-movies.com/series.php?s=496"
    image = showsPath+"An Thymhtheis to Oneiro mou.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�� ��� �������"
    url = "http://greek-movies.com/series.php?s=440"
    image = showsPath+"Gh kai Ouranos.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "��� ����� ����"
    url = "http://greek-movies.com/series.php?s=35"
    image = showsPath+"Dyo Meres Mono.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "����� �� ����� ���"
    url = "http://greek-movies.com/series.php?s=25"
    image = showsPath+"Eisai to Tairi mou.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "����� �����"
    url = "http://greek-movies.com/series.php?s=511"
    image = showsPath+"Enoxh Agaph.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "������� ������� ���������"
    url = "http://greek-movies.com/series.php?s=33"
    image = showsPath+"Erasths Dytikwn Proastiwn.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "��� �����"
    url = "http://greek-movies.com/series.php?s=613"
    image = showsPath+"Esy Ftais.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "���� �������"
    url = "http://greek-movies.com/series.php?s=327"
    image = showsPath+"Etsi Ksafnika.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "������������ ����"
    url = "http://greek-movies.com/series.php?s=91"
    image = showsPath+"Eftyxismenoi Mazi.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "� ����� ��� 592 ����"
    url = "http://greek-movies.com/series.php?s=343"
    image = showsPath+"H Genia twn 592 Evrw.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "� ������"
    url = "http://greek-movies.com/series.php?s=127"
    image = showsPath+"H Danta.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "� ������������"
    url = "http://greek-movies.com/series.php?s=156"
    image = showsPath+"H Polykatoikia.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "����"
    url = "http://greek-movies.com/series.php?s=95"
    image = showsPath+"Ixnh.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "������ �� �����"
    url = "http://greek-movies.com/series.php?s=27"
    image = showsPath+"Kleise ta Matia.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�������� ������"
    url = "http://greek-movies.com/series.php?s=471"
    image = showsPath+"Klemmena Oneira.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "������� ���������"
    url = "http://greek-movies.com/series.php?s=430"
    image = showsPath+"Klinikh Periptwsh.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�������"
    url = "http://greek-movies.com/series.php?s=346"
    image = showsPath+"Koykles.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "����"
    url = "http://greek-movies.com/series.php?s=508"
    image = showsPath+"Lenh.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "���� ���"
    url = "http://greek-movies.com/series.php?s=50"
    image = showsPath+"Mazi sou.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "����� � ������"
    url = "http://greek-movies.com/series.php?s=51"
    image = showsPath+"Maria h Asxhmh.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "����� ���������"
    url = "http://greek-movies.com/series.php?s=107"
    image = showsPath+"Mayra Mesanyxta.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�� ��� ��� ������"
    url = "http://greek-movies.com/series.php?s=131"
    image = showsPath+"Me Thea sto Pelago.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�� ���� �������"
    url = "http://greek-movies.com/series.php?s=429"
    image = showsPath+"Me Lene Vaggelh.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�� �� ���������� ����"
    url = "http://greek-movies.com/series.php?s=614"
    image = showsPath+"Me ta Pantelonia Katw.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "� 3�� �����"
    url = "http://greek-movies.com/series.php?s=302"
    image = showsPath+"O 3os Nomos.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "� ������ ��� �� �������� ���"
    url = "http://greek-movies.com/series.php?s=182"
    image = showsPath+"O Petros kai ta Koritsia tou.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�� ����������"
    url = "http://greek-movies.com/series.php?s=474"
    image = showsPath+"Oi Vasiliades.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�� �������� ��� �������"
    url = "http://greek-movies.com/series.php?s=37"
    image = showsPath+"Oi Magisses ths Smyrnhs.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "��� �� ������ ���� ��� �� �������"
    url = "http://greek-movies.com/series.php?s=347"
    image = showsPath+"Ouk an Lavois Para tou mh Exontos.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "������� ����"
    url = "http://greek-movies.com/series.php?s=260"
    image = showsPath+"Paidikh Xara.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "������� �������"
    url = "http://greek-movies.com/series.php?s=38"
    image = showsPath+"Penhnta Penhnta.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "���� ������ ��� ������"
    url = "http://greek-movies.com/series.php?s=143"
    image = showsPath+"Peri Anemwn kai Ydatwn.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "���� ��� �����"
    url = "http://greek-movies.com/series.php?s=428"
    image = showsPath+"Pisw sto Spiti.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "����� ��� ������"
    url = "http://greek-movies.com/series.php?s=159"
    image = showsPath+"Poios mas Pianei.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "��� ���� �����"
    url = "http://greek-movies.com/series.php?s=39"
    image = showsPath+"Sto Para Pente.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "��� ��� ��� ���������"
    url = "http://greek-movies.com/series.php?s=519"
    image = showsPath+"Sto Fws tou Feggarioy.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�� ���� �� ���������� ����"
    url = "http://greek-movies.com/series.php?s=24"
    image = showsPath+"Ti Psyxh tha Paradwseis Mwrh.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�� ������� �������"
    url = "http://greek-movies.com/series.php?s=41"
    image = showsPath+"To Kokkino Dwmatio.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�� ����"
    url = "http://greek-movies.com/series.php?s=342"
    image = showsPath+"To Nhsi.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    name = "�����"
    url = "http://greek-movies.com/series.php?s=283"
    image = showsPath+"Feyga.jpg"
    name = GreekCharacters(name,'complete').encode('utf-8')
    shows_list.append({'name': name, 'url': url, 'image': image})

    total = 0
    shows_list = sorted(shows_list, key=itemgetter('name'))
    if mode is not None: return shows_list
    for item in shows_list:
        name = item['name']
        url = item['url']
        image = item['image']
        total += 1
        add_shows(total,name,url,image)

    return shows_list

def fix_favourites():
    fix_list = []
    fix_list.append({'1': '', '2': ''})
    return fix_list

def get_youtube_shows_list(channel):
    try:
        shows = ""
        for i in range(1, 10000, 25):
            shows_url = '%s%s/playlists?max-results=25&start-index=%s' % (youtube_user, channel, str(i))
            result = common.fetchPage({"link": shows_url})
            shows += result["content"]
            next = 'start-index=%s' % str(i+25)
            if not next in result["content"]: break
        shows = common.parseDOM(shows, "entry")
        total = len(shows)
    except:
        return
    for show in shows:
        try:
            name = common.parseDOM(show, "title")[0]
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            image = common.parseDOM(show, "media:thumbnail", ret="url")[0]
            image = image.replace(image.split("/")[-1], '0.jpg')
            image = image.encode('utf-8')
            url = common.parseDOM(show, "id")[0]
            url = youtube_playlist + url.split("/")[-1]
            url = url.encode('utf-8')
            if image.endswith("/00000000000/0.jpg"): continue #empty playlist
            shows_list.append({'name': name, 'url': url, 'image': image, 'channel': channel})
        except:
            total = total - 1
            pass

    return shows_list

def add_shows(total,name,url,image):
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    sysimage = urllib.quote_plus(image)
    u = '%s?action=get_episodes&show=%s&url=%s&image=%s' % (sysbase, sysname, sysurl, sysimage)
    file = open(favData, 'r')
    read = file.read()
    file.close()
    cm = []
    cm.append((language(30401).encode("utf-8"), 'RunPlugin(%s?action=play_item)' % (sysbase)))
    cm.append((language(30402).encode("utf-8"), 'RunPlugin(%s?action=random_play_item)' % (sysbase)))
    cm.append((language(30404).encode("utf-8"), 'RunPlugin(%s?action=queue_item)' % (sysbase)))
    cm.append((language(30406).encode("utf-8"), 'RunPlugin(%s?action=play_queue)' % (sysbase)))
    cm.append((language(30407).encode("utf-8"), 'RunPlugin(%s?action=open_playlist)' % (sysbase)))
    if not url in read:
        cm.append((language(30413).encode("utf-8"), 'RunPlugin(%s?action=add_favourite_item&name=%s&url=%s)' % (sysbase, sysname, sysurl)))
    else:
        cm.append((language(30414).encode("utf-8"), 'RunPlugin(%s?action=delete_favourite_item&name=%s&url=%s)' % (sysbase, sysname, sysurl)))
    cm.append((language(30408).encode("utf-8"), 'RunPlugin(%s?action=xbmc_set_view)' % (sysbase)))
    #cm.append((language(30409).encode("utf-8"), 'RunPlugin(%s?action=open_settings)' % (sysbase)))
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=image)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    item.setProperty("Fanart_Image", fanart)
    item.addContextMenuItems(cm, replaceItems=True)
    xbmcplugin.addDirectoryItem(handle=handle,url=u,listitem=item,totalItems=total,isFolder=True)
    return

def get_episodes(show,url,image,mode=None):
    global episodes_list
    episodes_list = []

    if url.startswith(megatv_url):
        if mode is None:
            episodes_list = get_megatv_episodes(show,url)
        else:
            image = get_megatv_episodes(show,url,mode)
            return image

    if url.startswith(youtube_url):
        if mode is None:
            episodes_list = get_youtube_episodes(show,url)
        else:
            try:	image = [item['image'] for item in get_youtube_shows('image') if url == item['url']][0]
            except:	image = ""
            return image


    if url.startswith(cinegreece_url):
        if mode is None:
            episodes_list = get_cinegreece_episodes(show,url,image)
        else:
            try:	image = [item['image'] for item in get_youtube_shows('image') if url == item['url']][0]
            except:	image = ""
            return image

    if url.startswith(greek_movies_url):
        if mode is None:
            episodes_list = get_greek_movies_episodes(show,url,image)
        else:
            try:	image = [item['image'] for item in get_youtube_shows('image') if url == item['url']][0]
            except:	image = ""
            return image

    return episodes_list

def get_megatv_episodes(show,url,mode=None):
    try:
        content = fetchGreekPage(url)
        v1 = '/webtv/'
        if re.search('/webtv/',url) is None: v1 = '/'
        match = re.search("addPrototypeElement[(]'.+?','REST','(.+?)','(.+?)'.+?[)]", content)
        v2,v3 = match.groups()
        asp_url = '%s%s%s?%s' % (megatv_url, v1, v2, v3)
        asp_url = asp_url.replace('/../','/')

        if mode is None:
            episodes = ""
            for i in range(1, 11):
                episodes += fetchGreekPage('%s&page1=%s&page2=%s' % (asp_url, str(i), str(i)))
        else:
            episodes = fetchGreekPage(asp_url)

        episodes = common.parseDOM(episodes, "div", attrs = { "class": "thumbboxna" })
        episodes = unique_list(episodes)
        total = len(episodes)
    except:
        return

    for episode in episodes:
        try:
            image = common.parseDOM(episode, "img", ret="src")[0]
            image = common.replaceHTMLCodes(image)
            image = image.encode('utf-8')
            if mode == 'image': return image

            try:
                name = common.parseDOM(episode, "h3")[0]
                name = common.parseDOM(name, "a")[0]
            except:
                pass
            name = common.replaceHTMLCodes(name)
            name = GreekCharacters(name,'restore')
            name = name.encode('utf-8')

            url = common.parseDOM(episode, "a", ret="href")[0]
            if url.startswith('JAVASCRIPT') or url.startswith('default.asp'):
                url = url.split("catid=")[-1].replace("')",'')
                url = '%s/r.asp?catid=%s' % (megatv_url, url)
            url = url.encode('utf-8')

            episodes_list.append({'name': name, 'show': show, 'url': url, 'image': image})
            add_episodes(total,name,show,url,image)
        except:
            total = total - 1
            pass

    return episodes_list

def get_cinegreece_episodes(show,url,image):
    try:
        result = common.fetchPage({"link": url})
        episodes = re.compile('(<button.+?a="a".+?</button>)').findall(result["content"])
        episodes = unique_list(episodes)
        total = len(episodes)
    except:
        return
    for episode in episodes:
        try:
            name = common.parseDOM(episode, "button")[0]
            name = u'\u0395'u'\u03C0'u'\u03B5'u'\u03B9'u'\u03C3'u'\u03CC'u'\u03B4'u'\u03B9'u'\u03BF' + ' ' + name
            name = name.replace('&nbsp;&nbsp;&nbsp;','-')
            name = name.encode('utf-8')
            url = common.parseDOM(episode, "button", ret="onclick")[0]
            url = re.compile("'(.+?)'").findall(url)[0]
            url = url.split("&amp;")[0].split("/")[-1].split("=")[-1]
            url = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % url
            url = url.encode('utf-8')
            episodes_list.append({'name': name, 'show': show, 'url': url, 'image': image})
            add_episodes(total,name,show,url,image)
        except:
            total = total - 1
            pass

    return episodes_list

def get_greek_movies_episodes(show,url,image):
    try:
        result = common.fetchPage({"link": url})
        episodes = common.parseDOM(result["content"], "div", attrs = { "class": "episodemenu_new" })
        episodes = unique_list(episodes)
        total = len(episodes)
    except:
        return
    for episode in episodes:
        try:
            name = re.compile('<b>(.+?)</b>').findall(episode)[0]
            name = common.replaceHTMLCodes(name)
            name = u'\u0395'u'\u03C0'u'\u03B5'u'\u03B9'u'\u03C3'u'\u03CC'u'\u03B4'u'\u03B9'u'\u03BF' + ' ' + name
            name = name.encode('utf-8')
            url = ""
            popup = common.parseDOM(episode, "div", attrs = { "class": "episodepopup_new" })[0]
            for link in common.parseDOM(popup, "a", ret="href"):
                url += '%s/%s,' % (greek_movies_url, link)
            url = url[:-1]
            url = url.encode('utf-8')
            episodes_list.append({'name': name, 'show': show, 'url': url, 'image': image})
        except:
            total = total - 1
            pass
    reversed_list = []
    for i in reversed(episodes_list): reversed_list.append(i)
    for item in reversed_list:
        name = item['name']
        url = item['url']
        image = item['image']
        add_episodes(total,name,show,url,image)

    return episodes_list

def get_youtube_episodes(show,url,mode=None):
    try:
        episodes = ""
        if not "?" in url: url += "?"
        if url.startswith(youtube_playlist):
            for i in range(1, 10000, 25):
                episodes_url = '%s&max-results=25&start-index=%s' % (url, str(i))
                result = common.fetchPage({"link": episodes_url})
                episodes += result["content"]
                next = 'start-index=%s' % str(i+25)
                if not next in result["content"]: break
            episodes = common.parseDOM(episodes, "entry")
            total = len(episodes)

        if url.startswith(youtube_user):
            for i in range(1, 100, 25):
                episodes_url = '%s&max-results=25&start-index=%s' % (url, str(i))
                result = common.fetchPage({"link": episodes_url})
                episodes += result["content"]
            episodes = common.parseDOM(episodes, "entry")
            total = len(episodes)

        if url.startswith(youtube_search):
            params = url.split("?")[-1]
            params = dict(arg.split("=") for arg in params.split("&"))
            query = params["q"]
            query2 = urllib.quote_plus(query).encode('utf-8').replace('%','').replace('+','')
            url = url.replace(query, urllib.quote_plus(query))
            for i in range(1, 10000, 25):
                episodes_url = '%s&max-results=25&start-index=%s' % (url, str(i))
                result = common.fetchPage({"link": episodes_url})
                episodes += result["content"]
                try:
                    match = common.parseDOM(result["content"], "entry")[-1]
                    match = common.parseDOM(match, "title")[0]
                    match = urllib.quote_plus(match.encode('utf-8')).replace('%','').replace('+','')
                    if not query2 in match: break
                except:
                    break
            filter_list = common.parseDOM(episodes, "entry")
            episodes = []
            for filter in filter_list:
                match = common.parseDOM(filter, "title")[0]
                match = urllib.quote_plus(match.encode('utf-8')).replace('%','').replace('+','')
                if query2 in match:
                    episodes.append(filter)
            total = len(episodes)
    except:
        return

    for episode in episodes:
        try:
            name = common.parseDOM(episode, "title")[0]
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            image = common.parseDOM(episode, "media:thumbnail", ret="url")[0]
            image = image.replace(image.split("/")[-1], '0.jpg')
            image = image.encode('utf-8')
            if mode == 'image': return image
            url = common.parseDOM(episode, "media:player", ret="url")[0]
            url = re.compile('v=(.+?)&amp').findall(url)[0]
            url = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % url
            url = url.encode('utf-8')
            episodes_list.append({'name': name, 'show': show, 'url': url, 'image': image})
            add_episodes(total,name,show,url,image)
        except:
            total = total - 1
            pass

    return episodes_list

def get_news():
    episodes_list = get_episodes('MEGA TV','http://www.megatv.com/webtv/default.asp?catid=24616&catidlocal=24616','')
    return episodes_list

def get_sports():
    episodes_list = get_episodes('MEGA TV','http://www.megatv.com/webtv/default.asp?catid=24616&catidlocal=30200','')
    return episodes_list

def add_episodes(total,name,show,url,image,mode=None):
    sysurl = urllib.quote_plus(url)
    u = '%s?action=play_video&url=%s' % (sysbase, sysurl)
    cm = []
    cm.append((language(30405).encode("utf-8"), 'RunPlugin(%s?action=queue_item)' % (sysbase)))
    cm.append((language(30403).encode("utf-8"), 'RunPlugin(%s?action=play_from_here_item&url=%s)' % (sysbase, sysurl)))
    cm.append((language(30406).encode("utf-8"), 'RunPlugin(%s?action=play_queue)' % (sysbase)))
    cm.append((language(30407).encode("utf-8"), 'RunPlugin(%s?action=open_playlist)' % (sysbase)))
    cm.append((language(30408).encode("utf-8"), 'RunPlugin(%s?action=xbmc_set_view)' % (sysbase)))
    #cm.append((language(30409).encode("utf-8"), 'RunPlugin(%s?action=open_settings)' % (sysbase)))
    item = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=image)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": show, "Plot": description } )
    item.setProperty("IsPlayable", "true")
    item.setProperty( "Video", "true" )
    item.setProperty("Fanart_Image", fanart)
    if mode == 'playlist':
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.add(u, item)
    else:
        item.addContextMenuItems(cm, replaceItems=True)
        xbmcplugin.addDirectoryItem(handle=handle,url=u,listitem=item,totalItems=total)
    return

def play_video(url):
    if url.startswith('plugin://plugin.video.youtube/'):
        try:
            if check_addon('plugin.video.youtube') is None:
                xbmcgui.Dialog().ok(addonname, language(30351).encode("utf-8"), language(30352).encode("utf-8"))
            else:
                item = xbmcgui.ListItem(path=url)
                xbmcplugin.setResolvedUrl(handle, True, item)
                return url
        except:
            return

    if url.startswith(greek_movies_url):
        page_list = []
        x_list = [str(x) for x in url.split(',')]
        x_list2 = []
        for x in x_list:
            result = common.fetchPage({"link": x})
            x = common.parseDOM(result["content"], "button", ret="OnClick")[0]
            x = re.compile("'(.+?)'").findall(x)[0]
            x_list2.append(x)
        page_list += [x for x in x_list2 if "http://www.youtube.com" in x]
        page_list += [x for x in x_list2 if "http://www.putlocker.com" in x]
        page_list += [x for x in x_list2 if "http://www.datemule.com" in x]
        page_list += [x for x in x_list2 if "http://www.dailymotion.com" in x]
        page_list += [x for x in x_list2 if "http://www.veoh.com" in x]
        page_list += [x for x in x_list2 if "http://vimeo.com" in x]
        url = None

        for pageUrl in page_list:
            try:
                if pageUrl.startswith('http://www.youtube.com'):
                    result = common.fetchPage({"link": pageUrl})
                    try:
                        error = common.parseDOM(result[u"content"], "h1", attrs = { "id": "unavailable-message" })[0]
                    except:
                        error = None
                    try:
                        alert = common.parseDOM(result[u"content"], "div", attrs = { "id": "watch7-notification-area" })[0]
                    except:
                        alert = None
                    if result["status"] == 200 and error is None and alert is None:
                        url = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % pageUrl.split("=")[-1]
                        if check_addon('plugin.video.youtube') is None:
                            xbmcgui.Dialog().ok(addonname, language(30351).encode("utf-8"), language(30352).encode("utf-8"))
                        else:
                            item = xbmcgui.ListItem(path=url)
                            xbmcplugin.setResolvedUrl(handle, True, item)
                        return url
            except:
                pass

            try:
                if pageUrl.startswith('http://www.putlocker.com'):
                    result = common.fetchPage({"link": pageUrl})
                    hash = re.compile('value="(.+?)".+?name="hash"').findall(result[u"content"])[0]
                    post_data = {'hash': hash, 'confirm': 'Continue as Free User'}
                    result = common.fetchPage({"link": pageUrl, "post_data": post_data})
                    url = re.compile('href="(.+?)".+?class="download_file_link"').findall(result[u"content"])[0]
                    url = "http://putlocker.com%s" % url
                    item = xbmcgui.ListItem(path=url)
                    xbmcplugin.setResolvedUrl(handle, True, item)
                    return url
            except:
                pass

            try:
                if pageUrl.startswith('http://www.datemule.com'):
                    result = common.fetchPage({"link": pageUrl})
                    url = common.parseDOM(result[u"content"], "A", ret="onclick")[0]
                    url = re.compile("'(.+?)'").findall(url)[0]
                    url = url.split("title=")[0]
                    result = common.fetchPage({"link": url})
                    url = re.compile('href="(.+?)"').findall(result[u"content"])[0]
                    item = xbmcgui.ListItem(path=url)
                    xbmcplugin.setResolvedUrl(handle, True, item)
                    return url
            except:
                pass

            try:
                if pageUrl.startswith('http://www.dailymotion.com'):
                    result = common.fetchPage({"link": pageUrl})
                    sequence = re.compile('"sequence":"(.+?)"').findall(result[u"content"])[0]
                    sequence = urllib.unquote_plus(sequence).replace('\/', '/')
                    try:
                        url = re.compile('"hqURL":"(.+?)"').findall(sequence)[0]
                    except:
                        url = re.compile('"sdURL":"(.+?)"').findall(sequence)[0]
                    item = xbmcgui.ListItem(path=url)
                    xbmcplugin.setResolvedUrl(handle, True, item)
                    return url
            except:
                pass

            try:
                if pageUrl.startswith('http://www.veoh.com') or pageUrl.startswith('http://vimeo.com'):
                    flashUrl = 'http://www.flashvideodownloader.org/download.php?u=%s' % pageUrl
                    result = common.fetchPage({"link": flashUrl})
                    url = common.parseDOM(result[u"content"], "div", attrs = { "class": "mod_download" })[0]
                    url = common.parseDOM(url, "a", ret="href")[0]
                    item = xbmcgui.ListItem(path=url)
                    xbmcplugin.setResolvedUrl(handle, True, item)
                    return url
            except:
                pass

        item = xbmcgui.ListItem(path=url)
        xbmcplugin.setResolvedUrl(handle, True, item)
        return url

    if url.startswith(megatv_url):
        try:
            url = url.split("catid=")[-1]
            url = 'http://www.megatv.com/XML/jw/videolists.asp?catid=%s&attributes=0&nostore=true' % url
            result = common.fetchPage({"link": url})

            playpath = common.parseDOM(result[u"content"], "location")[-1]
            try:
                rtmp = common.parseDOM(result[u"content"], "meta", attrs = { "rel": "streamer" })[0]
            except:
                rtmp = ""

            if playpath.endswith("/manifest.f4m"):
                rtmp = 'rtmp://cp78455.edgefcs.net/ondemand/vod/'
                try:
                    playpath = re.compile('.+?,.+?,(.+?),.csmil/manifest.f4m').findall(playpath)[0]
                except:
                    playpath = re.compile('.+?,(.+?),.csmil/manifest.f4m').findall(playpath)[0]

            url = '%s%s timeout=10' % (rtmp, playpath)
            if not url.startswith('rtmp://'):
                url = '%s%s' % (rtmp, playpath)

            item = xbmcgui.ListItem(path=url)
            xbmcplugin.setResolvedUrl(handle, True, item)
            return url
        except:
            return

main()