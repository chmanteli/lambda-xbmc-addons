# -*- coding: utf-8 -*-

'''
    mega replay XBMC Addon
    Copyright (C) 2012 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib,urllib2,re,os,xbmcplugin,xbmcgui,xbmcaddon

settings = xbmcaddon.Addon(id='plugin.video.megatv.com')
data = 'special://profile/addon_data/plugin.video.megatv.com'

home = settings.getAddonInfo('path')
language = settings.getLocalizedString
addonname = settings.getAddonInfo("name")
description = language(30509).encode("utf-8")
icon = xbmc.translatePath(os.path.join(home,'icon.png'))
artPath = xbmc.translatePath(os.path.join(home,'resources/art/'))
fanart = xbmc.translatePath(os.path.join(home,'fanart.jpg'))
favPath = xbmc.translatePath(os.path.join(data,'favourites.cfg'))
dataPath = xbmc.translatePath(data)
skin = xbmc.getSkinDir()

xbmcplugin.setContent(int(sys.argv[1]), 'Episodes')
xbmcplugin.setPluginFanart(int(sys.argv[1]), fanart)

try:
    import StorageServer
    cache = StorageServer.StorageServer(addonname,720)
except:
    import storageserverdummy as StorageServer
    cache = StorageServer.StorageServer(addonname,720)

try:
    import CommonFunctions
    common = CommonFunctions
except:
    import commonfunctionsdummy as CommonFunctions
    common = CommonFunctions



base_url = 'http://www.megatv.com'
shows_url = 'http://www.megatv.com/webtv/default.asp?'

classics_base_url = 'http://www.megatv.com/classics.asp?catid=17556&subid=1'
classics_url = 'http://www.megatv.com/r.asp?catid=%s'

youtube_base_url = 'http://www.youtube.com'
youtube_url = 'http://www.youtube.com/user/Megatvweb/videos?view=1'


entitydefs = {
    '�':	'\u0386', # greek capital letter alpha with acute, U+0386'
    '�':	'\u0388', # greek capital letter epsilon with acute, U+0388'
    '�':	'\u0389', # greek capital letter eta with acute, U+0389'
    '�':	'\u038A', # greek capital letter iota with acute, U+A'
    '�':	'\u038C', # greek capital letter omicron with acute, U+038C'
    '�':	'\u038E', # greek capital letter upsilon with acute, U+038E'
    '�':	'\u038F', # greek capital letter omega with acute, U+038F'
    '�':	'\u0390', # greek small letter iota with acute and diaeresis, U+0390'
    '�':	'\u0391', # greek capital letter alpha, U+0391'
    '�':	'\u0392', # greek capital letter beta, U+0392'
    '�':	'\u0393', # greek capital letter gamma, U+0393'
    '�':	'\u0394', # greek capital letter delta, U+0394'
    '�':	'\u0395', # greek capital letter epsilon, U+0395'
    '�':	'\u0396', # greek capital letter zeta, U+0396'
    '�':	'\u0397', # greek capital letter eta, U+0397'
    '�':	'\u0398', # greek capital letter theta, U+0398'
    '�':	'\u0399', # greek capital letter iota, U+0399'
    '�':	'\u039A', # greek capital letter kappa, U+039A'
    '�':	'\u039B', # greek capital letter lambda, U+039B'
    '�':	'\u039C', # greek capital letter mu, U+039C'
    '�':	'\u039D', # greek capital letter nu, U+039D'
    '�':	'\u039E', # greek capital letter chi, U+039E'
    '�':	'\u039F', # greek capital letter omicron, U+039F'
    '�':	'\u03A0', # greek capital letter pi, U+03A0'
    '�':	'\u03A1', # greek capital letter rho, U+03A1'
    '�':	'\u03A3', # greek capital letter sigma, U+03A3'
    '�':	'\u03A4', # greek capital letter tau, U+03A4'
    '�':	'\u03A5', # greek capital letter upsilon, U+03A5'
    '�':	'\u03A6', # greek capital letter phi, U+03A6'
    '�':	'\u03A7', # greek capital letter xi, U+03A7'
    '�':	'\u03A8', # greek capital letter psi, U+03A8'
    '�':	'\u03A9', # greek capital letter omega, U+03A9'
    '�':	'\u03AA', # greek capital letter iota with diaeresis, U+03AA'
    '�':	'\u03AB', # greek capital letter upsilon with diaeresis, U+03AB'
    '�':	'\u03AC', # greek small letter alpha with acute, U+03AC'
    '�':	'\u03AD', # greek small letter epsilon with acute, U+03AD'
    '�':	'\u03AE', # greek small letter eta with acute, U+03AE'
    '�':	'\u03AF', # greek small letter iota with acute, U+03AF'
    '�':	'\u03B0', # greek small letter upsilon with acute and diaeresis, U+03B0'
    '�':	'\u03B1', # greek small letter alpha, U+03B1'
    '�':	'\u03B2', # greek small letter beta, U+03B2'
    '�':	'\u03B3', # greek small letter gamma, U+03B3'
    '�':	'\u03B4', # greek small letter delta, U+03B4'
    '�':	'\u03B5', # greek small letter epsilon, U+03B5'
    '�':	'\u03B6', # greek small letter zeta, U+03B6'
    '�':	'\u03B7', # greek small letter eta, U+03B7'
    '�':	'\u03B8', # greek small letter theta, U+03B8'
    '�':	'\u03B9', # greek small letter iota, U+03B9'
    '�':	'\u03BA', # greek small letter kappa, U+03BA'
    '�':	'\u03BB', # greek small letter lambda, U+03BB'
    '�':	'\u03BC', # greek small letter mu, U+03BC'
    '�':	'\u03BD', # greek small letter nu, U+03BD'
    '�':	'\u03BE', # greek small letter chi, U+03BE'
    '�':	'\u03BF', # greek small letter omicron, U+03BF'
    '�':	'\u03C0', # greek small letter pi, U+03C0'
    '�':	'\u03C1', # greek small letter rho, U+03C1'
    '�':	'\u03C2', # greek small letter final sigma, U+03C2'
    '�':	'\u03C3', # greek small letter sigma, U+03C3'
    '�':	'\u03C4', # greek small letter tau, U+03C4'
    '�':	'\u03C5', # greek small letter upsilon, U+03C5'
    '�':	'\u03C6', # greek small letter phi, U+03C6'
    '�':	'\u03C7', # greek small letter xi, U+03C7'
    '�':	'\u03C8', # greek small letter psi, U+03C8'
    '�':	'\u03C9', # greek small letter omega, U+03C9'
    '�':	'\u03CA', # greek small letter iota with diaeresis, U+03CA'
    '�':	'\u03CB', # greek small letter upsilon with diaeresis, U+03CB'
    '�':	'\u03CC', # greek small letter omicron with acute, U+03CC'
    '�':	'\u03CD', # greek small letter upsilon with acute, U+03CD'
    '�':	'\u03CE', # greek small letter omega with acute, U+03CE'
}

entitydefs2 = {
    '\u0386':	u'\u0386', # greek capital letter alpha with acute, U+0386'
    '\u0388':	u'\u0388', # greek capital letter epsilon with acute, U+0388'
    '\u0389':	u'\u0389', # greek capital letter eta with acute, U+0389'
    '\u038A':	u'\u038A', # greek capital letter iota with acute, U+A'
    '\u038C':	u'\u038C', # greek capital letter omicron with acute, U+038C'
    '\u038E':	u'\u038E', # greek capital letter upsilon with acute, U+038E'
    '\u038F':	u'\u038F', # greek capital letter omega with acute, U+038F'
    '\u0390':	u'\u0390', # greek small letter iota with acute and diaeresis, U+0390'
    '\u0391':	u'\u0391', # greek capital letter alpha, U+0391'
    '\u0392':	u'\u0392', # greek capital letter beta, U+0392'
    '\u0393':	u'\u0393', # greek capital letter gamma, U+0393'
    '\u0394':	u'\u0394', # greek capital letter delta, U+0394'
    '\u0395':	u'\u0395', # greek capital letter epsilon, U+0395'
    '\u0396':	u'\u0396', # greek capital letter zeta, U+0396'
    '\u0397':	u'\u0397', # greek capital letter eta, U+0397'
    '\u0398':	u'\u0398', # greek capital letter theta, U+0398'
    '\u0399':	u'\u0399', # greek capital letter iota, U+0399'
    '\u039A':	u'\u039A', # greek capital letter kappa, U+039A'
    '\u039B':	u'\u039B', # greek capital letter lambda, U+039B'
    '\u039C':	u'\u039C', # greek capital letter mu, U+039C'
    '\u039D':	u'\u039D', # greek capital letter nu, U+039D'
    '\u039E':	u'\u039E', # greek capital letter chi, U+039E'
    '\u039F':	u'\u039F', # greek capital letter omicron, U+039F'
    '\u03A0':	u'\u03A0', # greek capital letter pi, U+03A0'
    '\u03A1':	u'\u03A1', # greek capital letter rho, U+03A1'
    '\u03A3':	u'\u03A3', # greek capital letter sigma, U+03A3'
    '\u03A4':	u'\u03A4', # greek capital letter tau, U+03A4'
    '\u03A5':	u'\u03A5', # greek capital letter upsilon, U+03A5'
    '\u03A6':	u'\u03A6', # greek capital letter phi, U+03A6'
    '\u03A7':	u'\u03A7', # greek capital letter xi, U+03A7'
    '\u03A8':	u'\u03A8', # greek capital letter psi, U+03A8'
    '\u03A9':	u'\u03A9', # greek capital letter omega, U+03A9'
    '\u03AA':	u'\u03AA', # greek capital letter iota with diaeresis, U+03AA'
    '\u03AB':	u'\u03AB', # greek capital letter upsilon with diaeresis, U+03AB'
    '\u03AC':	u'\u03AC', # greek small letter alpha with acute, U+03AC'
    '\u03AD':	u'\u03AD', # greek small letter epsilon with acute, U+03AD'
    '\u03AE':	u'\u03AE', # greek small letter eta with acute, U+03AE'
    '\u03AF':	u'\u03AF', # greek small letter iota with acute, U+03AF'
    '\u03B0':	u'\u03B0', # greek small letter upsilon with acute and diaeresis, U+03B0'
    '\u03B1':	u'\u03B1', # greek small letter alpha, U+03B1'
    '\u03B2':	u'\u03B2', # greek small letter beta, U+03B2'
    '\u03B3':	u'\u03B3', # greek small letter gamma, U+03B3'
    '\u03B4':	u'\u03B4', # greek small letter delta, U+03B4'
    '\u03B5':	u'\u03B5', # greek small letter epsilon, U+03B5'
    '\u03B6':	u'\u03B6', # greek small letter zeta, U+03B6'
    '\u03B7':	u'\u03B7', # greek small letter eta, U+03B7'
    '\u03B8':	u'\u03B8', # greek small letter theta, U+03B8'
    '\u03B9':	u'\u03B9', # greek small letter iota, U+03B9'
    '\u03BA':	u'\u03BA', # greek small letter kappa, U+03BA'
    '\u03BB':	u'\u03BB', # greek small letter lambda, U+03BB'
    '\u03BC':	u'\u03BC', # greek small letter mu, U+03BC'
    '\u03BD':	u'\u03BD', # greek small letter nu, U+03BD'
    '\u03BE':	u'\u03BE', # greek small letter chi, U+03BE'
    '\u03BF':	u'\u03BF', # greek small letter omicron, U+03BF'
    '\u03C0':	u'\u03C0', # greek small letter pi, U+03C0'
    '\u03C1':	u'\u03C1', # greek small letter rho, U+03C1'
    '\u03C2':	u'\u03C2', # greek small letter final sigma, U+03C2'
    '\u03C3':	u'\u03C3', # greek small letter sigma, U+03C3'
    '\u03C4':	u'\u03C4', # greek small letter tau, U+03C4'
    '\u03C5':	u'\u03C5', # greek small letter upsilon, U+03C5'
    '\u03C6':	u'\u03C6', # greek small letter phi, U+03C6'
    '\u03C7':	u'\u03C7', # greek small letter xi, U+03C7'
    '\u03C8':	u'\u03C8', # greek small letter psi, U+03C8'
    '\u03C9':	u'\u03C9', # greek small letter omega, U+03C9'
    '\u03CA':	u'\u03CA', # greek small letter iota with diaeresis, U+03CA'
    '\u03CB':	u'\u03CB', # greek small letter upsilon with diaeresis, U+03CB'
    '\u03CC':	u'\u03CC', # greek small letter omicron with acute, U+03CC'
    '\u03CD':	u'\u03CD', # greek small letter upsilon with acute, U+03CD'
    '\u03CE':	u'\u03CE', # greek small letter omega with acute, U+03CE'
}

def fetchGreekPage(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    link = replaceGreekChars(link)
    link = unicode(link, errors='ignore')
    link = link.encode('utf-8')
    return link

def replaceGreekChars(data):
    for name, value in entitydefs.iteritems():
        data = data.replace(name, value)
    return data

def restoreGreekChars(data):
    for name, value in entitydefs2.iteritems():
        data = data.replace(name, value)
    return data


def check_addon(id):
    try:
        check_addon = xbmcaddon.Addon(id=id).getAddonInfo("name")
        if not check_addon == addonname:
            return check_addon
        else:
            return
    except:
        return

def xbmc_notify(type):
    if type == 'favadd':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30201).encode("utf-8")))
    elif type == 'favrem':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30202).encode("utf-8")))
    elif type == 'favup':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30203).encode("utf-8")))
    elif type == 'favdown':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30204).encode("utf-8")))

def xbmc_refresh():
    xbmc.executebuiltin("Container.Refresh")

def xbmc_view():
    viewenable = settings.getSetting("viewenable")

    if (skin == 'skin.confluence' or skin == 'skin.confluence.svn') and viewenable == 'true':
        confluence_views = [50,51,500,504,503,515]
        view = int(settings.getSetting("confluence"))
        xbmc.executebuiltin("Container.SetViewMode("+str(confluence_views[view])+")")

    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn') and viewenable == 'true':
        rapier_views = [50,52,74,73,68,94]
        view = int(settings.getSetting("rapier"))
        xbmc.executebuiltin("Container.SetViewMode("+str(rapier_views[view])+")")

def xbmc_data():
    if not os.path.exists(dataPath):
        os.makedirs(dataPath)
    if not os.path.isfile(favPath):
        read = open(favPath, 'w')
        read.write('')
        read.close()

def add_favourite_item(name,url):
    xbmc_refresh()
    read = open(favPath, 'a+')
    read.write('"'+name+'"|"'+url+'"\n')
    read.close()
    xbmc_notify('favadd')

def delete_favourite_item(name,url):
    xbmc_refresh()
    read = open(favPath, 'r')
    text = read.read().replace('"'+name+'"|"'+url+'"','')
    read.close()
    read = open(favPath, 'w')
    for line in re.compile('"(.+?)\n').findall(text):
        read.write('"'+line+'\n')
    read.close()
    xbmc_notify('favrem')

def move_favourite_item(name,url,type):
    xbmc_refresh()
    replaced = []
    j = []
    i = 0
    f = open(favPath,'r')
    for line in f:
        if re.search('"'+url.replace('?','[?]')+'"',line) is not None:
            j = i
        i = i+1
    f.close()
    if type == 'favup':
        i = 1
    if type == 'favdown':
        i = -1
    f = open(favPath,'r')
    for line in f:
        if i == j:
            replaced = line
        i = i+1
    f.close()

    if not replaced == []:
        read = open(favPath, 'r')
        text = read.read()
        if type == 'favup':
            text = text.replace(replaced+'"'+name+'"|"'+url+'"','"'+name+'"|"'+url+'"'+replaced)
            text = text.replace('\n','')
        if type == 'favdown':
            text = text.replace('"'+name+'"|"'+url+'"\n'+replaced,replaced+'"'+name+'"|"'+url+'"')
            text = text.replace('\n','')
        read.close()
        read = open(favPath, 'w')
        for name,cid in re.compile('"(.+?)"[|]"(.+?)"').findall(text):
            read.write('"'+name+'"|"'+cid+'"\n')
        if type == 'favup':
            xbmc_notify('favup')
        if type == 'favdown':
            xbmc_notify('favdown')
	    read.close()

def get_favourites():
    xbmc_data()
    read = open(favPath, 'r')
    text = read.read()
    read.close()
    list = re.compile('"(.+?)"[|]"(.+?)"').findall(text)
    total = len(list)
    for name,url in list:
        iconimage = cache.cacheFunction(get_episodes, name,url,'iconimage')
        #iconimage = get_episodes(name,url,'iconimage')
        add_favourites(total,name,url,700,iconimage)
    xbmc_view()

def add_favourites(total,name,url,mode,iconimage):
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    contextMenuItems = []
    contextMenuItems.append((xbmc.getLocalizedString(13332), 'XBMC.RunPlugin(%s?mode=102&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    contextMenuItems.append((xbmc.getLocalizedString(13333), 'XBMC.RunPlugin(%s?mode=103&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    contextMenuItems.append((xbmc.getLocalizedString(1210), 'XBMC.RunPlugin(%s?mode=101&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    u = '%s?mode=%s&show=%s&url=%s' % (sys.argv[0], str(mode), sysname, sysurl)
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        item.setProperty( "Fanart_Image", iconimage )
    else: item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)

def get_categories():
    xbmc_data()
    total = 5
    add_categories(total,language(30501).encode("utf-8"),base_url,200,'0',artPath+'favorites.png')
    add_categories(total,language(30502).encode("utf-8"),base_url,300,'0',artPath+'archive.png')
    add_categories(total,language(30503).encode("utf-8"),base_url,400,'0',artPath+'latest.png')
    add_categories(total,language(30504).encode("utf-8"),base_url,500,'1',artPath+'news.png')
    add_categories(total,language(30505).encode("utf-8"),base_url,500,'2',artPath+'sports.png')
    xbmc_view()
    return

def get_cat_shows():
    xbmc_data()
    total = 3
    add_categories(total,language(30506).encode("utf-8"),base_url,600,'1',artPath+'series.png')
    add_categories(total,language(30507).encode("utf-8"),base_url,600,'2',artPath+'shows.png')
    add_categories(total,language(30508).encode("utf-8"),base_url,600,'3',artPath+'info.png')
    xbmc_view()
    return

def add_categories(total,name,url,mode,type,iconimage):
    sysname = urllib.quote_plus(name)
    systype = urllib.quote_plus(type)
    sysurl = urllib.quote_plus(url)
    contextMenuItems = []
    u = '%s?mode=%s&type=%s&url=%s' % (sys.argv[0], str(mode), systype, sysurl)
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        item.setProperty( "Fanart_Image", iconimage )
    else: item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)

def get_cat_episodes(type):
    xbmc_data()
    try:
        if type == '1':
            get_episodes(language(30504).encode("utf-8"),'http://www.megatv.com/megagegonota/r.asp?catid=27377')
        if type == '2':
            get_episodes(language(30505).encode("utf-8"),'http://www.megatv.com/megagegonota/r.asp?catid=27387')
    except:
        return
    return

def get_classics():
    xbmc_data()
    try:
        shows = fetchGreekPage(classics_base_url)
        shows = common.parseDOM(shows, "ul", attrs = { "class": "pin" })[0]
        shows = common.parseDOM(shows, "li")
        total = len(shows)
    except:
        total = 0
        pass
    try:
        result = common.fetchPage({"link": youtube_url})
        youtubes = common.parseDOM(result["content"], "li", attrs = { "class": "channels-content-item" })
        total = total + len(youtubes)
    except:
        if total == 0 : return
        pass
    for show in shows:
        try:
            name = common.parseDOM(show, "a")[-1]
            name = common.replaceHTMLCodes(name)
            name = restoreGreekChars(name)
            name = name.encode('utf-8')
            url = common.parseDOM(show, "a", ret="href")[0]
            url = re.compile('.+?catid%3D(.+?)&.+?').findall(url)[0]
            url = classics_url % url
            url = common.replaceHTMLCodes(url)
            url = url.encode('utf-8')
            iconimage = common.parseDOM(show, "img", ret="src")[0]
            iconimage = common.replaceHTMLCodes(iconimage)
            iconimage = iconimage_fixer(iconimage)
            iconimage = iconimage.encode('utf-8')
            add_shows(total,name,url,700,iconimage)
        except:
            total = total - 1
            pass
    for youtube in youtubes:
        try:
            name = common.parseDOM(youtube, "a", attrs = { "class": "content-item-title" })[0]
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            iconimage = common.parseDOM(youtube, "img", ret="data-thumb")[0]
            iconimage = re.compile('.+?/vi/(.+?)/.+?').findall(iconimage)[0]
            iconimage = 'http://i.ytimg.com/vi/%s/0.jpg' % iconimage
            iconimage = iconimage.encode('utf-8')
            url = common.parseDOM(youtube, "a", attrs = { "class": "content-item-title" }, ret = "href")[0]
            url = youtube_base_url + url
            url = url.encode('utf-8')
            add_shows(total,name,url,700,iconimage)
        except:
            total = total - 1
            pass
    xbmc_view()
    return

def get_shows(type):
    xbmc_data()
    try:
        shows = fetchGreekPage(shows_url)
        shows = common.parseDOM(shows, "div", attrs = { "class": "catlbottom" })[0]
        shows = common.parseDOM(shows, "ul")
        # Series
        if type == '1': shows = shows[0]
        # Shows
        if type == '2': shows = shows[1]
        # �nfo
        if type == '3': shows = shows[2]
        shows = common.parseDOM(shows, "li")
        total = len(shows)
    except:
        xbmc_view()
        return
    for show in shows:
        try:
            name = common.parseDOM(show, "a")[0]
            name = common.replaceHTMLCodes(name)
            name = restoreGreekChars(name)
            name = name.encode('utf-8')
            url = common.parseDOM(show, "a", ret="href")[0]
            url = common.replaceHTMLCodes(url)
            url = url.encode('utf-8')
            iconimage = cache.cacheFunction(get_episodes, name,url,'iconimage')
            #iconimage = get_episodes(name,url,'iconimage')
            add_shows(total,name,url,700,iconimage)
        except:
            total = total - 1
            pass
    xbmc_view()
    return

def add_shows(total,name,url,mode,iconimage):
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    read = open(favPath, 'r')
    text = read.read()
    read.close()
    contextMenuItems = []
    if not url in text: contextMenuItems.append((xbmc.getLocalizedString(14076), 'XBMC.RunPlugin(%s?mode=100&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    else: contextMenuItems.append((xbmc.getLocalizedString(14077), 'XBMC.RunPlugin(%s?mode=101&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    u = '%s?mode=%s&show=%s&url=%s' % (sys.argv[0], str(mode), sysname, sysurl)
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        item.setProperty( "Fanart_Image", iconimage )
    else: item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total,isFolder=True)

def get_episodes(show,url,type=None):
    xbmc_data()
    s = ['megatvgegonotarest','ajaxblock','entavcboxcont','classrestvid','restcatlay','WebTvStripe1Tabd','onlinep']

    if url.startswith(youtube_base_url):
        if type is None:
            get_youtube_episodes(show,url)
        else:
            iconimage = get_youtube_episodes(show,url,type)
            return iconimage
        xbmc_view()
        return

    try:
        episodes_url = fetchGreekPage(url)
    except:
        xbmc_view()
        return

    try:
        for v1,v2,v3,v4 in re.compile("addPrototypeElement[(]'(.+?)','(.+?)','(.+?)','(.+?)'").findall(episodes_url):
            if (re.search(s[0],v3) or re.search(s[1],v3) or re.search(s[2],v3) or re.search(s[3],v3) or re.search(s[4],v3) or re.search(s[5],v3) or re.search(s[6],v3)) is not None:
                break
            else:
                v3 = ''
        if v3 == '':
            xbmc_view()
            return
    except:
        pass

    try:
        episodes_base = url.split("r.asp?catid=")[0]
        episodes_url = '%s%s?%s&page1=999&ajaxid=%s&ajaxgroup=%s' % (episodes_base, v3, v4, v1, v2)
    except:
        xbmc_view()
        return

    try:
        if re.search(s[5],v3) is None:
            episodes = fetchGreekPage(episodes_url)
        else:
            episodes = ''
            for i in range(1, 11):
                episodes += fetchGreekPage(episodes_url.replace('page1=999','page1='+str(i)))
    except:
        xbmc_view()
        return

    try:
        episodes_data = re.compile('(<div class="vthumb".+?</td>)').findall(episodes)
        episodes_data += re.compile('(<li style="background.+?</li>)').findall(episodes)
        episodes_data += re.compile('(<li><a href="JAVASCRIPT.+?</li>)').findall(episodes)
        total = len(episodes_data)
        episodes = episodes_data
    except:
        xbmc_view()
        return

    for episode in episodes:
        try:
            try:
                name = common.parseDOM(episode, "a")[-1]
            except:
                pass
            try:
                if re.search('class="summ"',episode) is not None:
                    name = common.parseDOM(episode, "a")[1]
            except:
                pass
            try:
                name = re.compile('<h1>.+?</h1><h2>(.+?)</h2>').findall(episode)[0]
            except:
                pass
            name = common.replaceHTMLCodes(name)
            name = name_cleaner(name)
            name = restoreGreekChars(name)
            name = name.encode('utf-8')

            url = common.parseDOM(episode, "a", ret="href")[0]
            if re.search("'.+?'",url) is not None:
                url = re.compile("'(.+?)'").findall(url)[-1]
            if url.startswith('default.asp?'):
                url = url.split("default.asp?")[1]
            url = common.replaceHTMLCodes(url)
            url = shows_url + url
            url = url.encode('utf-8')

            try:
                iconimage = common.parseDOM(episode, "img", ret="src")[0]
            except:
                pass
            try:
                iconimage = common.parseDOM(episode, "div", ret="style")[0]
            except:
                pass
            try:
                iconimage = common.parseDOM(episode, "li", ret="style")[0]
            except:
                pass
            iconimage = common.replaceHTMLCodes(iconimage)
            if re.search("[(].+?[)]",iconimage) is not None:
                iconimage = re.compile("[(](.+?)[)]").findall(iconimage)[-1]
            iconimage = iconimage_fixer(iconimage)
            iconimage = iconimage.encode('utf-8')
            if type == 'iconimage': return iconimage

            add_episodes(total,name,show,url,iconimage)
        except:
            total = total - 1
            pass
    xbmc_view()
    return

def get_youtube_episodes(show,url,type=None):
    try:
        result = common.fetchPage({"link": url})
        episodes = common.parseDOM(result["content"], "li", attrs = { "class": "playlist-video-item.+?" })
        total = len(episodes)
    except:
        return
    for episode in episodes:
        try:
            name = common.parseDOM(episode, "span", attrs = { "class": "title video-title.+?" })[0]
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            videoid = common.parseDOM(episode, "button", ret="data-video-ids")[0]
            iconimage = 'http://i.ytimg.com/vi/%s/0.jpg' % videoid
            iconimage = iconimage.encode('utf-8')
            if type == 'iconimage': return iconimage
            url = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % videoid
            url = url.encode('utf-8')
            add_episodes(total,name,show,url,iconimage)
        except:
            total = total - 1
            pass
    return

def add_episodes(total,name,show,url,iconimage):
    mode = 900
    sysurl = urllib.quote_plus(url)
    u = '%s?mode=%s&url=%s' % (sys.argv[0], str(mode), sysurl)
    contextMenuItems = []
    item = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": show, "Plot": description } )
    item.setProperty("IsPlayable", "true")
    item.setProperty( "Video", "true" )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        item.setProperty( "Fanart_Image", iconimage )
    else: item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)	
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,totalItems=total)

def resolve_episodes(url):
    try:
        if url.startswith('plugin://plugin.video.youtube/') and check_addon('plugin.video.youtube') is None:
            xbmcgui.Dialog().ok(addonname, language(30211).encode("utf-8"), language(30212).encode("utf-8"))
            return
        if url.startswith('plugin://plugin.video.youtube/') and check_addon('plugin.video.youtube') is not None:
            item = xbmcgui.ListItem(path=url)
            return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)

        url = url.split("default.asp?")[1]
        url = 'http://www.megatv.com/XML/jw/videolists.asp?%s&attributes=0&mmgroup=&nostore=true' % url
        result = common.fetchPage({"link": url})
        try:
            rtmp = common.parseDOM(result["content"], "meta", attrs = { "rel": "streamer" })[0]
        except:
            rtmp = ''
            pass
        playpath = common.parseDOM(result["content"], "location")[-1]
        url = '%s%s' % (rtmp, playpath)
        if re.search('live',rtmp) is not None: url += ' live=true'
        if not rtmp.startswith('rtmp://'): url = playpath
        item = xbmcgui.ListItem(path=url)
        return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
    except:
        return

def name_cleaner(name):
    if re.search('.+?<br/>.+?<br/>.+?',name) is not None:
        name = re.compile('.+?<br/>(.+?)<br/>.+?').findall(name)[0]
    if re.search('-->',name) is not None:
        name = name.replace('--> ','').replace('-->','')
    return name

def iconimage_fixer(iconimage):
    if re.search('.+?engine[.]feed[.]gr.+?type=.+?',iconimage) is not None:
        iconimage = iconimage.split("type=")[0]
        iconimage = '%stype=7' % iconimage
    return iconimage


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?','')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


params = get_params()
url = None
name = None
show = None
type = None
mode = None
try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    show = urllib.unquote_plus(params["show"])
except:
    pass
try:
    type = urllib.unquote_plus(params["type"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass


if mode == None or url == None or len(url) < 1:
    get_categories()

elif mode == 100:
    add_favourite_item(name,url)

elif mode == 101:
    delete_favourite_item(name,url)

elif mode == 102:
    move_favourite_item(name,url,'favup')

elif mode == 103:
    move_favourite_item(name,url,'favdown')

elif mode == 200:
    get_favourites()

elif mode == 300:
    get_classics()

elif mode == 400:
    get_cat_shows()

elif mode == 500:
    get_cat_episodes(type)

elif mode == 600:
    get_shows(type)

elif mode == 700:
    get_episodes(show,url)

elif mode == 900:
    resolve_episodes(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))