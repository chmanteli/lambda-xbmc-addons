# -*- coding: cp1253 -*-

'''
    mega replay XBMC Addon
    Copyright (C) 2012 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib,urllib2,re,os,xbmcplugin,xbmcgui,xbmcaddon

settings = xbmcaddon.Addon(id='plugin.video.megatv.com')
data = 'special://profile/addon_data/plugin.video.megatv.com'

home = settings.getAddonInfo('path')
language = settings.getLocalizedString
addonname = settings.getAddonInfo("name")
description = language(30020).encode("utf-8")
icon = xbmc.translatePath(os.path.join(home,'icon.png'))
fanart = xbmc.translatePath(os.path.join(home,'fanart.jpg'))
artPath = xbmc.translatePath(os.path.join(home,'resources/art/'))
datapath = xbmc.translatePath(data)
skin = xbmc.getSkinDir()

xbmcplugin.setContent(int(sys.argv[1]), 'Episodes')
xbmcplugin.setPluginFanart(int(sys.argv[1]), fanart)

try:
    import StorageServer
    cache = StorageServer.StorageServer(addonname,240)
except:
    import storageserverdummy as StorageServer
    cache = StorageServer.StorageServer(addonname,240)
	
def xbmc_refresh():
    xbmc.executebuiltin("Container.Refresh")

def xbmc_view():
    viewenable = settings.getSetting("viewenable")

    if (skin == 'skin.confluence' or skin == 'skin.confluence-vertical' \
    or skin == 'skin.confluence.moviesets'):
        if viewenable == 'true':
            confluence_views = [50,51,500,503,504]
            view = int(settings.getSetting("confluence"))
            xbmc.executebuiltin("Container.SetViewMode("+str(confluence_views[view])+")")

    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        if viewenable == 'true':
            rapier_views = [50,52,74,73,68,94]
            view = int(settings.getSetting("rapier"))
            xbmc.executebuiltin("Container.SetViewMode("+str(rapier_views[view])+")")

def GetURL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    link = link.replace('\n','')
    return link

def ClearURL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    return link

def name_cleaner(name):
	name = name.replace('&lt;&lt;','�').replace('&gt;&gt','�').replace('&lt;','<') \
	.replace('&gt;','>').replace('&quot;','"').replace("''",'"').replace('&amp;','&')
	if re.search('.+?<br/>.+?<br/>.+?',name) is not None:
	    for name in re.compile('.+?<br/>(.+?)<br/>.+?').findall(name):
		    return name
	else: return name
	
def thumbnail_fixer(thumbnail):
	thumbnail = thumbnail.replace('type=11999','type=7')
	thumbnail = thumbnail.replace('type=12241','type=7')
	thumbnail = thumbnail.replace('type=12253','type=7')
	thumbnail = thumbnail.replace('type=12261','type=7')
	thumbnail = thumbnail.replace('type=12262','type=7')
	return thumbnail

shows_pattern_1 = '<div class="catlbottom">.+?<ul>(.+?)</ul>'
shows_pattern_2 = '<div class="catlbottom">.+?<ul>.+?</ul>.+?<ul>(.+?)</ul>'
shows_pattern_3 = '<div class="catlbottom">.+?<ul>.+?</ul>.+?<ul>.+?</ul>.+?<ul>(.+?)</ul>'
shows_pattern = '<a href="(.+?)">(.+?)</a></h1>'

classics_pattern_1 = '<div class="categoriesright">.+?<ul>(.+?)</ul>'
classics_pattern = '<a href="(.+?)">(.+?)</a></h1>'

news_pattern = '<li class="meganews">.+?<img src=.+?<a href="(.+?)">(.+?)</a>'

element_pattern_1 = '<div class="subelements".+?prototype_.+?_.+?">'+"<.+?addPrototypeElement[(]'(.+?)','(.+?)','(.+?)','(.+?)'[)]"
element_pattern_2 = '<div id="prototype_19183">'+"<.+?addPrototypeElement[(]'(.+?)','(.+?)','(.+?)','(.+?)'[)]" 
element_pattern_3 = '<div id="prototype_19811">'+"<.+?addPrototypeElement[(]'(.+?)','(.+?)','(.+?)','(.+?)'[)]" 
element_pattern_4 = '<div id="prototype_20150">'+"<.+?addPrototypeElement[(]'(.+?)','(.+?)','(.+?)','(.+?)'[)]"
element_pattern_5 = '<div id="prototype_12887">'+"<.+?addPrototypeElement[(]'(.+?)','(.+?)','(.+?)','(.+?)'[)]"
element_pattern_6 = '<div id="prototype_22663_1">'+"<.+?addPrototypeElement[(]'(.+?)','(.+?)','(.+?)','(.+?)'[)]"
element_pattern_7 = '<div id="prototype_22660">'+"<.+?addPrototypeElement[(]'(.+?)','(.+?)','(.+?)','(.+?)'[)]"
element_pattern_9 = '<div id="prototype_22671">'+"<.+?addPrototypeElement[(]'(.+?)','(.+?)','(.+?)','(.+?)'[)]"
element_pattern_8 = '<div id="prototype_15580">'+"<.+?addPrototypeElement[(]'(.+?)','(.+?)','(.+?)','(.+?)'[)]"

episodes_pattern_1 = "style.+?url[(](.+?)[)].+?','(.+?)'.+?img.+?[)]"+'"'+">(.+?)</a>"
episodes_pattern_2 = 'vthumb.+?url[(](.+?)[)].+?<h3>.+?"(.+?)".+?[)]">(.+?)</a>'
episodes_pattern_3 = 'vthumb.+?<img src="(.+?)".+?'+"','(.+?)'.+?>(.+?)</a></h1>"
episodes_pattern_4 = 'vthumb.+?<a href=.+?'+"['],['](.+?)[']"+'.+?><img src="(.+?)".+?/>.+?<h1>(.+?)</h1>'
episodes_pattern_5 = '<li><a href=".+?"><img src="(.+?)".+? /></a>.+?<a href="(.+?)">(.+?)</a>'

resolve_pattern_1 = '</album><location>(.+?)</location>.+?<meta rel="streamer">(.+?)</meta>'
resolve_pattern_2 = '</creator><location>(.+?)</location>.+?<meta rel="streamer">(.+?)</meta>'
resolve_pattern_3 = '</album><location>(.+?)</location>'

def get_categories():
    add_categories(language(30001).encode("utf-8"),101,artPath+'series.png')
    add_categories(language(30002).encode("utf-8"),102,artPath+'shows.png')
    add_categories(language(30003).encode("utf-8"),103,artPath+'classics.png')
    add_categories(language(30004).encode("utf-8"),104,artPath+'info.png')
    add_categories(language(30005).encode("utf-8"),105,artPath+'news.png')
    add_categories(language(30006).encode("utf-8"),106,artPath+'sports.png')
    xbmc_view()

def add_categories(name,mode,iconimage):
    contextMenuItems = []
    url = 'http://www.megatv.com'
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        liz.setProperty( "Fanart_Image", iconimage )
    else: liz.setProperty( "Fanart_Image", fanart )
    liz.addContextMenuItems(contextMenuItems, replaceItems=True)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def get_shows(pattern):
	link = GetURL('http://www.megatv.com/webtv/default.asp')
	for link in re.compile(pattern).findall(link):
		for url,name in re.compile(shows_pattern).findall(link):
			thumbnail = None
			url = url.replace('catid=24567','catid=24919') # Money Drop - fix
			try:
				thumbnail = cache.cacheFunction(get_episodes, url,'thumbnail')
				#thumbnail = get_episodes(url,'thumbnail')
			except:
			    pass
			if thumbnail is not None:
				add_shows(name,url,900,thumbnail)
	xbmc_view()

def get_classics():
	link = GetURL('http://www.megatv.com/webtv/default.asp')
	for link in re.compile(classics_pattern_1).findall(link):
		for url,name in re.compile(classics_pattern).findall(link):
			thumbnail = None
			try:
				thumbnail = cache.cacheFunction(get_episodes, url,'thumbnail')
				#thumbnail = get_episodes(url,'thumbnail')
			except:
			    pass
			if thumbnail is not None:
				add_shows(name,url,900,thumbnail)
	xbmc_view()

def add_shows(name,url,mode,iconimage):
    contextMenuItems = []
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        liz.setProperty( "Fanart_Image", iconimage )
    else: liz.setProperty( "Fanart_Image", fanart )
    liz.addContextMenuItems(contextMenuItems, replaceItems=True)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def get_news():
	url = 'http://www.megatv.com/megagegonota/r.asp'
	thumbnail = artPath+'news.png'
	link = GetURL(url)
	for url,name in re.compile(news_pattern).findall(link):
		url = url.replace('summary.asp','default.asp')
		add_episodes(name,url,thumbnail)
	url = 'http://www.megatv.com/megagegonota/r.asp?catid=17571'
	get_episodes(url,'episode')
	xbmc_view()

def get_sports():
	url = 'http://www.megatv.com/megagegonota/r.asp?catid=17639'
	get_episodes(url,'episode')
	xbmc_view()

def get_episodes(url,type):
	link = GetURL(url)
	element = []
	v4 = ''
	try:
		for v1,v2,v3,v4 in re.compile(element_pattern_1).findall(link):
			element = url.split("r.asp?catid=")[0]+v3+'?'+v4+'&page1=99&ajaxid='+v1+'&ajaxgroup='+v2
	except:
	    pass
	try:
		for v1,v2,v3,v4 in re.compile(element_pattern_2).findall(link):
			element = url.split("r.asp?catid=")[0]+v3+'?'+v4+'&page1=99&ajaxid='+v1+'&ajaxgroup='+v2
	except:
	    pass
	try:
		for v1,v2,v3,v4 in re.compile(element_pattern_3).findall(link):
			element = url.split("r.asp?catid=")[0]+v3+'?'+v4+'&page1=99&ajaxid='+v1+'&ajaxgroup='+v2
	except:
	    pass
	try:
		for v1,v2,v3,v4 in re.compile(element_pattern_4).findall(link):
			element = url.split("r.asp?catid=")[0]+v3+'?'+v4+'&page1=99&ajaxid='+v1+'&ajaxgroup='+v2
	except:
	    pass
	try:
		for v1,v2,v3,v4 in re.compile(element_pattern_5).findall(link):
			element = url.split("r.asp?catid=")[0]+v3+'?'+v4+'&page1=99&ajaxid='+v1+'&ajaxgroup='+v2
	except:
	    pass
	try:
		for v1,v2,v3,v4 in re.compile(element_pattern_6).findall(link):
			element = url.split("r.asp?catid=")[0]+v3+'?'+v4+'&page1=99&ajaxid='+v1+'&ajaxgroup='+v2
	except:
	    pass
	try:
		for v1,v2,v3,v4 in re.compile(element_pattern_7).findall(link):
			element = url.split("r.asp?catid=")[0]+v3+'?'+v4+'&page1=99&ajaxid='+v1+'&ajaxgroup='+v2
	except:
	    pass
	try:
		for v1,v2,v3,v4 in re.compile(element_pattern_8).findall(link):
			element = url.split("r.asp?catid=")[0]+v3+'?'+v4+'&page1=99&ajaxid='+v1+'&ajaxgroup='+v2
	except:
	    pass
	try:
		for v1,v2,v3,v4 in re.compile(element_pattern_9).findall(link):
			element = url.split("r.asp?catid=")[0]+v3+'?'+v4+'&page1=99&ajaxid='+v1+'&ajaxgroup='+v2
	except:
	    pass

	if (re.search("ajaxgroup=", v4) or v4 == ''): return		

	if type == 'thumbnail':	
		try:
			link = GetURL(element.replace('page1=99','page1=1'))
		except:
		    pass
	elif type == 'episode':	
		try:
			link = GetURL(element)
		except:
		    pass
		try:
			if not re.search("'"+v2+".", link):
				element = element.replace('page1=99','page1=1')
				link = ClearURL(element)
				link = link+ClearURL(element.replace('page1=1','page1=2'))
				link = link+ClearURL(element.replace('page1=1','page1=3'))
				link = link+ClearURL(element.replace('page1=1','page1=4'))
				link = link+ClearURL(element.replace('page1=1','page1=5'))
				link = link+ClearURL(element.replace('page1=1','page1=6'))
				link = link+ClearURL(element.replace('page1=1','page1=7'))
				link = link+ClearURL(element.replace('page1=1','page1=8'))
				link = link+ClearURL(element.replace('page1=1','page1=9'))
				link = link+ClearURL(element.replace('page1=1','page1=10'))
		except:
		    pass

	url = ''
	name = ''
	thumbnail = ''
	try:
		for thumbnail,url,name in re.compile(episodes_pattern_1).findall(link):
			thumbnail = thumbnail_fixer(thumbnail)
			url = url.replace('default.asp?','')
			if (url.startswith('catid') and 'pubid' in url):
				if type == 'thumbnail': return thumbnail
				elif type == 'episode':
					new_name = name_cleaner(name)
					new_url = 'http://www.megatv.com/webtv/default.asp?'+url
					add_episodes(new_name,new_url,thumbnail)
	except:
	    pass
	try:
		if not (url.startswith('catid') and 'pubid' in url):
			for thumbnail,url,name in re.compile(episodes_pattern_2).findall(link):
				thumbnail = thumbnail_fixer(thumbnail)
				url = url.replace('default.asp?','')
				if (url.startswith('catid') and 'pubid' in url):
					if type == 'thumbnail': return thumbnail
					elif type == 'episode':
						new_name = name_cleaner(name)
						new_url = 'http://www.megatv.com/webtv/default.asp?'+url
						add_episodes(new_name,new_url,thumbnail)
	except:
	    pass
	try:
		if not (url.startswith('catid') and 'pubid' in url):
			for thumbnail,url,name in re.compile(episodes_pattern_3).findall(link):
				thumbnail = thumbnail_fixer(thumbnail)
				url = url.replace('default.asp?','')
				if (url.startswith('catid') and 'pubid' in url):
					if type == 'thumbnail': return thumbnail
					elif type == 'episode':
						new_name = name_cleaner(name)
						new_url = 'http://www.megatv.com/webtv/default.asp?'+url
						add_episodes(new_name,new_url,thumbnail)
	except:
	    pass
	try:
		if not (url.startswith('catid') and 'pubid' in url):
			for url,thumbnail,name in re.compile(episodes_pattern_4).findall(link):
				thumbnail = thumbnail_fixer(thumbnail)
				url = url.replace('default.asp?','')
				if (url.startswith('catid') and 'pubid' in url):
					if type == 'thumbnail': return thumbnail
					elif type == 'episode':
						new_name = name_cleaner(name)
						new_url = 'http://www.megatv.com/webtv/default.asp?'+url
						add_episodes(new_name,new_url,thumbnail)
	except:
	    pass
	try:
		if not (url.startswith('catid') and 'pubid' in url):
			for thumbnail,url,name in re.compile(episodes_pattern_5).findall(link):
				thumbnail = thumbnail_fixer(thumbnail)
				url = url.replace('default.asp?','')
				if (url.startswith('catid') and 'pubid' in url):
					if type == 'thumbnail': return thumbnail
					elif type == 'episode':
						new_name = name_cleaner(name)
						new_url = 'http://www.megatv.com/webtv/default.asp?'+url
						add_episodes(new_name,new_url,thumbnail)
	except:
	    pass
	xbmc_view()

def add_episodes(name,url,iconimage):
    mode = 901
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok = True
    contextMenuItems = []
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
    liz.setProperty("IsPlayable", "true")
    liz.setProperty( "Video", "true" )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        liz.setProperty( "Fanart_Image", iconimage )
    else: liz.setProperty( "Fanart_Image", fanart )
    liz.addContextMenuItems(contextMenuItems, replaceItems=True)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
    return ok

def resolve_episodes(url):
	url = url.split("default.asp?")[1]
	url = 'http://www.megatv.com/XML/jw/videolists.asp?'+url+'&attributes=0&mmgroup=&nostore=true'
	link = GetURL(url)

	check=re.search('<meta rel="streamer">',link)
	if check is not None:
		for a,b in re.compile(resolve_pattern_1).findall(link): new_url=b+a
	else:
		for a in re.compile(resolve_pattern_3).findall(link): new_url=a

	check=re.search('</creator><location>',link)
	if check is not None:
		for a,b in re.compile(resolve_pattern_2).findall(link): new_url=b+a

	url=new_url
	item = xbmcgui.ListItem(path=url)
	return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)



def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?','')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


params = get_params()
url = None
name = None
mode = None
try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass


if mode == None or url == None or len(url) < 1:
    get_categories()
	
elif mode == 101:
    get_shows(shows_pattern_1)
	
elif mode == 102:
    get_shows(shows_pattern_2)
	
elif mode == 103:
    get_classics()
	
elif mode == 104:
    get_shows(shows_pattern_3)
	
elif mode == 105:
    get_news()
	
elif mode == 106:
    get_sports()

elif mode == 900:
    get_episodes(url,'episode')

elif mode == 901:
    resolve_episodes(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))