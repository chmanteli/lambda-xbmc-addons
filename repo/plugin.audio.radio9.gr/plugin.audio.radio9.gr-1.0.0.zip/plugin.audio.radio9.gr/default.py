# -*- coding: cp1253 -*-

'''
    radio9 podcast XBMC Addon
    Copyright (C) 2012 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib,urllib2,re,os,xbmcplugin,xbmcgui,xbmcaddon
import random


settings = xbmcaddon.Addon(id='plugin.audio.radio9.gr')
data = 'special://profile/addon_data/plugin.audio.radio9.gr'

home = settings.getAddonInfo('path')
language = settings.getLocalizedString
addonname = settings.getAddonInfo("name")
description = language(30002).encode("utf-8")
icon = xbmc.translatePath(os.path.join(home,'icon.png'))
fanart1 = xbmc.translatePath(os.path.join(home,'resources/fanart/1.jpg'))
fanart2 = xbmc.translatePath(os.path.join(home,'resources/fanart/2.jpg'))
logoPath = xbmc.translatePath(os.path.join(home,'resources/logos/'))
datapath = xbmc.translatePath(data)
skin = xbmc.getSkinDir()

try:
    import StorageServer
    cache = StorageServer.StorageServer(addonname,240)
except:
    import storageserverdummy as StorageServer
    cache = StorageServer.StorageServer(addonname,240)

xbmcplugin.setContent(int(sys.argv[1]), 'Songs')

base_url = 'http://www.radio9.gr/MediaList.aspx?a_id=1335'
shows_pattern_1 = '<option value="(.+?)">(.+?)</option>'
shows_pattern_2 = '<div class="playNow">.+?src='+"'(.+?)'"
podcasts_pattern_1 = 'repMediaItems_divMedia.+?href="(.+?)".+?src='+"'(.+?)'.+?<b>(.+?)</b>.+?>(.+?)</div>"
podcasts_pattern_2 = "flashplayer: '(.+?)'.+?streamer: '(.+?)'.+?file: '(.+?)'"


def GetURL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    link = link.replace('\n','')
    return link
	
def xbmc_view():
    viewenable = settings.getSetting("viewenable")

    if (skin == 'skin.confluence' or skin == 'skin.confluence-vertical' \
    or skin == 'skin.confluence.moviesets'):
        if viewenable == 'true':
            confluence_views = [50,51,500,506]
            view = int(settings.getSetting("confluence"))
            xbmc.executebuiltin("Container.SetViewMode("+str(confluence_views[view])+")")

    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        if viewenable == 'true':
            rapier_views = [50,63,52,77,62,67]
            view = int(settings.getSetting("rapier"))
            xbmc.executebuiltin("Container.SetViewMode("+str(rapier_views[view])+")")

def name_cleaner(name):
	name = name.replace('&lt;&lt;','�').replace('&gt;&gt','�').replace('&lt;','<') \
	.replace('&gt;','>').replace('&quot;','"').replace("''",'"').replace('&amp;','&')
	return name

def get_shows():
	add_shows(language(30001).encode("utf-8"),base_url,1,logoPath+'item.png')
	link = GetURL(base_url)
	for url,name in re.compile(shows_pattern_1).findall(link):
		url = 'http://www.radio9.gr/MediaList.aspx?a_id=1335&prodId='+url
		name = name_cleaner(name)
		try:
			thumbnail = cache.cacheFunction(get_shows_thumbnail, url)
			#thumbnail = get_shows_thumbnail(url)
			add_shows(name,url,1,thumbnail)
		except:
			pass
	xbmc_view()

def get_shows_thumbnail(url):
	for thumbnail in re.compile(shows_pattern_2).findall(GetURL(url)):
		thumbnail = 'http://www.radio9.gr/'+thumbnail
	return thumbnail

def add_shows(name,url,mode,iconimage):
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="music", infoLabels={ "Title": name, "Label": name, "Album": "Radio 9", "Comment": description } )
    liz.setProperty( "Album_Description", description )
    liz.setProperty( "Fanart_Image", random.choice([fanart1, fanart2]) )
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def get_podcasts(show):
	try:
		link = GetURL(show+'&p=1') + GetURL(show+'&p=2')
		for url,thumbnail,n1,n2 in re.compile(podcasts_pattern_1).findall(link):
			name = n1 + ' - ' + n2.replace('  ','')
			name = name_cleaner(name)
			thumbnail = 'http://www.radio9.gr/'+thumbnail
			url = 'http://www.radio9.gr/'+name_cleaner(url)
			add_podcasts(name,url,thumbnail)
	except:
	    pass
	xbmc_view()

def add_podcasts(name,url,iconimage):
    mode = 0
    u = sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="music", infoLabels={ "Title": name, "Label": name, "Album": "Radio 9", "Comment": description } )
    liz.setProperty("IsPlayable", "true")
    liz.setProperty( "music", "true" )
    liz.setProperty( "Album_Description", description )
    liz.setProperty( "Fanart_Image", random.choice([fanart1, fanart2]) )
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
    return ok	
	
def resolve_podcasts(url):
	try:
		pageUrl = url
		link = GetURL(url)
		for swfUrl,path,playpath in re.compile(podcasts_pattern_2).findall(link):
			swfUrl = 'http://www.radio9.gr/'+swfUrl
		#url = path+' playpath='+playpath+' pageUrl='+pageUrl+' swfUrl='+swfUrl+' swfVfy=true'
		url = path+' playpath='+playpath
	except:
	    pass
	item = xbmcgui.ListItem(path=url, iconImage=logoPath+'Radio 9.png', thumbnailImage=logoPath+'Radio 9.png')
	return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)



def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?','')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


params = get_params()
url = None
name = None
mode = None
try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass


if mode==None or url==None or len(url)<1:
    get_shows()
	
elif mode==0:
    resolve_podcasts(url)

elif mode==1:
    get_podcasts(url)
	

xbmcplugin.endOfDirectory(int(sys.argv[1]))
