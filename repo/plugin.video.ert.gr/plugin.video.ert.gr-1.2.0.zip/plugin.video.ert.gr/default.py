# -*- coding: utf-8 -*-

'''
    ert online XBMC Addon
    Copyright (C) 2013 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib,urllib2,re,os,xbmc,xbmcplugin,xbmcgui,xbmcaddon
from operator import itemgetter
try:
    import StorageServer
except:
    import storageserverdummy as StorageServer
try:
    import CommonFunctions
except:
    import commonfunctionsdummy as CommonFunctions


language = xbmcaddon.Addon().getLocalizedString
setSetting = xbmcaddon.Addon().setSetting
getSetting = xbmcaddon.Addon().getSetting
addonname = xbmcaddon.Addon().getAddonInfo("name")
addonVersion = xbmcaddon.Addon().getAddonInfo("version")
addonId = xbmcaddon.Addon().getAddonInfo("id")
addonPath = xbmcaddon.Addon().getAddonInfo('path')
addonIcon = xbmc.translatePath(os.path.join(addonPath,'icon.png'))
artPath = xbmc.translatePath(os.path.join(addonPath,'resources/art/'))
fanart = xbmc.translatePath(os.path.join(addonPath,'fanart.jpg'))
dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))
favData = xbmc.translatePath(os.path.join(dataPath,'favourites2.cfg'))
viewData = xbmc.translatePath(os.path.join(dataPath,'views.cfg'))
cacheFull = StorageServer.StorageServer(addonname+addonVersion,720).cacheFunction
cache = StorageServer.StorageServer(addonname+addonVersion,720).cacheFunction
description = language(30450).encode("utf-8")
common = CommonFunctions
sysbase = sys.argv[0]
handle = int(sys.argv[1])
paramString = sys.argv[2]
skin = xbmc.getSkinDir()

shows_list = []
episodes_list = []
ert_url = 'http://www.ert.gr'
ert_archives_url = 'http://www.ert-archives.gr'
cinegreece_url = 'http://www.cinegreece.com'

def main():
    xbmc_data()
    params = {}
    splitparams = paramString[paramString.find('?') + 1:].split('&')
    for param in splitparams:
        if (len(param) > 0):
            splitparam = param.split('=')
            key = splitparam[0]
            try: 
                value = splitparam[1].encode("utf-8")
            except:
                value = splitparam[1]
            params[key] = value

    try:		action = urllib.unquote_plus(params["action"])
    except:		action = None
    try:		name = urllib.unquote_plus(params["name"])
    except:		name = None
    try:		show = urllib.unquote_plus(params["show"])
    except:		show = None
    try:		url = urllib.unquote_plus(params["url"])
    except:		url = None
    try:		image = urllib.unquote_plus(params["image"])
    except:		image = None
    try:		mode = urllib.unquote_plus(params["mode"])
    except:		mode = None

    if action == None:							get_categories()
    elif action == 'play_item':					play_item()
    elif action == 'random_play_item':			random_play_item()
    elif action == 'queue_item':				queue_item()
    elif action == 'play_from_here_item':		play_from_here_item(url)
    elif action == 'add_favourite_item':		add_favourite_item(name,url)
    elif action == 'delete_favourite_item':		delete_favourite_item(name,url)
    elif action == 'move_favourite_item_up':	move_favourite_item_up(name,url)
    elif action == 'move_favourite_item_down':	move_favourite_item_down(name,url)
    elif action == 'play_queue':				play_queue()
    elif action == 'open_playlist':				open_playlist()
    elif action == 'xbmc_set_view':				xbmc_set_view()
    elif action == 'open_settings':				open_settings()
    elif action == 'get_favourites':			get_favourites()
    elif action == 'get_live':					get_live()
    elif action == 'get_ert_menus':				get_ert_menus()
    elif action == 'get_cinegreece_shows':		get_cinegreece_shows()
    elif action == 'get_news':					get_news()
    elif action == 'get_sports':				get_sports()
    elif action == 'get_ert_shows':				get_ert_shows(url)
    elif action == 'get_episodes':				get_episodes(show,url,image)
    elif action == 'play_video':				play_video(url)

    xbmcplugin.setContent(handle, 'Episodes')
    xbmcplugin.setPluginFanart(handle, fanart)
    xbmcplugin.endOfDirectory(handle)
    xbmc_view()
    return

def unique_list(list):
    unique_set = set()
    unique_list = []
    for n in list:
        if n not in unique_set:
            unique_set.add(n)
            unique_list.append(n)
    return unique_list

def get_url(url,fetch=True,mobile=False,proxy=None,referer=None,cookie=None):
    if not proxy is None:
        proxy_handler = urllib2.ProxyHandler({'http':'%s' % (proxy)})
        opener = urllib2.build_opener(proxy_handler, urllib2.HTTPHandler)
        opener = urllib2.install_opener(opener)
    request = urllib2.Request(url,None)
    if not cookie is None:
        from urllib2 import Request, build_opener, HTTPCookieProcessor, HTTPHandler
        import cookielib
        cj = cookielib.CookieJar()
        opener = build_opener(HTTPCookieProcessor(cj), HTTPHandler())
        cookiereq = Request(cookie)
        response = opener.open(cookiereq)
        response.close()
        for cookie in cj:
            cookie = '%s=%s' % (cookie.name, cookie.value)
        request.add_header('Cookie', cookie)
    if mobile == True:
        request.add_header('User-Agent', 'Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_0 like Mac OS X; en-us) AppleWebKit/532.9 (KHTML, like Gecko) Version/4.0.5 Mobile/8A293 Safari/6531.22.7')
    else:
        request.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0')
    if not referer is None:
        request.add_header('Referer', referer)
    response = urllib2.urlopen(request)
    if fetch == True:
        result = response.read()
    else:
        result = response.geturl()
    response.close()
    return result

def quote_url(url):
    url = urllib.quote_plus(url)
    url = url.replace("%3A", ":")
    url = url.replace("%2F", "/")
    url = url.replace("%3F", "?")
    url = url.replace("%26", "&")
    url = url.replace("%3D", "=")
    url = url.encode('utf-8')
    return url

def check_addon(id):
    check_addon = xbmcaddon.Addon(id=id).getAddonInfo("name")
    if not check_addon == addonname: return check_addon
    return

def xbmc_notify(mode):
    if mode == 'setview':
        viewName = xbmc.getInfoLabel('Container.Viewmode')
        xbmc.executebuiltin("Notification(%s,%s, 3000)" % (addonname, '%s%s%s') % (language(30301).encode("utf-8"), viewName, language(30302).encode("utf-8")))
    elif mode == 'favadd':
        xbmc.executebuiltin("Notification(%s,%s, 3000)" % (addonname, language(30303).encode("utf-8")))
    elif mode == 'favrem':
        xbmc.executebuiltin("Notification(%s,%s, 3000)" % (addonname, language(30304).encode("utf-8")))
    elif mode == 'favup':
        xbmc.executebuiltin("Notification(%s,%s, 3000)" % (addonname, language(30305).encode("utf-8")))
    elif mode == 'favdown':
        xbmc.executebuiltin("Notification(%s,%s, 3000)" % (addonname, language(30306).encode("utf-8")))

def xbmc_refresh():
    xbmc.executebuiltin('Container.Refresh')

def xbmc_data():
    if not os.path.exists(dataPath):
        os.makedirs(dataPath)
    if not os.path.isfile(favData):
        file = open(favData, 'w')
        file.write('')
        file.close()
    if not os.path.isfile(viewData):
        file = open(viewData, 'w')
        file.write('')
        file.close()

def xbmc_view():
    try:
        file = open(viewData,'r')
        read = file.read().replace('\n','')
        file.close()
        view = re.compile('"%s"[|]"(.+?)"' % (skin)).findall(read)[0]
        xbmc.executebuiltin('Container.SetViewMode(%s)' % str(view))
    except:
        if (skin == 'skin.confluence'):			xbmc.executebuiltin('Container.SetViewMode(503)')
        if (skin == 'skin.ace'):				xbmc.executebuiltin('Container.SetViewMode(59)')
        if (skin == 'skin.aeon.nox'):			xbmc.executebuiltin('Container.SetViewMode(518)')
        if (skin == 'skin.back-row'):			xbmc.executebuiltin('Container.SetViewMode(529)')
        if (skin == 'skin.carmichael'):			xbmc.executebuiltin('Container.SetViewMode(50)')
        if (skin == 'skin.diffuse'):			xbmc.executebuiltin('Container.SetViewMode(55)')
        if (skin == 'skin.metropolis'):			xbmc.executebuiltin('Container.SetViewMode(55)')
        if (skin == 'skin.pm3-hd'):				xbmc.executebuiltin('Container.SetViewMode(58)')
        if (skin == 'skin.transparency'):		xbmc.executebuiltin('Container.SetViewMode(51)')
        if (skin == 'skin.xeebo'):				xbmc.executebuiltin('Container.SetViewMode(50)')
        if (skin == 'skin.xperience-more'):		xbmc.executebuiltin('Container.SetViewMode(50)')
        if (skin == 'skin.fusion.migma.v3'):	xbmc.executebuiltin('Container.SetViewMode(504)')
        if (skin == 'skin.bello'):				xbmc.executebuiltin('Container.SetViewMode(50)')
        if (skin == 'skin.cirrus.extended.v3'):	xbmc.executebuiltin('Container.SetViewMode(55)')
        if (skin == 'skin.neon'):				xbmc.executebuiltin('Container.SetViewMode(53)')
        if (skin == 'skin.quartz'):				xbmc.executebuiltin('Container.SetViewMode(52)')
        if (skin == 'skin.quartz.reloaded'):	xbmc.executebuiltin('Container.SetViewMode(52)')
        if (skin == 'skin.rapier'):				xbmc.executebuiltin('Container.SetViewMode(68)')
        if (skin == 'skin.re-touched'):			xbmc.executebuiltin('Container.SetViewMode(550)')
        if (skin == 'skin.refocus'):			xbmc.executebuiltin('Container.SetViewMode(50)')
        if (skin == 'skin.simplicity.frodo'):	xbmc.executebuiltin('Container.SetViewMode(50)')
        if (skin == 'skin.touched'):			xbmc.executebuiltin('Container.SetViewMode(50)')
        if (skin == 'skin.xperience1080'):		xbmc.executebuiltin('Container.SetViewMode(50)')

def xbmc_set_view():
    try:
        skinInfo = xbmc.translatePath('special://xbmc/addons/%s/addon.xml' % (skin))
        videoNav = 'special://xbmc/addons/%s/%s/MyVideoNav.xml'
        if not os.path.isfile(skinInfo):
            skinInfo = xbmc.translatePath('special://home/addons/%s/addon.xml' % (skin))
            videoNav = 'special://home/addons/%s/%s/MyVideoNav.xml'
        file = open(skinInfo,'r')
        read = file.read().replace('\n','')
        file.close()
        try:
            skinInfo = re.compile('defaultresolution="(.+?)"').findall(read)[0]
        except:
            skinInfo = re.compile('<res.+?folder="(.+?)"').findall(read)[0]
        videoNav = xbmc.translatePath(videoNav % (skin, skinInfo))
        file = open(videoNav,'r')
        read = file.read().replace('\n','')
        file.close()
        views = re.compile('<views>(.+?)</views>').findall(read)[0]
        views = [int(x) for x in views.split(',')]
        for view in views:
            viewLabel = xbmc.getInfoLabel('Control.GetLabel(%s)' % (view))
            if not (viewLabel == '' or viewLabel is None): break
        file = open(viewData, 'r')
        read = file.read()
        file.close()
        file = open(viewData, 'w')
        for line in re.compile('(".+?\n)').findall(read):
            if not line.startswith('"%s"|"' % (skin)): file.write(line)
        file.write('"%s"|"%s"\n' % (skin, str(view)))
        file.close()
        xbmc_notify('setview')
    except:
        return

def play_item():
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    xbmc.executebuiltin('Action(Queue)')
    playlist.unshuffle()
    xbmc.Player().play(playlist)

def random_play_item():
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    xbmc.executebuiltin('Action(Queue)')
    playlist.shuffle()
    xbmc.Player().play(playlist)

def queue_item():
    xbmc.executebuiltin('Action(Queue)')

def play_from_here_item(url):
    try:
        deamon = url
        folderPath = xbmc.getInfoLabel('Container.FolderPath')
        params = folderPath.split("?")[-1]
        params = dict(arg.split("=") for arg in params.split("&"))
        if params["action"] == "get_news": episodes_list = get_news()
        if params["action"] == "get_sports": episodes_list = get_sports()
        if params["action"] == "get_live": episodes_list = get_live()
        if params["action"] == "get_episodes":
            show = urllib.unquote_plus(params["show"])
            url = urllib.unquote_plus(params["url"])
            image = urllib.unquote_plus(params["image"])
            episodes_list = get_episodes(show,url,image)
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()
        playlist.unshuffle()
        episodes_list.reverse()
        play_from_here_list = []
        for item in episodes_list:
            play_from_here_list.append({'name': item['name'], 'show': item['show'], 'url': item['url'], 'image': item['image']})
            if deamon == item['url']: break
        play_from_here_list.reverse()
        for item in play_from_here_list:
            add_episodes(0,item['name'],item['show'],item['url'],item['image'],'playlist')
        xbmc.Player().play(playlist)
    except:
        return

def add_favourite_item(name,url):
    xbmc_refresh()
    file = open(favData, 'a+')
    file.write('"%s"|"%s"\n' % (name, url))
    file.close()
    xbmc_notify('favadd')

def delete_favourite_item(name,url):
    xbmc_refresh()
    file = open(favData, 'r')
    read = file.read().replace('"%s"|"%s"' % (name, url),'')
    file.close()
    file = open(favData, 'w')
    for line in re.compile('(".+?\n)').findall(read):
        file.write(line)
    file.close()
    xbmc_notify('favrem')

def move_favourite_item_up(name,url):
    xbmc_refresh()
    file = open(favData,'r')
    read = file.read()
    file.close()
    favourites_list = []
    for line in re.compile('(".+?)\n').findall(read):
        favourites_list.append(line)
    i = favourites_list.index('"%s"|"%s"' % (name, url))
    if i == 0: return
    favourites_list[i],favourites_list[i-1] = favourites_list[i-1],favourites_list[i]
    file = open(favData, 'w')
    for line in favourites_list:
        file.write('%s\n' % (line))
    file.close()
    xbmc_notify('favup')

def move_favourite_item_down(name,url):
    xbmc_refresh()
    file = open(favData,'r')
    read = file.read()
    file.close()
    favourites_list = []
    for line in re.compile('(".+?)\n').findall(read):
        favourites_list.append(line)
    i = favourites_list.index('"%s"|"%s"' % (name, url))
    if i+1 == len(favourites_list): return
    favourites_list[i],favourites_list[i+1] = favourites_list[i+1],favourites_list[i]
    file = open(favData, 'w')
    for line in favourites_list:
        file.write('%s\n' % (line))
    file.close()
    xbmc_notify('favdown')

def play_queue():
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.unshuffle()
    xbmc.Player().play(playlist)

def open_playlist():
    xbmc.executebuiltin('ActivateWindow(VideoPlaylist)')

def open_settings():
    xbmc.executebuiltin('Addon.OpenSettings(%s)' % (addonId))

def get_favourites():
    file = open(favData, 'r')
    read = file.read()
    file.close()
    list = re.compile('"(.+?)"[|]"(.+?)"').findall(read)
    total = len(list)
    for name,url in list:
        image = cacheFull(get_episodes,name,url,'','image')
        #image = get_episodes(name,url,'','image')
        if image == [] or image == "" or image is None: image = artPath+'Favourites.png'
        add_favourites(total,name,url,image)
    return

def add_favourites(total,name,url,image):
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    sysimage = urllib.quote_plus(image)
    u = '%s?action=get_episodes&show=%s&url=%s&image=%s' % (sysbase, sysname, sysurl, sysimage)
    cm = []
    cm.append((language(30401).encode("utf-8"), 'RunPlugin(%s?action=play_item)' % (sysbase)))
    cm.append((language(30402).encode("utf-8"), 'RunPlugin(%s?action=random_play_item)' % (sysbase)))
    cm.append((language(30404).encode("utf-8"), 'RunPlugin(%s?action=queue_item)' % (sysbase)))
    cm.append((language(30406).encode("utf-8"), 'RunPlugin(%s?action=play_queue)' % (sysbase)))
    cm.append((language(30407).encode("utf-8"), 'RunPlugin(%s?action=open_playlist)' % (sysbase)))
    cm.append((language(30408).encode("utf-8"), 'RunPlugin(%s?action=xbmc_set_view)' % (sysbase)))
    #cm.append((language(30409).encode("utf-8"), 'RunPlugin(%s?action=open_settings)' % (sysbase)))
    cm.append((language(30410).encode("utf-8"), 'RunPlugin(%s?action=move_favourite_item_up&name=%s&url=%s)' % (sysbase, sysname, sysurl)))
    cm.append((language(30411).encode("utf-8"), 'RunPlugin(%s?action=move_favourite_item_down&name=%s&url=%s)' % (sysbase, sysname, sysurl)))
    cm.append((language(30412).encode("utf-8"), 'RunPlugin(%s?action=delete_favourite_item&name=%s&url=%s)' % (sysbase, sysname, sysurl)))
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=image)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    item.setProperty("Fanart_Image", fanart)
    item.addContextMenuItems(cm, replaceItems=True)
    xbmcplugin.addDirectoryItem(handle=handle,url=u,listitem=item,totalItems=total,isFolder=True)
    return

def get_categories():
    total = 6
    add_categories(total,language(30501).encode("utf-8"),artPath+'Favourites.png','get_favourites')
    add_categories(total,language(30502).encode("utf-8"),artPath+'Live.png','get_live')
    add_categories(total,language(30503).encode("utf-8"),artPath+'ERT GR.png','get_ert_menus')
    add_categories(total,language(30504).encode("utf-8"),artPath+'YouTube.png','get_cinegreece_shows')
    add_categories(total,language(30505).encode("utf-8"),artPath+'News.png','get_news')
    add_categories(total,language(30506).encode("utf-8"),artPath+'Sports.png','get_sports')
    return

def add_categories(total,name,image,action):
    u = '%s?action=%s' % (sysbase, action)
    cm = []
    if action == 'get_news' or action == 'get_sports':
        cm.append((language(30401).encode("utf-8"), 'RunPlugin(%s?action=play_item)' % (sysbase)))
        cm.append((language(30402).encode("utf-8"), 'RunPlugin(%s?action=random_play_item)' % (sysbase)))
        cm.append((language(30404).encode("utf-8"), 'RunPlugin(%s?action=queue_item)' % (sysbase)))
    cm.append((language(30406).encode("utf-8"), 'RunPlugin(%s?action=play_queue)' % (sysbase)))
    cm.append((language(30407).encode("utf-8"), 'RunPlugin(%s?action=open_playlist)' % (sysbase)))
    cm.append((language(30408).encode("utf-8"), 'RunPlugin(%s?action=xbmc_set_view)' % (sysbase)))
    #cm.append((language(30409).encode("utf-8"), 'RunPlugin(%s?action=open_settings)' % (sysbase)))
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=image)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    item.setProperty("Fanart_Image", fanart)
    item.addContextMenuItems(cm, replaceItems=True)
    xbmcplugin.addDirectoryItem(handle=handle,url=u,listitem=item,totalItems=total,isFolder=True)
    return

def get_ert_menus():
    try:
        menus_url = "http://www.ert.gr/webtv/shows-directory"
        result = common.fetchPage({"link": menus_url})
        menus = common.parseDOM(result["content"], "ol", attrs = { "id": "letters" })[0]
        menus = common.parseDOM(menus, "li")
        total = len(menus)
    except:
        return
    for menu in menus:
        try:
            name = common.parseDOM(menu, "span")[0]
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            url = common.parseDOM(menu, "a", ret="href")[0]
            url = common.replaceHTMLCodes(url)
            url = '%s%s' % (ert_url, url)
            url = url.encode('utf-8')
            image = artPath+'Folder.png'
            add_menus(total,name,url,image)
        except:
            total = total - 1
            pass
    return

def add_menus(total,name,url,image):
    sysurl = urllib.quote_plus(url)
    u = '%s?action=get_ert_shows&url=%s' % (sysbase, sysurl)
    cm = []
    cm.append((language(30406).encode("utf-8"), 'RunPlugin(%s?action=play_queue)' % (sysbase)))
    cm.append((language(30407).encode("utf-8"), 'RunPlugin(%s?action=open_playlist)' % (sysbase)))
    cm.append((language(30408).encode("utf-8"), 'RunPlugin(%s?action=xbmc_set_view)' % (sysbase)))
    #cm.append((language(30409).encode("utf-8"), 'RunPlugin(%s?action=open_settings)' % (sysbase)))
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=image)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    item.setProperty("Fanart_Image", fanart)
    item.addContextMenuItems(cm, replaceItems=True)
    xbmcplugin.addDirectoryItem(handle=handle,url=u,listitem=item,totalItems=total,isFolder=True)
    return

def get_ert_shows(url):
    global shows_list
    shows_list = []

    try:
        shows_url = url
        result = common.fetchPage({"link": shows_url})
        shows = result["content"]
        try:
            pages = common.parseDOM(result["content"], "div", attrs = { "class": "k2Pagination" })[0]
            pages = common.parseDOM(pages, "a", ret="href")
            pages = unique_list(pages)
            for page in pages:
                url = '%s%s' % (ert_url, page)
                result = common.fetchPage({"link": url})
                shows += result["content"]
        except:
            pass
        shows = common.parseDOM(shows, "div", attrs = { "class": "itemListCategory" })
        shows = common.parseDOM(shows, "h2")
        total = len(shows)
    except:
        return
    for show in shows:
        try:
            name = common.parseDOM(show, "a")[0]
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            url = common.parseDOM(show, "a", ret="href")[0]
            url = common.replaceHTMLCodes(url)
            url = '%s%s' % (ert_url, url)
            url = url.encode('utf-8')
            #image = get_ert_shows_image(url)
            image = cache(get_ert_shows_image,url)
            image = common.replaceHTMLCodes(image)
            image = image.encode('utf-8')
            shows_list.append({'name': name, 'url': url, 'image': image})
            add_shows(total,name,url,image)
        except:
            total = total - 1
            pass

    return shows_list

def get_ert_shows_image(url):
    try:
        url = quote_url(url)
        result = common.fetchPage({"link": url})
        image = common.parseDOM(result["content"], "div", attrs = { "class": "catItemImageBlock" })[0]
        image = common.parseDOM(image, "img", ret="src")[0]
        image = image.replace('_M.jpg','_L.jpg')
        image = '%s%s' % (ert_url, image)
        image = image.encode('utf-8')
        return image
    except:
        return

def get_cinegreece_shows():
    global shows_list
    shows_list = []

    try:
        shows_url = "http://www.cinegreece.com/2012/05/ert.html"
        result = common.fetchPage({"link": shows_url})
        shows = common.parseDOM(result["content"], "div", attrs = { "itemprop": "articleBody" })[0]
        shows = re.compile('(<a.+?</a>)').findall(shows)
        total = len(shows)
    except:
        return
    for show in shows:
        try:
            name = common.parseDOM(show, "img", ret="title")[0]
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            url = common.parseDOM(show, "a", ret="href")[0]
            url = common.replaceHTMLCodes(url)
            url = url.replace(url.split("/")[2], cinegreece_url.split("//")[-1])
            url = url.encode('utf-8')
            image = common.parseDOM(show, "img", ret="src")[0]
            image = common.replaceHTMLCodes(image)
            image = image.encode('utf-8')
            shows_list.append({'name': name, 'url': url, 'image': image})
        except:
            total = total - 1
            pass

    total = 0
    shows_list = sorted(shows_list, key=itemgetter('name'))

    for item in shows_list:
        name = item['name']
        url = item['url']
        image = item['image']
        total += 1
        add_shows(total,name,url,image)

    return shows_list

def get_cinegreece_shows_image(url):
    try:
        result = common.fetchPage({"link": url})
        image = common.parseDOM(result["content"], "div", attrs = { "class": "separator" })[0]
        image = common.parseDOM(image, "img", ret="src")[0]
        image = common.replaceHTMLCodes(image)
        image = image.encode('utf-8')
        return image
    except:
        return

def add_shows(total,name,url,image):
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    sysimage = urllib.quote_plus(image)
    u = '%s?action=get_episodes&show=%s&url=%s&image=%s' % (sysbase, sysname, sysurl, sysimage)
    file = open(favData, 'r')
    read = file.read()
    file.close()
    cm = []
    cm.append((language(30401).encode("utf-8"), 'RunPlugin(%s?action=play_item)' % (sysbase)))
    cm.append((language(30402).encode("utf-8"), 'RunPlugin(%s?action=random_play_item)' % (sysbase)))
    cm.append((language(30404).encode("utf-8"), 'RunPlugin(%s?action=queue_item)' % (sysbase)))
    cm.append((language(30406).encode("utf-8"), 'RunPlugin(%s?action=play_queue)' % (sysbase)))
    cm.append((language(30407).encode("utf-8"), 'RunPlugin(%s?action=open_playlist)' % (sysbase)))
    if not url in read:
        cm.append((language(30413).encode("utf-8"), 'RunPlugin(%s?action=add_favourite_item&name=%s&url=%s)' % (sysbase, sysname, sysurl)))
    else:
        cm.append((language(30414).encode("utf-8"), 'RunPlugin(%s?action=delete_favourite_item&name=%s&url=%s)' % (sysbase, sysname, sysurl)))
    cm.append((language(30408).encode("utf-8"), 'RunPlugin(%s?action=xbmc_set_view)' % (sysbase)))
    #cm.append((language(30409).encode("utf-8"), 'RunPlugin(%s?action=open_settings)' % (sysbase)))
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=image)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    item.setProperty("Fanart_Image", fanart)
    item.addContextMenuItems(cm, replaceItems=True)
    xbmcplugin.addDirectoryItem(handle=handle,url=u,listitem=item,totalItems=total,isFolder=True)
    return

def get_episodes(show,url,image,mode=None):
    global episodes_list
    episodes_list = []

    if url.startswith(ert_url):
        if mode is None:
            episodes_list = get_ert_episodes(show,url,image)
        else:
            image = get_ert_shows_image(url)
            return image

    if url.startswith(cinegreece_url):
        if mode is None:
            episodes_list = get_cinegreece_episodes(show,url,image)
        else:
            image = get_cinegreece_shows_image(url)
            return image

    return episodes_list

def get_ert_episodes(show,url,image):
    try:
        episodes_url = quote_url(url)
        result = common.fetchPage({"link": episodes_url})
        episodes = result["content"]
        try:
            pages = common.parseDOM(result["content"], "div", attrs = { "class": "k2Pagination" })[0]
            pages = common.parseDOM(pages, "a", ret="href")
            pages = unique_list(pages)
            for page in pages[:5]:
                url = '%s%s' % (ert_url, page)
                url = url.encode('utf-8')
                url = quote_url(url)
                result = common.fetchPage({"link": url})
                episodes += result["content"]
        except:
            pass
        episodes = common.parseDOM(episodes, "div", attrs = { "class": "catItemImageBlock" })
        total = len(episodes)
    except:
        return

    if total == 1:
        try:
            url = common.parseDOM(episodes[0], "a", ret="href")[0]
            url = '%s%s' % (ert_url, url)
            url = url.encode('utf-8')
            url = quote_url(url)
            result = common.fetchPage({"link": url})
            video = common.parseDOM(result["content"], "div", attrs = { "class": "itemVideoEmbedded" })[0]
        except:
            get_ert_archives_episodes(show,url,image)
            return

    for episode in episodes:
        try:
            name = common.parseDOM(episode, "a", ret="title")[0]
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            url = common.parseDOM(episode, "a", ret="href")[0]
            url = common.replaceHTMLCodes(url)
            url = '%s%s' % (ert_url, url)
            url = url.encode('utf-8')
            image = common.parseDOM(episode, "img", ret="src")[0]
            image = common.replaceHTMLCodes(image)
            image = image.replace('_M.jpg','_L.jpg')
            image = '%s%s' % (ert_url, image)
            image = image.encode('utf-8')
            episodes_list.append({'name': name, 'show': show, 'url': url, 'image': image})
            add_episodes(total,name,show,url,image)
        except:
            total = total - 1
            pass

    return episodes_list

def get_ert_archives_episodes(show,url,image):
    try:
        result = common.fetchPage({"link": url})
        episodes = common.parseDOM(result["content"], "div", attrs = { "class": "itemFullText" })[0]
        episodes = re.compile('(<a.+?</a>)').findall(episodes)
        episodes = unique_list(episodes)
        total = len(episodes)
    except:
        return
    for episode in episodes:
        try:
            name = common.parseDOM(episode, "a")[0]
            name = re.compile('<strong>(\d.+?)').findall(name)[0]
            name = re.compile('(\d*)').findall(name)[0]
            name = u'\u0395'u'\u03C0'u'\u03B5'u'\u03B9'u'\u03C3'u'\u03CC'u'\u03B4'u'\u03B9'u'\u03BF' + ' ' + name
            name = name.encode('utf-8')
            url = common.parseDOM(episode, "a", ret="href")[0]
            url = common.replaceHTMLCodes(url)
            url = url.encode('utf-8')
            episodes_list.append({'name': name, 'show': show, 'url': url, 'image': image})
            add_episodes(total,name,show,url,image)
        except:
            total = total - 1
            pass

    return episodes_list

def get_cinegreece_episodes(show,url,image):
    try:
        result = common.fetchPage({"link": url})
        episodes = re.compile('(<button.+?a="a".+?</button>)').findall(result["content"])
        episodes = unique_list(episodes)
        total = len(episodes)
    except:
        return
    for episode in episodes:
        try:
            name = common.parseDOM(episode, "button")[0]
            name = u'\u0395'u'\u03C0'u'\u03B5'u'\u03B9'u'\u03C3'u'\u03CC'u'\u03B4'u'\u03B9'u'\u03BF' + ' ' + name
            name = name.replace('&nbsp;&nbsp;&nbsp;','-')
            name = name.encode('utf-8')
            url = common.parseDOM(episode, "button", ret="onclick")[0]
            url = re.compile("'(.+?)'").findall(url)[0]
            url = url.split("&amp;")[0].split("/")[-1].split("=")[-1]
            url = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % url
            url = url.encode('utf-8')
            episodes_list.append({'name': name, 'show': show, 'url': url, 'image': image})
            add_episodes(total,name,show,url,image)
        except:
            total = total - 1
            pass

    return episodes_list

def get_live():
    global episodes_list
    episodes_list = []
    total = 6

    name = 'NET'
    episodes_list.append({'name': name, 'show': 'ERT GR', 'url': name, 'image': '%s%s.png' % (artPath, name)})
    add_episodes(total,name,'ERT GR',name,'%s%s.png' % (artPath, name))

    name = 'ET1'
    episodes_list.append({'name': name, 'show': 'ERT GR', 'url': name, 'image': '%s%s.png' % (artPath, name)})
    add_episodes(total,name,'ERT GR',name,'%s%s.png' % (artPath, name))

    name = 'ET3'
    episodes_list.append({'name': name, 'show': 'ERT GR', 'url': name, 'image': '%s%s.png' % (artPath, name)})
    add_episodes(total,name,'ERT GR',name,'%s%s.png' % (artPath, name))

    name = 'ERT World'
    episodes_list.append({'name': name, 'show': 'ERT GR', 'url': name, 'image': '%s%s.png' % (artPath, name)})
    add_episodes(total,name,'ERT GR',name,'%s%s.png' % (artPath, name))

    name = 'ERT WebSport1'
    episodes_list.append({'name': name, 'show': 'ERT GR', 'url': name, 'image': '%s%s.png' % (artPath, name)})
    add_episodes(total,name,'ERT GR',name,'%s%s.png' % (artPath, name))

    name = 'ERT WebSport2'
    episodes_list.append({'name': name, 'show': 'ERT GR', 'url': name, 'image': '%s%s.png' % (artPath, name)})
    add_episodes(total,name,'ERT GR',name,'%s%s.png' % (artPath, name))

    name = 'ERT WebSport3'
    episodes_list.append({'name': name, 'show': 'ERT GR', 'url': name, 'image': '%s%s.png' % (artPath, name)})
    add_episodes(total,name,'ERT GR',name,'%s%s.png' % (artPath, name))

    return episodes_list

def get_news():
    episodes_list = get_episodes('ERT GR','http://www.ert.gr/webtv/net-deltia-eidisewn','')
    return episodes_list

def get_sports():
    episodes_list = get_episodes('ERT GR','http://www.ert.gr/webtv/athlhtika/itemlist/category/71-athlhtika','')
    return episodes_list

def add_episodes(total,name,show,url,image,mode=None):
    sysurl = urllib.quote_plus(url)
    u = '%s?action=play_video&url=%s' % (sysbase, sysurl)
    cm = []
    cm.append((language(30405).encode("utf-8"), 'RunPlugin(%s?action=queue_item)' % (sysbase)))
    cm.append((language(30403).encode("utf-8"), 'RunPlugin(%s?action=play_from_here_item&url=%s)' % (sysbase, sysurl)))
    cm.append((language(30406).encode("utf-8"), 'RunPlugin(%s?action=play_queue)' % (sysbase)))
    cm.append((language(30407).encode("utf-8"), 'RunPlugin(%s?action=open_playlist)' % (sysbase)))
    cm.append((language(30408).encode("utf-8"), 'RunPlugin(%s?action=xbmc_set_view)' % (sysbase)))
    #cm.append((language(30409).encode("utf-8"), 'RunPlugin(%s?action=open_settings)' % (sysbase)))
    item = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=image)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": show, "Plot": description } )
    item.setProperty("IsPlayable", "true")
    item.setProperty( "Video", "true" )
    item.setProperty("Fanart_Image", fanart)
    if mode == 'playlist':
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.add(u, item)
    else:
        item.addContextMenuItems(cm, replaceItems=True)
        xbmcplugin.addDirectoryItem(handle=handle,url=u,listitem=item,totalItems=total)
    return

def play_video(url):
    if url == "NET":
        url = 'rtmp://cp76856.live.edgefcs.net/live/GRERT_vid_nogeo_NET@25927 live=1 timeout=10'
        hls = 'http://ebuios-i.akamaihd.net/hls/live/200094/sample/iphone/test.m3u8'
        try:
            result = common.fetchPage({"link": hls})
            if "EXTM3U" in result["content"]: url = hls
        except:
            pass

    elif url == "ET1":
        url = 'rtmp://cp76856.live.edgefcs.net/live/GRERT_vid_nogeo_ET1@25926 live=1 timeout=10'
        hls = 'http://ebuios-i.akamaihd.net/hls/live/200703/sample/iphone/test.m3u8'
        try:
            result = common.fetchPage({"link": hls})
            if "EXTM3U" in result["content"]: url = hls
        except:
            pass

    elif url == "ET3":
        url = 'rtmp://cp76856.live.edgefcs.net/live/GRERT_vid_nogeo_ET3@25928 live=1 timeout=10'

    elif url == "ERT World":
        try:
            cookie = 'http://tvnetwork.new.visionip.tv/Hellenic_TV'
            url = 'http://tvnetwork.new.visionip.tv/Hellenic_TV/index.php?module=playlist&type=jwASX&broadcastid=4267'
            result = get_url(url,cookie=cookie)
            result = common.parseDOM(result, "entry")[0]
            streamer = common.parseDOM(result, "param", ret="value")[0]
            playpath = common.parseDOM(result, "ref", ret="href")[0]
            url = '%s/%s live=1 timeout=10' % (streamer, playpath)
        except:
            return

    elif url == "ERT WebSport1":
        url = 'rtmp://cp76858.live.edgefcs.net/live/grert_video_gr_f1@26623 swfUrl=http://www.ert.gr/webtv/multi-player/AkamaiFlashPlayer.swf swfVfy=1 live=1 timeout=10'

    elif url == "ERT WebSport2":
        url = 'rtmp://cp76858.live.edgefcs.net/live/grert_video_gr_f2@26624 swfUrl=http://www.ert.gr/webtv/multi-player/AkamaiFlashPlayer.swf swfVfy=1 live=1 timeout=10'

    elif url == "ERT WebSport3":
        url = 'rtmp://cp76858.live.edgefcs.net/live/grert_video_gr_f3@60513 swfUrl=http://www.ert.gr/webtv/multi-player/AkamaiFlashPlayer.swf swfVfy=1 live=1 timeout=10'

    elif url.startswith('plugin://plugin.video.youtube/'):
        if check_addon('plugin.video.youtube') is None:
            xbmcgui.Dialog().ok(addonname, language(30351).encode("utf-8"), language(30352).encode("utf-8"))
            return

    elif url.startswith(ert_archives_url):
        try:
            params = url.split("?")[-1]
            params = dict(arg.split("=") for arg in params.split("&"))
            tid = urllib.quote_plus(params["tid"])
            url = 'http://www.ert-archives.gr/V3/media.hFLV?tid=%s' % tid
        except:
            return

    elif url.startswith(ert_url):
        try:
            url = quote_url(url)
            result = common.fetchPage({"link": url})
            content = common.parseDOM(result["content"], "div", attrs = { "class": "itemVideoEmbedded" })[0]
            try:
                url = common.parseDOM(content, "iframe", ret="src")[0]
                if "youtube" in url:
                    url = url.split("&amp;")[0].split("/")[-1].split("=")[-1]
                    url = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % url
                    if check_addon('plugin.video.youtube') is None:
                        xbmcgui.Dialog().ok(addonname, language(30351).encode("utf-8"), language(30352).encode("utf-8"))
                        return
            except:
                pass
            try:
                rtmp = re.compile("'(rtmp://.+?)'").findall(content)[0]
                if (rtmp.endswith('.mp4') or rtmp.endswith('.f4v')): rtmp = rtmp.replace('/ondemand/','/ondemand/mp4:')
                swfUrl = re.compile("embedSWF[(]'(.+?)'").findall(content)[0]
                url = '%s pageUrl=%s swfUrl=%s swfVfy=1 timeout=10' % (rtmp, url, swfUrl)
            except:
                pass
            try:
                hls = re.compile('(http://.+?[.]m3u8)').findall(content)[0]
                result = common.fetchPage({"link": hls})
                if "EXTM3U" in result["content"]: url = hls
            except:
                pass
        except:
            return

    item = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(handle, True, item)
    return url

main()