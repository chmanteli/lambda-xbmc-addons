# -*- coding: utf-8 -*-

'''
    ert online XBMC Addon
    Copyright (C) 2012 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib,urllib2,re,os,xbmcplugin,xbmcgui,xbmcaddon
import random
import sets

settings = xbmcaddon.Addon(id='plugin.video.ert.gr')
data = 'special://profile/addon_data/plugin.video.ert.gr'

home = settings.getAddonInfo('path')
language = settings.getLocalizedString
addonname = settings.getAddonInfo("name")
description = language(30504).encode("utf-8")
icon = xbmc.translatePath(os.path.join(home,'icon.png'))
artPath = xbmc.translatePath(os.path.join(home,'resources/art/'))
art1 = xbmc.translatePath(os.path.join(artPath,'ET1_anticipation.jpg'))
art2 = xbmc.translatePath(os.path.join(artPath,'ET1_astonishment.jpg'))
art3 = xbmc.translatePath(os.path.join(artPath,'ET1_humour.jpg'))
art4 = xbmc.translatePath(os.path.join(artPath,'ET1_joy.jpg'))
art5 = xbmc.translatePath(os.path.join(artPath,'ET1_love.jpg'))
art6 = xbmc.translatePath(os.path.join(artPath,'ET1_serenity.jpg'))
art7 = xbmc.translatePath(os.path.join(artPath,'NET_beach.jpg'))
art8 = xbmc.translatePath(os.path.join(artPath,'NET_dance.jpg'))
art9 = xbmc.translatePath(os.path.join(artPath,'NET_fashion.jpg'))
art10 = xbmc.translatePath(os.path.join(artPath,'NET_lanterns.jpg'))
art11 = xbmc.translatePath(os.path.join(artPath,'NET_music.jpg'))
art12 = xbmc.translatePath(os.path.join(artPath,'NET_shadows.jpg'))
fanart = xbmc.translatePath(os.path.join(home,'fanart.jpg'))
favPath = xbmc.translatePath(os.path.join(data,'favourites.cfg'))
dataPath = xbmc.translatePath(data)
skin = xbmc.getSkinDir()

xbmcplugin.setContent(int(sys.argv[1]), 'Episodes')
xbmcplugin.setPluginFanart(int(sys.argv[1]), fanart)

try:
    import StorageServer
    cache = StorageServer.StorageServer(addonname,720)
except:
    import storageserverdummy as StorageServer
    cache = StorageServer.StorageServer(addonname,720)

try:
    import CommonFunctions
    common = CommonFunctions
except:
    import commonfunctionsdummy as CommonFunctions
    common = CommonFunctions



base_url = 'http://www.ert.gr'
shows_url = 'http://www.ert.gr/webtv/'


def GetURL(url,referer=None):
    if referer is None:
        headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0'}
    else:
        headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0', 'Referer' : referer}
    req = urllib2.Request(url,None,headers)
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    link = link.replace('\n','')
    return link

def unique_list(list):
    unique_set = sets.Set()
    unique_list = []
    for n in list:
        if n not in unique_set:
            unique_set.add(n)
            unique_list.append(n)
    return unique_list

def xbmc_notify(type):
    if type == 'favadd':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30201).encode("utf-8")))
    elif type == 'favrem':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30202).encode("utf-8")))
    elif type == 'favup':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30203).encode("utf-8")))
    elif type == 'favdown':
        xbmc.executebuiltin("XBMC.Notification(%s,%s, 3000)" % (addonname, language(30204).encode("utf-8")))

def xbmc_refresh():
    xbmc.executebuiltin("Container.Refresh")

def xbmc_view():
    viewenable = settings.getSetting("viewenable")

    if (skin == 'skin.confluence' or skin == 'skin.confluence.svn') and viewenable == 'true':
        confluence_views = [50,51,500,504,503,515]
        view = int(settings.getSetting("confluence"))
        xbmc.executebuiltin("Container.SetViewMode("+str(confluence_views[view])+")")

    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn') and viewenable == 'true':
        rapier_views = [50,52,74,73,68,94]
        view = int(settings.getSetting("rapier"))
        xbmc.executebuiltin("Container.SetViewMode("+str(rapier_views[view])+")")

def xbmc_data():
    if not os.path.exists(dataPath):
        os.makedirs(dataPath)
    if not os.path.isfile(favPath):
        read = open(favPath, 'w')
        read.write('')
        read.close()

def add_favourite_item(name,url):
    xbmc_refresh()
    read = open(favPath, 'a+')
    read.write('"'+name+'"|"'+url+'"\n')
    read.close()
    xbmc_notify('favadd')

def delete_favourite_item(name,url):
    xbmc_refresh()
    read = open(favPath, 'r')
    text = read.read().replace('"'+name+'"|"'+url+'"','')
    read.close()
    read = open(favPath, 'w')
    for line in re.compile('"(.+?)\n').findall(text):
        read.write('"'+line+'\n')
    read.close()
    xbmc_notify('favrem')

def move_favourite_item(name,url,type):
    xbmc_refresh()
    replaced = []
    j = []
    i = 0
    f = open(favPath,'r')
    for line in f:
        if re.search('"'+url.replace('?','[?]')+'"',line) is not None:
            j = i
        i = i+1
    f.close()
    if type == 'favup':
        i = 1
    if type == 'favdown':
        i = -1
    f = open(favPath,'r')
    for line in f:
        if i == j:
            replaced = line
        i = i+1
    f.close()

    if not replaced == []:
        read = open(favPath, 'r')
        text = read.read()
        if type == 'favup':
            text = text.replace(replaced+'"'+name+'"|"'+url+'"','"'+name+'"|"'+url+'"'+replaced)
            text = text.replace('\n','')
        if type == 'favdown':
            text = text.replace('"'+name+'"|"'+url+'"\n'+replaced,replaced+'"'+name+'"|"'+url+'"')
            text = text.replace('\n','')
        read.close()
        read = open(favPath, 'w')
        for name,cid in re.compile('"(.+?)"[|]"(.+?)"').findall(text):
            read.write('"'+name+'"|"'+cid+'"\n')
        if type == 'favup':
            xbmc_notify('favup')
        if type == 'favdown':
            xbmc_notify('favdown')
	    read.close()

def get_favourites():
    xbmc_data()
    read = open(favPath, 'r')
    text = read.read()
    read.close()
    for name,url in re.compile('"(.+?)"[|]"(.+?)"').findall(text):
        iconimage = random.choice([art1,art2,art3,art4,art5,art6,art7,art8,art9,art10,art11,art12])
        add_favourites(name,url,500,iconimage)
    xbmc_view()

def add_favourites(name,url,mode,iconimage):
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    contextMenuItems = []
    contextMenuItems.append((xbmc.getLocalizedString(13332), 'XBMC.RunPlugin(%s?mode=102&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    contextMenuItems.append((xbmc.getLocalizedString(13333), 'XBMC.RunPlugin(%s?mode=103&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    contextMenuItems.append((xbmc.getLocalizedString(1210), 'XBMC.RunPlugin(%s?mode=101&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    u = '%s?mode=%s&url=%s' % (sys.argv[0], str(mode), sysurl)
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        item.setProperty( "Fanart_Image", iconimage )
    else: item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,isFolder=True)

def get_categories():
    xbmc_data()
    add_categories(language(30501).encode("utf-8"),base_url,200,random.choice([art1,art2,art3,art4,art5,art6,art7,art8,art9,art10,art11,art12]))
    add_categories(language(30502).encode("utf-8"),base_url,400,random.choice([art1,art2,art3,art4,art5,art6,art7,art8,art9,art10,art11,art12]))
    try:
        result = common.fetchPage({"link": shows_url})
        categories = common.parseDOM(result["content"], "div", attrs = { "class": "article-content clear" })[0]
        categories = common.parseDOM(categories, "td", attrs = { "valign": "top" })
        count = -1
    except:
        xbmc_view()
        return
    for category in categories:
        try:
            name = common.parseDOM(category, "th", attrs = { "valign": "top" })[0]
            name = name.encode('utf-8')
            iconimage = common.parseDOM(category, "img", ret="src")[0]
            count = count + 1
            url = str(count)
            url = url.encode('utf-8')
            iconimage = iconimage.replace('_M.jpg','_L.jpg')
            iconimage = base_url + iconimage
            iconimage = iconimage.encode('utf-8')
            add_categories(name,url,300,iconimage)
        except:
            pass
    xbmc_view()
    return

def add_categories(name,url,mode,iconimage):
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    contextMenuItems = []
    u = '%s?mode=%s&url=%s' % (sys.argv[0], str(mode), sysurl)
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        item.setProperty( "Fanart_Image", iconimage )
    else: item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,isFolder=True)

def get_cat_episodes(url):
    xbmc_data()
    try:
        result = common.fetchPage({"link": shows_url})
        categories = common.parseDOM(result["content"], "div", attrs = { "class": "article-content clear" })[0]
        categories = common.parseDOM(categories, "td", attrs = { "valign": "top" })
        if url == '0' : categories = categories[0]
        elif url == '1' : categories = categories[1]
        elif url == '2' : categories = categories[2]
        elif url == '3' : categories = categories[3]
        elif url == '4' : categories = categories[4]
        elif url == '5' : categories = categories[5]
        else : categories = []
        cat_episodes = categories.replace('"firstItem"', '"listItems"')
        cat_episodes = common.parseDOM(cat_episodes, "div", attrs = { "class": "listItems" })
    except:
        return
    for cat_episode in cat_episodes:
        try:
            name1 = common.parseDOM(cat_episode, "a", attrs = { "class": "moduleItemCategoryIns" })[0]
            name2 = common.parseDOM(cat_episode, "a", attrs = { "class": "moduleItemTitle" })[0]
            name = '%s - %s' % (name1, name2)
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            show = common.replaceHTMLCodes(name1)
            show = show.encode('utf-8')
            url = common.parseDOM(cat_episode, "a", attrs = { "class": "moduleItemTitle" }, ret="href")[0]
            url = base_url + url
            url = url.encode('utf-8')
            try:
                iconimage = common.parseDOM(cat_episode, "img", ret="src")[0]
                iconimage = iconimage.replace('_M.jpg','_L.jpg')
                iconimage = base_url + iconimage
                iconimage = iconimage.encode('utf-8')
            except:
                pass
            try:
                iconimage = cache.cacheFunction(get_cat_episode_image, url)
                #iconimage = get_cat_episode_image(url)
            except:
                pass
            add_cat_episodes(name,show,url,iconimage)
        except:
            pass
    xbmc_view()
    return

def get_cat_episode_image(url):
    try:
        result = GetURL(url)
        iconimage = re.compile('<div class="itemBody">.+?<img src="(.+?)"').findall(result)[0]
        iconimage = base_url + iconimage
        iconimage = iconimage.encode('utf-8')
        return iconimage
    except:
        return

def add_cat_episodes(name,show,url,iconimage):
    mode = 900
    sysurl = urllib.quote_plus(url)
    u = '%s?mode=%s&url=%s' % (sys.argv[0], str(mode), sysurl)
    contextMenuItems = []
    item = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": show, "Plot": description } )
    item.setProperty("IsPlayable", "true")
    item.setProperty( "Video", "true" )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        item.setProperty( "Fanart_Image", iconimage )
    else: item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)	
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item)

def get_shows():
    xbmc_data()
    add_shows('NET - %s' % language(30503).encode("utf-8"),'http://www.ert.gr/webtv/athlhtika',500,random.choice([art1,art2,art3,art4,art5,art6,art7,art8,art9,art10,art11,art12]))
    try:
        result = common.fetchPage({"link": shows_url})
        shows = common.parseDOM(result["content"], "div", attrs = { "class": "megamenu" })[0]
    except:
        xbmc_view()
        return
    try:
        net = []
        net = common.parseDOM(shows, "div", attrs = { "id": "mak-nav-more-net-inner" })[0]
        net = re.compile('(<a.+?</a>)').findall(net)
    except:
        pass
    try:
        et1 = []
        et1 = common.parseDOM(shows, "div", attrs = { "id": "mak-nav-more-et1-inner" })[0]
        et1 = re.compile('(<a.+?</a>)').findall(et1)
    except:
        pass
    try:
        et3 = []
        et3 = common.parseDOM(shows, "div", attrs = { "id": "mak-nav-more-et3-inner" })[0]
        et3 = re.compile('(<a.+?</a>)').findall(et3)
    except:
        pass
    try:
        ertworld = []
        ertworld = common.parseDOM(shows, "div", attrs = { "id": "mak-nav-more-ertworld-inner" })[0]
        ertworld = re.compile('(<a.+?</a>)').findall(ertworld)
    except:
        pass
    for show in net:
        try:
            name = common.parseDOM(show, "a")[0]
            name = 'NET - %s' % common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            url = common.parseDOM(show, "a", ret="href")[0]
            url = base_url + url
            url = url.encode('utf-8')
            add_shows(name,url,500,random.choice([art1,art2,art3,art4,art5,art6,art7,art8,art9,art10,art11,art12]))
        except:
            pass
    for show in et1:
        try:
            name = common.parseDOM(show, "a")[0]
            name = 'ET1 - %s' % common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            url = common.parseDOM(show, "a", ret="href")[0]
            url = base_url + url
            url = url.encode('utf-8')
            add_shows(name,url,500,random.choice([art1,art2,art3,art4,art5,art6,art7,art8,art9,art10,art11,art12]))
        except:
            pass
    for show in et3:
        try:
            name = common.parseDOM(show, "a")[0]
            name = 'ET3 - %s' % common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            url = common.parseDOM(show, "a", ret="href")[0]
            url = base_url + url
            url = url.encode('utf-8')
            add_shows(name,url,500,random.choice([art1,art2,art3,art4,art5,art6,art7,art8,art9,art10,art11,art12]))
        except:
            pass
    for show in ertworld:
        try:
            name = common.parseDOM(show, "a")[0]
            name = 'ERT World - %s' % common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            url = common.parseDOM(show, "a", ret="href")[0]
            url = base_url + url
            url = url.encode('utf-8')
            add_shows(name,url,500,random.choice([art1,art2,art3,art4,art5,art6,art7,art8,art9,art10,art11,art12]))
        except:
            pass
    xbmc_view()
    return

def add_shows(name,url,mode,iconimage):
    sysname = urllib.quote_plus(name)
    sysurl = urllib.quote_plus(url)
    read = open(favPath, 'r')
    text = read.read()
    read.close()
    contextMenuItems = []
    if not url in text: contextMenuItems.append((xbmc.getLocalizedString(14076), 'XBMC.RunPlugin(%s?mode=100&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    else: contextMenuItems.append((xbmc.getLocalizedString(14077), 'XBMC.RunPlugin(%s?mode=101&name=%s&url=%s)' % (sys.argv[0], sysname, sysurl)))
    u = '%s?mode=%s&url=%s' % (sys.argv[0], str(mode), sysurl)
    item = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": name, "Plot": description } )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        item.setProperty( "Fanart_Image", iconimage )
    else: item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item,isFolder=True)

def get_episodes(url):
    xbmc_data()
    try:
        result = common.fetchPage({"link": url})
        episodes = common.parseDOM(result["content"], "div", attrs = { "id": "itemListLeading" })[0]
    except:
        return
    try:
        navs = common.parseDOM(result["content"], "div", attrs = { "class": "k2Pagination" })[0]
        navs = common.parseDOM(navs, "a", ret="href")
        navs = unique_list(navs)
        for nav in navs:
            url = base_url + nav
            result = common.fetchPage({"link": url})
            episodes += common.parseDOM(result["content"], "div", attrs = { "id": "itemListLeading" })[0]
    except:
        pass
    try:
        episodes = common.parseDOM(episodes, "div", attrs = { "class": "catItemView groupLeading" })
    except:
        return
    for episode in episodes:
        try:
            name1 = common.parseDOM(episode, "div", attrs = { "class": "catItemCategory" })[0]
            name1 = common.parseDOM(name1, "a")[0]
            name2 = common.parseDOM(episode, "a", ret="title")[0]
            name = '%s - %s' % (name1, name2)
            name = common.replaceHTMLCodes(name)
            name = name.encode('utf-8')
            show = common.replaceHTMLCodes(name1)
            show = show.encode('utf-8')
            url = common.parseDOM(episode, "a", ret="href")[0]
            url = base_url + url
            url = url.encode('utf-8')
            iconimage = common.parseDOM(episode, "img", ret="src")[0]
            iconimage = iconimage.replace('_M.jpg','_L.jpg')
            iconimage = base_url + iconimage
            iconimage = iconimage.encode('utf-8')
            add_episodes(name,show,url,iconimage)
        except:
            pass
    xbmc_view()
    return

def add_episodes(name,show,url,iconimage):
    mode = 900
    sysurl = urllib.quote_plus(url)
    u = '%s?mode=%s&url=%s' % (sys.argv[0], str(mode), sysurl)
    contextMenuItems = []
    item = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    item.setInfo( type="Video", infoLabels={ "Label": name, "Title": name, "TVShowTitle": show, "Plot": description } )
    item.setProperty("IsPlayable", "true")
    item.setProperty( "Video", "true" )
    if (skin == 'skin.rapier' or skin == 'skin.rapier.svn'):
        item.setProperty( "Fanart_Image", iconimage )
    else: item.setProperty( "Fanart_Image", fanart )
    item.addContextMenuItems(contextMenuItems, replaceItems=True)	
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=item)

def resolve_episodes(url):
    try:
        result = GetURL(url)
        temp = re.search("var flashvars.+?src.+?'(.+?)'.+?embedSWF[(]'(.+?)'", result)
        rtmp,swfUrl = temp.groups()
        if (rtmp.endswith('.mp4') or rtmp.endswith('.f4v')):
            rtmp = rtmp.replace('/ondemand/','/ondemand/mp4:')
        url = '%s pageUrl=%s swfUrl=%s swfVfy=true timeout=10' % (rtmp, url, swfUrl)
        item = xbmcgui.ListItem(path=url)
        return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
    except:
        return


def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?','')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


params = get_params()
url = None
name = None
mode = None
try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass


if mode == None or url == None or len(url) < 1:
    get_categories()

elif mode == 100:
    add_favourite_item(name,url)

elif mode == 101:
    delete_favourite_item(name,url)

elif mode == 102:
    move_favourite_item(name,url,'favup')

elif mode == 103:
    move_favourite_item(name,url,'favdown')

elif mode == 200:
    get_favourites()

elif mode == 300:
    get_cat_episodes(url)

elif mode == 400:
    get_shows()

elif mode == 500:
    get_episodes(url)

elif mode == 900:
    resolve_episodes(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))